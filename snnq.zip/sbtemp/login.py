﻿# -*- coding: utf-8 -*-
#=====================================================================
from linepy import *
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import *
from tornado import ioloop
from tornado.httpclient import HTTPClient
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup as bSoup
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from Naked.toolshed.shell import execute_js
from threading import Thread
from tmp.Instagram import InstagramScraper
from instagram import Instagram
from io import StringIO
from py_translator import TEXTLIB
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from tmp.MySplit import *
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import platform
import requests, json
import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=====================================================================
#=====================================================================
with open("token1.txt","r") as z:
    token = z.read()
noobcoder = LINE(token,appName="DESKTOPMAC")
noobcoder.log("Auth Token : " + str(noobcoder.authToken))
#
#Channel(noobcoder, "1602687308").getChannelResult().channelAccessToken
waitOpen = codecs.open("wait.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
imagesOpen = codecs.open("image.json","r","utf-8")
stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers2Open = codecs.open("sticker2.json","r","utf-8")
blockInviteOpen = codecs.open("HOOKZ/blockinvite.json","r","utf-8")
protectKickOpen = codecs.open("HOOKZ/protectkick.json","r","utf-8")
groupNameOpen = codecs.open("HOOKZ/groupname.json","r","utf-8")
groupQrOpen = codecs.open("HOOKZ/groupqr.json","r","utf-8")
notagOpen = codecs.open("HOOKZ/notag.json","r","utf-8")
#=====================================================================
#=====================================================================
noobcoderProfile = noobcoder.getProfile()
noobcoderSettings = noobcoder.getSettings()
noobcoderPoll = OEPoll(noobcoder)
noobcoderMID = noobcoder.getProfile().mid
#=====================================================================
#=====================================================================
loop = asyncio.get_event_loop()
maker = ["u9b9897fdd536e9886a4b7c28def482cf"]
botStart = time.time()
mid = []
msg_image={}
msg_video={}
msg_sticker={}
msgdikirim = {}
msgditerima = {}
unsendchat = {}
msg_dict = {}
msg_dict1 = {}
temp_flood = {}
groupName = {}
groupImage = {}
kuciyose = {}
protectname = []
wbanlist = []
protectinvite = []
protectkick = []
protectjoin = []
protectqr = []
steals = []
noobcoderStart = time.time()
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
images = json.load(imagesOpen)
stickers = json.load(stickersOpen)
stickers2 = json.load(stickers2Open)
blockInvite = json.load(blockInviteOpen)
protectKick = json.load(protectKickOpen)
groupName = json.load(groupNameOpen)
groupQr = json.load(groupQrOpen)
responsename = noobcoder.getProfile().displayName
mulai = time.time()
#
covid19 =""".9.0"""
#
Lexe = {"lscon":{},"lstatus":False,"lkick":{},"lcancel":{},"lleave":{},"linvite":{},"ljoin":{},"lban":""}
wtf = {
    "autoBlock": False
}
nissa = {
    "addTikel2": {
        "name": "",
        "status": False
        },
}
Sider1 = {
    "siderRoom": {},
    "siderMessage": "Sider Test",
}
tailah = {
    "siderTemp": {},
    "siderPesan": "How are you today?",
}
tailah2 = {
    "siderTemp": {},
    "siderPesan": "Oh, hi",
}
tailah2tag = {
    "siderTemp": {}
}
tailah3 = {
    "siderTemp": {},
    "siderPesan": "Hey there ...",
}
tailah4 = {
    "siderTemp": {},
    "siderPesan": "Dont wait, Join Call!",
}
tailah5 = {
    "siderTemp": {},
    "siderPesan": "What are you looking?",
}
tailah6 = {
    "siderTemp": {},
    "siderPesan": "What are you looking?",
}
liffnya = {
        "ttt": "line://app/1602687308-GXq4Vvk9?type=text&text=",
}
setting = {
    "temp_flood": False,
    "expire" : True,
    "likeTimeline": False,
    "comment": {},
    "time": time.time(),
    "flood": 0,
}
anyun = {
    "addTikel": {
        "name": "",
        "status": False
        },
}
wait2 = {
    "detectSContact":{
    "SContact": 5,
     "status":False,
     "tmp":{}
    },
}
komen = {
    "komenan": False,
}
lastseen = {
    "find": {},
    "username": {}
}
chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
}
tes = {
    "Message": {},
    "msg": {},
}
tes2 = {
    "Message2": {},
    "msg2": {},
}
peler = { 
    "receivercount": 0,
    "sendcount": 0
}
read = { 
    "readMember": {},
    "readPoint": {}
}
hoho = {
    "savefile": False,
    "namefile": "",
}
temptag = {
    "stealtag": False,
    "pesanya": "What's wrong , i'm busy right now",
}
wmin = {
    "wMessage": False,
    "textnya": "Welcome to our Group Dear .... Enjoy!",
}
lvin = {
    "lMessage": False,
    "textnya": "Take Care, Bye!",
}
gjoin = {
    "jMessage": True,
    "textnya": "Thanks for Inviting me",
}
ProfileMe = {
    "myProfile": {
        "coverId": "",
        "pictureStatus": "",
        "statusMessage": ""
    },
    "PictureMe": "",
    "NameMe": "",
}
ownerData = {
    "licon":{},
    "sendvirus":"karona",
    "purge": "kickbans",
    "nuke": "nukeit",
    "cleanse": "cleathis",
    "invitebots": "botsin",
    "kicktargets": "outofhere",
    "takegroup": "mygroup",
}
gwcool = {
    "squad": "TEMP",
}
gwcool1 = {
    "squad": "🙄",
}
gwcool2 = {
    "squad": "🙄",
}
gwcool3 = {
    "squad": "🙄",
}
gwcool4 = {
    "squad": "😭",
}
gwcool5 = {
    "squad": "🙄",
}
gwcool6 = {
    "squad": "🙄",
}
gwcool7 = {
    "squad": "🙄",
}
gwcool10 = {
    "squad": "Hi! Join call please ...",
}
tempcolor = {
    "color": "#E490E0",
}
tempfont = {
    "font": "#Ffcc00",
}
tempborder = {
    "border": "#C70039",
}
wstckr = {
    "sticker": {
        "status": False,
        "sender": [],
        "ver": "1",
        "stkid": "2754653",
        "pkgid": "1066653",
    },
    "PictureMe": "",
    "NameMe": "",
}
dstckr = {
    "sticker": {
        "status": False,
        "sender": [],
        "ver": "1",
        "stkid": "2754653",
        "pkgid": "1066653",
    },
    "PictureMe": "",
    "NameMe": "",
}
lstckr = {
    "sticker": {
        "status": False,
        "sender": [],
        "ver": "1",
        "stkid": "2754653",
        "pkgid": "1066653",
    },
    "PictureMe": "",
    "NameMe": "",
}
sets = {
    "tagsticker": False,
    "addStickerz": {
        "name": "",
        "status": False,
    },
    "messageStickerz": {
        "addNamez": "",
        "addStatusz": False,
        "listStickerz": {
            "responSticker": {
                "STKID": "",
                "STKPKGID": "",
                "STKVER": ""
            },
        }
    },
}
waitgroup = {
    "silentGroup":{},
    "remotGroup": "",
    "cmd": ""
}
#=====================================================================
settings["myProfile"]["displayName"] = noobcoderProfile.displayName
settings["myProfile"]["statusMessage"] = noobcoderProfile.statusMessage
settings["myProfile"]["pictureStatus"] = noobcoderProfile.pictureStatus
cont = noobcoder.getContact(noobcoderMID)
settings["myProfile"]["videoProfile"] = cont.videoProfile
coverId = noobcoder.getProfileDetail()["result"]["objectId"]
settings["myProfile"]["coverId"] = coverId
ProfileMe["myProfile"]["statusMessage"] = noobcoderProfile.statusMessage
ProfileMe["myProfile"]["pictureStatus"] = noobcoderProfile.pictureStatus
coverId = noobcoder.getProfileDetail()["result"]["objectId"]
ProfileMe["myProfile"]["coverId"] = coverId
#=====================================================================
with open("temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu
#=====================================================================
admins = wait["admins"]
bots = wait["bots"]
banlist = wait["blacklist"]
whitelist = wait["whitelist"]
enemies = wait["enemies"]
invitelist = wait["invitelist"]
#=====================================================================
def delBlocklist(tar="all"):
    try:
        global blockInvite
        if tar == "all":
            blockInvite = []
        else:
            blockInvite.remove(blockInvite[int(tar) - 1])
    except Exception as error:
        logError(error)
def delNotelist(tar="all"):
    try:
        global notegroup
        if tar == "all":
            notegroup = []
        else:
            notegroup.remove(notegroup[int(tar) - 1])
    except Exception as error:
        logError(error)
def delGnamelist(tar="all"):
    try:
        global groupName
        if tar == "all":
            groupName = []
        else:
            groupName.remove(groupName[int(tar) - 1])
    except Exception as error:
        logError(error)
def delQrlist(tar="all"):
    try:
        global groupQr
        if tar == "all":
            groupQr = []
        else:
            groupQr.remove(groupQr[int(tar) - 1])
    except Exception as error:
        logError(error)
def delKicklist(tar="all"):
    try:
        global protectKick
        if tar == "all":
            protectKick = []
        else:
            protectKick.remove(protectKick[int(tar) - 1])
    except Exception as error:
        logError(error)
def delNotelist(tar="all"):
    try:
        global notegroup
        if tar == "all":
            notegroup = []
        else:
            notegroup.remove(notegroup[int(tar) - 1])
    except Exception as error:
        logError(error)
def delNotaglist(tar="all"):
    try:
        global notag
        if tar == "all":
            notag = []
        else:
            notag.remove(notag[int(tar) - 1])
    except Exception as error:
        logError(error)
def inSteals(from_):
    global steals
    if from_ in steals:
        return True
    return False
def appendSteals(from_):
    try:
        global steals
        if from_ in steals:
            return
        return steals.append(from_)
    except:
        return False
def clearSteals():
    global steals
    steals = []
    return
#=====================================================================
def entod_in(to, mid):
    try:
        noobcoder.kickoutFromGroup(to, [mid])
        noobcoder.findAndAddContactsByMid(mid)
        noobcoder.inviteIntoGroup(to, [mid])
        noobcoder.cancelGroupInvitation(to,[mid])
    except Exception as e:
        print(e)

# Template Functions
lifflist = ["1602687308-GXq4Vvk9", "1656199698-gYJaDxdJ","1656613356-bJm9z8x6","1656086034-5De9BMoq", "1656162526-ZKWnYxzv"]

def allowLiff(ch_id):
    # Copyright by https://github.com/RynKings
    data = {'on': ['P', 'CM'], 'off': []}
    headers = {
        'X-Line-Access': noobcoder.authToken,
        'X-Line-Application': noobcoder.appName,
        'X-Line-ChannelId': ch_id,
        'Content-Type': 'application/json'
    }
    r = requests.post("https://access.line.me/dialog/api/permissions", headers=headers, data=json.dumps(data))
    return r.json()

def sendTemplate(to, data):
    random.shuffle(lifflist)
    for liffs in lifflist:
        try:
            xyz = LiffChatContext(to)
            xyzz = LiffContext(chat=xyz)
            view = LiffViewRequest(liffs, xyzz)
            try:token = noobcoder.liff.issueLiffView(view).accessToken
            except Exception as e:
                if "consent" in str(e).lower():
                    allowLiff(liffs.split("-")[0])
                    token = noobcoder.liff.issueLiffView(view).accessToken
                else:noobcoder.sendMessage(to,str(e));break

            url = 'https://api.line.me/message/v3/share'
            headers = {
                'Authorization': 'Bearer %s' % token,
                'Accept' : 'application/json, text/plain, */*',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 9; Redmi Note 6 Pro Build/PKQ1.180904.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.71 Mobile Safari/537.36 Line/11.9.0',
                'Accept-Encoding': 'gzip, deflate',
                'content-Type': 'application/json',
                'X-Requested-With': 'jp.naver.line.android'
            }
            data = {"messages":[data]}

            r = requests.post(url, headers=headers, data=json.dumps(data))
            #print(r.text)
            time.sleep(random.randint(700, 1000) / 1000)
            if "blocked" not in r.text.lower():
                #print(liffs + " : " + r.text)
                break

        except Exception as e:
            traceback.print_tb(e.__traceback__)
            logError(e)
            break

def sendflex(to, data):sendTemplate(to, data)
def bcTemplate(to, data):sendTemplate(to, data)
def bcTemplate2(to, data):sendTemplate(to, data)
def sendCarousel(to, data):sendTemplate(to, data)

def picFinder(name):    
        try:
            rgram = requests.get('http://www.instagram.com/{}'.format(name))
            rgram.raise_for_status()
            selenaSoup=BeautifulSoup(rgram.text,'html.parser')
            pageJS = selenaSoup.select('script')
            for i, j in enumerate(pageJS):
                pageJS[i]=str(j)
            picInfo = sorted(pageJS,key=len, reverse=True)[0]
            allPics = json.loads(str(picInfo)[52:-10])['entry_data']['ProfilePage'][0]
            return allPics
        except requests.exceptions.HTTPError:
            return '\t \t ### ACCOUNT MISSING ###'
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d d %02d h %02d m %02d s' % (days, hours, mins, secs)
def ClonerV2(to):
    try:
        contact = noobcoder.getContact(to)
        profile = noobcoder.profile
        profileName = noobcoder.profile
        profileStatus = noobcoder.profile
        profileName.displayName = contact.displayName
        profileStatus.statusMessage = contact.statusMessage
        noobcoder.updateProfile(profileName)
        noobcoder.updateProfile(profileStatus)
        profile.pictureStatus = noobcoder.downloadFileURL('https://obs.line-scdn.net/{}'.format(contact.pictureStatus, 'path'))
        if noobcoder.getProfileCoverId(to) is not None:
            noobcoder.updateProfileCoverById(noobcoder.getProfileCoverId(to))
        noobcoder.updateProfilePicture(profile.pictureStatus)
        print("Success Clone Profile {}".format(contact.displayName))
        return noobcoder.updateProfile(profile)
        if contact.videoProfile == None:
            return "Get Video Profile"
        path2 = "https://obs.line-scdn.net/" + profile.pictureStatus
        noobcoder.updateProfilePicture(path2, 'vp')
    except Exception as error:
        print(error)
def timeChange(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weeks, days = divmod(days,7)
    months, weeks = divmod(weeks,4)
    text = ""
    if months != 0: text += "%02d Month" % (months)
    if weeks != 0: text += " %02d Week" % (weeks)
    if days != 0: text += " %02d Days" % (days)
    if hours !=  0: text +=  " %02d Hours" % (hours)
    if mins != 0: text += " %02d Minutes" % (mins)
    if secs != 0: text += " %02d Seconds" % (secs)
    if text[0] == " ":
        text = text[1:]
    return text
#=====================================================================
# TEMPLATES
# TEMPLATES NEU
#=====================================================================
def getTimeLine(to, mid):
        data = noobcoder.getHomeProfile(mid)
        if data['result'] != []:
            try:
                no = 1
                a = " 「 Timeline 」\nCreated by : @!"#+str(data['result']['homeInfo']['userInfo']['nickname'])
                for i in data['result']['feeds']:
                    gtime = i['post']['postInfo']['createdTime']
                    timeCreated = []
                    timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(gtime) / 1000)))
                    try:
                        desc ="\n\n" + str(no) + ". Text : "+str(i['post']['contents']['text'])
                    except:
                        desc ="\n\n" + str(no) + ". Text : None"
                    a += str(desc)
                    a +="\n    Total Like : "+str(i['post']['postInfo']['likeCount'])
                    a +="\n    Total Comment : "+str(i['post']['postInfo']['commentCount'])
                    a +="\n    Created on : "+str(timeCreated[0])+"\n"
                    no = (no+1)
                a +="\n\nTotal Post : "+str(data['result']['homeInfo']['postCount'])+" Post."
                return mentions(to,str(a), [mid])
            except:
                return mentions(to, "@! not have timeline", [mid])
def sendMention(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@HOOKZGans"
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'「 Admin -23 」', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getProfile().picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def sendMention2(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
def youtubeMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output TeamAnuBot.mp3 {}'.format(link))
    try:
        noobcoder.sendAudio(to, 'TeamAnuBot.mp3')
        time.sleep(2)
        os.remove('TeamAnuBot.mp3')
    except Exception as e:
        TBotMessage(to, "Error")
def fileYtMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output FileYoutube.mp4 {}'.format(link))
    try:
        noobcoder.sendFile(to, "FileYoutube.mp4")
        time.sleep(2)
        os.remove('FileYoutube.mp4')
    except Exception as e:
        TBotMessage(to, ' 「 ERROR 」')
def fileYtMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output FileYoutube.mp3 {}'.format(link))
    try:
        noobcoder.sendFile(to, 'FileYoutube.mp3')
        time.sleep(2)
        os.remove('FileYoutube.mp3')
    except Exception as e:
        TBotMessage(to, ' 「 ERROR 」')
def sendMentionFooter(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@LopeAgri"
        slen = str(len(text))
        elen = str(len(text) + len(mention))
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        nama = "{}".format(noobcoder.getContact(noobcoderMID).displayName)
        img = "http://dl.profile.line-cdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
        ticket = "https://line.me/ti/p/{}".format(noobcoder.getUserTicket().id)
        noobcoder.sendMessage(to, text, {'AGENT_LINK': ticket, 'AGENT_ICON': img, 'AGENT_NAME': nama, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        noobcoder.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def NoteCreate(to,cmd,msg):
    h = []
    s = []
    if cmd == 'mentionnote':
        sakui = noobcoder.getProfile()
        group = noobcoder.getGroup(msg.to);nama = [contact.mid+'||//{}'.format(contact.displayName) for contact in group.members];nama.remove(sakui.mid+'||//{}'.format(sakui.displayName))
        data = nama
        k = len(data)//20
        for aa in range(k+1):
            nos = 0
            if aa == 0:dd = '╭「 Mention Note 」─';no=aa
            else:dd = '├「 Mention Note 」─';no=aa*20
            msgas = dd
            for i in data[aa*20 : (aa+1)*20]:
                no+=1
                if no == len(data):msgas+='\n╰{}. @'.format(no)
                else:msgas+='\n│{}. @'.format(no)
            msgas = msgas
            for i in data[aa*20 : (aa+1)*20]:
                gg = []
                dd = ''
                for ss in msgas:
                    if ss == '@':
                        dd += str(ss)
                        gg.append(dd.index('@'))
                        dd = dd.replace('@',' ')
                    else:
                        dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[nos], 'end': gg[nos]+1, 'mid': str(i.split('||//')[0])})
                nos +=1
            h = noobcoder.createPostGroup(msgas,msg.to,holdingTime=None,textMeta=s)
    else:
        cmd = cmd.replace(msg.text[:12],'')
        if 'MENTION' in msg.contentMetadata.keys()!= None:
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            no = 0
            for mention in mentionees:
                ask = no
                nama = str(noobcoder.getContact(mention["M"]))
                h.append(str(cmd.replace('@{}'.format(nama),'@')))
                for b in h:
                    cmd = str(b)
                gg = []
                dd = ''
                for ss in cmd:
                    if ss == '@':
                        dd += str(ss)
                        gg.append(dd.index('@'))
                        dd = dd.replace('@',' ')
                    else:
                        dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[no], 'end': gg[no]+1, 'mid': str(mention["M"])})
                no +=1
        h = noobcoder.createPostGroup(cmd,msg.to,holdingTime=None,textMeta=s)
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@NEO-STORE  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def mention(self,msg,targets):
    if msg.mentionees:
        for mention in msg.mentionees:
            targets.append(mention)
def load():
    global images
    global stickers
    with open("image.json","r") as fp:
        images = json.load(fp)
    with open("sticker.json","r") as fp:
        stickers = json.load(fp)
def sendStickerz(to, version, packageId, stickerId):
    contentMetadata = {
        'STKVER': version,
        'STKPKGID': packageId,
        'STKID': stickerId
    }
    noobcoder.sendMessage(to, '', contentMetadata, 7)
def sendStickers(to, sver, spkg, sid):
    contentMetadata = {
        'STKVER': sver,
        'STKPKGID': spkg,
        'STKID': sid
    }
    noobcoder.sendMessage(to, '', contentMetadata, 7)
def sendSticker(to, mid, sver, spkg, sid):
    contentMetadata = {
        'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,
        'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact(mid).pictureStatus,
        'STKVER': sver,
        'STKPKGID': spkg,
        'STKID': sid
    }
    noobcoder.sendMessage(to, '', contentMetadata, 7)
def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            noobcoder.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)
#=====================================================================
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = noobcoder.genOBSParams({'oid': noobcoderMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        noobcoder.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("FadhilvanHalen.mp4")
def changeProfileVideo(to):
    if settings['changeProfileVideo']['picture'] == None:
        return TBotMessage(to, "Foto tidak ditemukan")
    elif settings['changeProfileVideo']['video'] == None:
        return TBotMessage(to, "Video tidak ditemukan")
    else:
        path = settings['changeProfileVideo']['video']
        files = {'file': open(path, 'rb')}
        obs_params = noobcoder.genOBSParams({'oid': noobcoder.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return TBotMessage(to, "Gagal update profile")
        path_p = settings['changeProfileVideo']['picture']
        settings['changeProfileVideo']['status'] = False
        noobcoder.updateProfilePicture(path_p, 'vp')
def backProfileVideo():
    path = settings['changeProfileVideo']['video']
    files = {'file': open(path, 'rb')}
    obs_params = noobcoder.genOBSParams({'oid': noobcoder.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
    data = {'params': obs_params }
    r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
    if r_vp.status_code != 201:
        return TBotMessage(to, "Failed")
    path_p = settings['changeProfileVideo']['picture']
    noobcoder.updateProfilePicture(path_p, 'vp')
def cytmp4(to,url):
    import pafy
    vid = pafy.new(url,basic=False)
    result = vid.streams[-1]
    return result.url
    links = cytmp4(anunya);links = 'https://'+noobcoder.google_url_shorten(links)
def pendekin(to,url):
    req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
    payload = {'longUrl': url}
    headers = {'content-type': 'application/json'}
    r = requests.post(req_url, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    return resp['id']
def cloneProfile(mid):
    contact = noobcoder.getContact(mid)
    if contact.videoProfile == None:
        noobcoder.cloneContactProfile(mid)
    else:
        profile = noobcoder.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        noobcoder.updateProfile(profile)
        pict = noobcoder.downloadFileURL('https://obs.line-scdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = noobcoder.downloadFileURL( 'https://obs.line-scdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = noobcoder.getProfileDetail(mid)['result']['objectId']
    noobcoder.updateProfileCoverById(coverId)
def backupProfile():
    profile = noobcoder.getContact(noobcoderMID)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = noobcoder.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)
def reTeamProfile():
    profile = noobcoder.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        noobcoder.updateProfileAttribute(8, profile.pictureStatus)
        noobcoder.updateProfile(profile)
    else:
        noobcoder.updateProfile(profile)
        pict = noobcoder.downloadFileURL('https://obs.line-scdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = noobcoder.downloadFileURL( 'https://obs.line-scdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    noobcoder.updateProfileCoverById(coverId)
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)
def change(url):
    import base64
    return base64.b64encode(url.encode()).decode()
def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        nooobcoder.sendMessage(to, textx, {'MSG_SENDER_NAME': noobcoder.getContact(ps).displayName,'MSG_SENDER_ICON': "https://obs.line-scdn.net/" + noobcoder.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================                                
        if op.type == 26:
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = msg.text
            msg_id = msg.id
            msg.from_ = msg._from
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
                if msg.toType == 0:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 13:
                    if settings["contact"] == True:
                      msg.contentType = 0
                      nooobcoder.sendMessage(msg.to,msg.contentMetadata["mid"])
                      if 'displayName' in msg.contentMetadata:
                          contact = nooobcoder.getContact(msg.contentMetadata["mid"])
                          path = nooobcoder.getContact(msg.contentMetadata["mid"]).picturePath
                          image = 'http://dl.profile.line.naver.jp'+path
                          nooobcoder.sendMessage(msg.to," Nama : " + msg.contentMetadata["displayName"] + "\n MID : " + msg.contentMetadata["mid"] + "\n Status Msg : " + contact.statusMessage + "\n Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                          nooobcoder.sendImageWithURL(msg.to, image)
#=====================================================================
def youtubeMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
    try:
        noobcoder.sendVideo(to, "TeamAnuBot.mp4")
        time.sleep(2)
        os.remove('TeamAnuBot.mp4')
    except Exception as e:
        TBotMessage(to, "Error")
def autoresponuy(to,msg,wait):
    to = msg.to
    if msg.to not in wait["GROUP"]['AR']['AP']:
        return
    if msg.to in wait["GROUP"]['AR']['S']:
        TBotMessage(msg.to,text=None,contentMetadata=wait["GROUP"]['AR']['S'][msg.to]['Sticker'], contentType=7)
    if(wait["GROUP"]['AR']['P'][msg.to] in [""," ","\n",None]):
        return
    if '@!' not in wait["GROUP"]['AR']['P'][msg.to]:
        wait["GROUP"]['AR']['P'][msg.to] = '@!'+wait["GROUP"]['AR']['P'][msg.to]
    nama = noobcoder.getGroup(msg.to).name
    sd = noobcoder.waktunjir()
    noobcoder.sendMention(msg.to,wait["GROUP"]['AR']['P'][msg.to].replace('greeting',sd).replace(';',nama),'',[msg._from]*wait["GROUP"]['AR']['P'][msg.to].count('@!'))
def anulurk(to, wait):
    moneys = {}
    for a in wait["setTime"][to].items():
        moneys[a[1]] = [a[0]] if a[1] is not None else idnya
    sort = sorted(moneys)
    sort = sort[0:]
    k = len(sort)//100
    for a in range(k+1):
        if a == 0:no= a;msgas = '╭「 Lurkers 」─'
        else:no = a*100;msgas = '├「 Lurkers 」─'
        h = []
        for i in sort[a*100 : (a+1)*100]:
            h.append(moneys[i][0])
            no+=1
            a = '{}'.format(humanize.naturaltime(datetime.fromtimestamp(i/1000)))
            if no == len(sort):msgas+='\n│{}. @!\n╰    「 {} 」'.format(no,a)
            else:msgas+='\n│{}. @!\n│    「 {} 」'.format(no,a)
        mentions(to, msgas, h)
#=====================================================================
def anunanu(to,s,wait,j=''):
    try:
        if j == '':
            data = {"messages": [{"type": "image","originalContentUrl": s,"previewImageUrl": s,"sentBy":{"label":"{}".format(noobcoder.getContact(noobcoderMID).displayName),"iconUrl":"https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),"linkUrl":""}}]}
        else:
            data = {"messages": [{"type": "image","originalContentUrl": s,"previewImageUrl": s,"animated":True,"extension":"gif","sentBy":{"label":"{}".format(noobcoder.getContact(noobcoderMID).displayName),"iconUrl":"https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),"linkUrl":""}}]}
        sendCarousel(to,data)
    except Exception as e:
        print(e)
def anuanu(to,s,wait,j=''):
    try:
        if j == '':
            data = {"messages": [{"type": "video","originalContentUrl": s,"previewImageUrl": s}]}
        else:
            data = {"messages": [{"type": "video","originalContentUrl": s,"previewImageUrl": s}]}
        sendCarousel(to,data)
    except Exception as e:
        print(e)
#=====================================================================
def logError(text):
    noobcoder.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
def cloneProfile(mid):
    contact = noobcoder.getContact(mid)
    if contact.videoProfile == None:
        noobcoder.cloneContactProfile(mid)
    else:
        profile = noobcoder.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        noobcoder.updateProfile(profile)
        pict = noobcoder.downloadFileURL('https://obs.line-scdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = noobcoder.downloadFileURL( 'https://obs.line-scdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = noobcoder.getProfileDetail(mid)['result']['objectId']
    noobcoder.updateProfileCoverById(coverId)
def backupProfile():
    profile = noobcoder.getContact(noobcoderMID)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = noobcoder.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)
def reTeamProfile():
    profile = noobcoder.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        noobcoder.updateProfileAttribute(8, profile.pictureStatus)
        noobcoder.updateProfile(profile)
    else:
        noobcoder.updateProfile(profile)
        pict = noobcoder.downloadFileURL('https://obs.line-scdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = noobcoder.downloadFileURL( 'https://obs.line-scdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    noobcoder.updateProfileCoverById(coverId)
#=====================================================================
def speedTestSelfbot():
    get_profile_time_start = time.time()
    get_profile = noobcoder.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_group_time_start = time.time()
    get_group = noobcoder.getGroupIdsJoined()
    get_group_time = time.time() - get_group_time_start
    get_contact_time_start = time.time()
    get_contact = noobcoder.getContact(get_profile.mid)
    get_contact_time = time.time() - get_contact_time_start
    elapsed_time = time.time() - get_profile_time_start
    return "𝗦𝗘𝗟𝗙𝗕𝗢𝗧 𝗦𝗣𝗘𝗘𝗗\n\nMessage:        %.5f\nGet Profile:     %.5f\nGet Contact:   %.5f\nGet Group:      %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time)
#=====================================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
#=====================================================================
def removeCmd(cmd, text):
    key = settings["keyCommand"]
    if settings["setKey"] == False: key = ''
    rmv = len(key + cmd) + 1
    return text[rmv:]
def helpown():
    key = settings["keyCommand"]
    key = key.title()
    if settings['setKey'] == False: key = ''
    helpOwn = "Premium Selfbot" + "\n\n" + \
                  "Command's :" + "\n\n" + \
                  "Use「" + key + "」to Prefix" + "\n\n" + \
                  "" + key + "logout" + "\n" + \
                  "" + key + "Runtime" + "\n" + \
                  "" + key + "Clearban"
    return helpOwn
def remoteText(grup):
    if waitgroup["remotGroup"] == "":
        return
    else:
        waitgroup["remotGroup"] = ""
        waitgroup["cmd"] = ""
#=====================================================================
# Put JSONS in Backup here
def backupData():
    try:
        backup = settings
        f = codecs.open('temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickers
        f = codecs.open('sticker.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = images
        f = codecs.open('image.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = stickers2
        f = codecs.open('sticker2.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
#=====================================================================
Customer = {
    "makerName": "Eric",
    "makerTextLogo": "Eric",
    "makerMark": "Eric",
    "makerFlag": "Eric",
    "makerLineid" :"https://line.me/ti/p/~j71.a",
    "makerMid" : "https://line://nv/profilePopup/mid=u9b9897fdd536e9886a4b7c28def482cf",
    "userFlag" : "Eric",
}
#=====================================================================
# Ladies Colors
# Grey: #708090
# Biege: #FFF8DC
# Pink: #FF1493
Colors = {
    "LogoBack": "#000000",       # Colors["LogoBack"],
    "LogoFont": "#5C493F",       # Colors["LogoFont"],
    "Template": "#708090",       # Colors["Template"],
    "Background": "#DAA520",     # Colors["Background"] + Colors["Transparency"],
    "Border": "#00FFFF",         # Colors["Border"],
    "Liner": "#00FFFF",          # Colors["Liner"],
    "Heading": "#FFCCAA",        # Colors["Heading"],
    "Font": "#FFF8DC",           # Colors["Font"],
    "Transparency": "CC"         # Colors["Transparency"],
}
textMainHelp ="""
 𝗛𝗘𝗟𝗣 𝗠𝗘𝗡𝗨
 _____________

 ☞  mybot           
 ☞  myself
 ☞  profile           
 ☞  settings
 ☞  themes           
 ☞  information
 ☞  group            
 ☞  parameters
 ☞  kicking           
 ☞  banning
 ☞  protection     
 ☞  war
 ☞  friends          
 ☞  broadcast
 ☞  mention          
 ☞  media  
 ☞  stickers          
 ☞  giflist"""
# Final Templates
def TtempMainHelp(to):
    true = True
    false = False
    data={"type":"flex","altText":"{}".format(Customer["makerName"]),"contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "kilo",
                    "body": {
                        "backgroundColor": Colors["Background"],
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://obs.line-scdn.net",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:2.73",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂",
                                                "size": "md",
                                                "align": "center",
                                                "color": Colors["Font"],
                                                "weight": "regular"
                                            }
                                        ]
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "spacer",
                                                "size": "md"
                                            },
                                            {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Mybot",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=myself"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Myself",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=profile"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Profile",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=steal"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Settings",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=mention"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Themes",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=group"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Group",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=protect"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Information",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=newlist"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Kicking",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=stickers"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Banning",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=friend"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    }
                                                ],
                                                "borderColor": Colors["Font"],
                                                "cornerRadius": "10px",
                                                "borderWidth": "1.5px"
                                            }
                                        ]
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "paddingAll": "20px",
                                "paddingTop": "18px",
                                "offsetTop": "145px"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "image",
                                        "url": "https://obs.line-scdn.net/" + noobcoder.profile.pictureStatus,
                                        "size": "full",
                                        "aspectMode": "cover",
                                        "aspectRatio": "2:3",
                                        "action": {
                                            "type": "uri",
                                            "uri": "https://line.me/ti/p/~Adiich1122"
                                        }
                                    }
                                ],
                                "position": "absolute",
                                "offsetTop": "20px",
                                "height": "135px",
                                "width": "135px",
                                "borderWidth": "1.5px",
                                "borderColor": Colors["Font"],
                                "cornerRadius": "10px",
                                "offsetStart": "60px"
                            }
                        ],
                        "paddingAll": "0px",
                        "cornerRadius": "10px",
                        "borderColor": Colors["Font"],
                        "borderWidth": "1.5px"
                    }
                },
                {
                    "type": "bubble",
                    "size": "kilo",
                    "body": {
                        "backgroundColor": Colors["Background"],
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://obs.line-scdn.net",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:2.73",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂",
                                                "size": "md",
                                                "align": "center",
                                                "color": Colors["Font"],
                                                "weight": "regular"
                                            }
                                        ]
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "spacer",
                                                "size": "md"
                                            },
                                            {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Protection",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=myself"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Friends",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=profile"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Broadcast",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=steal"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Mention",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=mention"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "War",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=group"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Media",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=protect"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Stickers",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=newlist"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Giflist",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=stickers"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Parameters",
                                                                "size": "xs",
                                                                "color": Colors["Font"],
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=friend"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    }
                                                ],
                                                "borderColor": Colors["Font"],
                                                "cornerRadius": "10px",
                                                "borderWidth": "1.5px"
                                            }
                                        ]
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "paddingAll": "20px",
                                "paddingTop": "18px",
                                "offsetTop": "145px"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "image",
                                        "url": "https://obs.line-scdn.net/" + noobcoder.profile.pictureStatus,
                                        "size": "full",
                                        "aspectMode": "cover",
                                        "aspectRatio": "2:3",
                                        "action": {
                                            "type": "uri",
                                            "uri": "https://line.me/ti/p/~Adiich1122"
                                        }
                                    }
                                ],
                                "position": "absolute",
                                "offsetTop": "20px",
                                "height": "135px",
                                "width": "135px",
                                "borderWidth": "1.5px",
                                "borderColor": Colors["Font"],
                                "cornerRadius": "10px",
                                "offsetStart": "60px"
                            }
                        ],
                        "paddingAll": "0px",
                        "cornerRadius": "10px",
                        "borderColor": Colors["Font"],
                        "borderWidth": "1.5px"
                    }
                }
            ]
        }
          }
    sendTemplate(to,data)
def TtempListMenu(to, heading, menulist):
    true = True
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "micro",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": Colors["Font"],
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "135px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "text": heading,
                                "size": "md",
                                "align": "center",
                                "color": Colors["Font"],
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "135px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "contents": [
                                    {
                                        "text": menulist,
                                        "size": "xs",
                                        "margin": "none",
                                        "color": Colors["Font"],
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                },
                "footer": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
                   }
    sendTemplate(to, data)
####
# List 20 Text
def list20WithHeading(to,text1,text2,jembut):
    num = 0
    tot = {}
    for mid in jembut:
        tot[mid] = True
        if 20 == len(tot):
            tx = "{}\n\n".format(text1)
            for a in tot:
                num += 1
                tx += "{}. {}\n".format(num, noobcoder.getContact(a).displayName)
            tot = {}
            noobcoder.sendMessage(to,tx)
    jem = "{}\n\n".format(text1)
    for a in tot:
        num += 1
        jem += "{}. {}\n".format(num, noobcoder.getContact(a).displayName)
    return noobcoder.sendMessage(to, jem+"\nTotal {}: {}".format(text2,len(jembut)))
# List 20 Template
def Tlist20WithHeading(to,text1,text2,jembut):
    num = 0
    tot = {}
    for mid in jembut:
        tot[mid] = True
        if 20 == len(tot):
            tx = ""
            for a in tot:
                num += 1
                tx += "{}. {}\n".format(num, noobcoder.getContact(a).displayName)
            tot = {}
            TlistwithHeader(to, text1, tx)
    jem = ""
    for a in tot:
        num += 1
        jem += "{}. {}\n".format(num, noobcoder.getContact(a).displayName)
    return TlistwithHeader(to, text1, jem+"\nTotal {}: {}".format(text2,len(jembut)))
def TlistwithHeader(to, heading, listtwenty):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "micro",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": Colors["Font"],
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "135px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "text": heading,
                                "size": "md",
                                "align": "center",
                                "color": Colors["Font"],
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "135px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "contents": [
                                    {
                                        "text": listtwenty,
                                        "size": "xs",
                                        "margin": "none",
                                        "color": Colors["Font"],
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                },
                "footer": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
                   }
    sendTemplate(to, data)
#
def TBotMessage(to, message):
    true = True
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                            {
                                "type": "text",
                                "text": message,
                                "size": "sm",
                                "wrap": true,
                                "align": "center",
                                "color": Colors["Font"],
                                "action": {
                                    "type": "uri",
                                    "uri": Customer["makerLineid"]
                                }
                            }
                        ],
                        "margin": "xs",
                        "spacing": "xs",
                        "backgroundColor": Colors["Background"]
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": Customer["userFlag"],
                                "align": "center",
                                "color": Colors["Font"],
                                "size": "xs",
                                "action": {
                                    "type": "uri",
                                    "uri": Customer["makerLineid"]
                                }
                            }
                        ],
                        "paddingAll": "0px",
                        "backgroundColor": Colors["Template"]
                    }
                ],
                "paddingAll": "0px",
                "borderWidth": "1.5px",
                "borderColor": Colors["Font"],
                "cornerRadius": "10px",
                "spacing": "xs"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
                   }
    sendTemplate(to, data)
def TBotMessageWithHeaderFooter(to, heading, message):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "micro",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": Colors["Font"],
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "135px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "text": heading,
                                "size": "md",
                                "align": "center",
                                "color": Colors["Font"],
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "135px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "contents": [
                                    {
                                        "text": message,
                                        "size": "xs",
                                        "margin": "none",
                                        "color": Colors["Font"],
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                },
                "footer": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
                   }
    sendTemplate(to, data)
def TBotMessageWithHeader(to, heading, message):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "micro",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": Colors["Font"],
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "135px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "text": heading,
                                "size": "md",
                                "align": "center",
                                "color": Colors["Font"],
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "135px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "contents": [
                                    {
                                        "text": message,
                                        "size": "xs",
                                        "margin": "none",
                                        "color": Colors["Font"],
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                },
                "footer": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
                   }
    sendTemplate(to, data)
def TBotMessageWithFooter(to, message):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                            {
                                "type": "text",
                                "text": message,
                                "size": "sm",
                                "wrap": true,
                                "align": "center",
                                "color": Colors["Font"],
                                "action": {
                                    "type": "uri",
                                    "uri": Customer["makerLineid"]
                                }
                            }
                        ],
                        "margin": "xs",
                        "spacing": "xs",
                        "backgroundColor": Colors["Background"]
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": Customer["userFlag"],
                                "align": "center",
                                "color": Colors["Font"],
                                "size": "xs",
                                "action": {
                                    "type": "uri",
                                    "uri": Customer["makerLineid"]
                                }
                            }
                        ],
                        "paddingAll": "0px",
                        "backgroundColor": Colors["Template"]
                    }
                ],
                "paddingAll": "0px",
                "borderWidth": "1.5px",
                "borderColor": Colors["Font"],
                "cornerRadius": "10px",
                "spacing": "xs"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
                   }
    sendTemplate(to, data)
# Siders
def twlcom(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "kilo",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "20:23",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/01_1_cafe.png",
                                                "size": "full",
                                                "aspectMode": "cover"
                                            }
                                        ],
                                        "position": "absolute",
                                        "flex": 0,
                                        "borderWidth": "1.5px",
                                        "cornerRadius": "10px",
                                        "borderColor": "#FFFFFF",
                                        "width": "90px",
                                        "height": "90px",
                                        "offsetTop": "70px",
                                        "offsetStart": "22px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/01_1_cafe.png",
                                                "size": "full",
                                                "aspectMode": "cover"
                                            }
                                        ],
                                        "position": "absolute",
                                        "flex": 0,
                                        "borderWidth": "1.5px",
                                        "cornerRadius": "10px",
                                        "borderColor": "#FFFFFF",
                                        "width": "90px",
                                        "height": "90px",
                                        "offsetTop": "70px",
                                        "offsetStart": "142px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "Member Name 12345678",
                                                "size": "md",
                                                "color": "#FFFFFF",
                                                "weight": "bold",
                                                "align": "center",
                                                "flex": 0,
                                                "gravity": "center"
                                            }
                                        ],
                                        "margin": "none",
                                        "position": "absolute",
                                        "offsetTop": "25px",
                                        "width": "220px",
                                        "offsetStart": "20px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "Liner",
                                                "color": "#FFFFFF"
                                            }
                                        ],
                                        "height": "1.5px",
                                        "backgroundColor": "#FFFFFF",
                                        "position": "absolute",
                                        "offsetTop": "50px",
                                        "flex": 0,
                                        "paddingAll": "0px",
                                        "width": "215px",
                                        "offsetStart": "20px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "color": "#FFFFFF",
                                                        "size": "15px",
                                                        "flex": 0,
                                                        "wrap": true,
                                                        "text": "Welcome Message",
                                                        "align": "center"
                                                    }
                                                ],
                                                "spacing": "md",
                                                "margin": "md",
                                                "width": "225px",
                                                "position": "relative",
                                                "offsetStart": "10px",
                                                "height": "80px"
                                            }
                                        ],
                                        "cornerRadius": "10px",
                                        "spacing": "sm",
                                        "margin": "xxl",
                                        "height": "100px",
                                        "position": "absolute",
                                        "width": "210px",
                                        "backgroundColor": "#2F4F4F",
                                        "offsetTop": "175px",
                                        "offsetStart": "22px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": "#000000CC",
                                "paddingAll": "20px",
                                "paddingTop": "18px",
                                "borderColor": "#000000CC",
                                "margin": "none",
                                "offsetTop": "0px"
                            }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "1.5px",
                        "cornerRadius": "10px",
                        "borderColor": "#FFFFFF"
                    }
                }
            ]
        }
            }
    sendTemplate(to, data)
def TtempSider101(to, readerpic, readername, readermessage):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": readerpic,
                                                "size": "full",
                                                "aspectMode": "cover",
                                                "aspectRatio": "2:3"
                                            }
                                        ],
                                        "width": "56px",
                                        "height": "61.5px",
                                        "borderWidth": "1.5px",
                                        "borderColor": Colors["Font"],
                                        "cornerRadius": "xl",
                                        "action": {
                                            "type": "uri",
                                            "uri": Customer["makerLineid"]
                                        }
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": readername,
                                                "weight": "bold",
                                                "size": "lg",
                                                "color": Colors["Font"],
                                                "align": "center"
                                            },
                                            {
                                                "type": "separator",
                                                "color": Colors["Font"],
                                                "margin": "sm"
                                            },
                                            {
                                                "type": "text",
                                                "text": readermessage,
                                                "size": "md",
                                                "margin": "md",
                                                "color": Colors["Font"],
                                                "align": "center",
                                                "wrap": true
                                            }
                                        ],
                                        "margin": "lg"
                                    }
                                ]
                            }
                        ],
                        "paddingAll": "5px",
                        "backgroundColor": Colors["Background"],
                        "borderWidth": "1.5px",
                        "borderColor": Colors["Font"],
                        "cornerRadius": "xl"
                    }
                ],
                "paddingAll": "0px"
            }
        }
                   }
    sendTemplate(to, data)
def TtempSider101giga(to, readerpic, readername, readermessage):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "giga",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": readerpic,
                                                "size": "full",
                                                "aspectMode": "cover",
                                                "aspectRatio": "2:3"
                                            }
                                        ],
                                        "width": "56px",
                                        "height": "61.5px",
                                        "borderWidth": "2px",
                                        "borderColor": Colors["Font"],
                                        "cornerRadius": "6px",
                                        "action": {
                                            "type": "uri",
                                            "uri": Customer["makerLineid"]
                                        }
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": readername,
                                                "weight": "bold",
                                                "size": "lg",
                                                "color": Colors["Font"],
                                                "align": "center"
                                            },
                                            {
                                                "type": "separator",
                                                "color": Colors["Border"],
                                                "margin": "sm"
                                            },
                                            {
                                                "type": "text",
                                                "text": readermessage,
                                                "size": "md",
                                                "margin": "md",
                                                "color": Colors["Font"],
                                                "align": "center",
                                                "wrap": true
                                            }
                                        ],
                                        "margin": "lg"
                                    }
                                ]
                            }
                        ],
                        "paddingAll": "5px",
                        "backgroundColor": Colors["Background"],
                        "borderWidth": "2px",
                        "borderColor": Colors["Border"],
                        "cornerRadius": "6px"
                    }
                ],
                "paddingAll": "0px"
            },
            "styles": {
                "footer": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
            }
    sendTemplate(to, data)
def TtempSider102(to, readerpic, readername, readermessage):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "mega",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": Colors["Border"],
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": readerpic,
                                "aspectMode": "cover"
                            }
                        ],
                        "position": "absolute",
                        "width": "70px",
                        "height": "70px",
                        "borderWidth": "1.5px",
                        "borderColor": Colors["Border"],
                        "cornerRadius": "100px",
                        "offsetTop": "10px",
                        "offsetStart": "10px"
                    },
                    {
                        "contents": [
                            {
                                "text": readername,
                                "size": "sm",
                                "align": "center",
                                "color": Colors["Font"],
                                "wrap": false,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical",
                        "offsetStart": "97px",
                        "width": "180px",
                        "offsetTop": "15px",
                        "position": "absolute"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Border"]
                            }
                        ],
                        "backgroundColor": Colors["Border"],
                        "width": "220px",
                        "height": "1.5px",
                        "offsetStart": "80px",
                        "offsetTop": "45px",
                        "position": "absolute"
                    },
                    {
                        "contents": [
                            {
                                "text": readermessage,
                                "size": "sm",
                                "margin": "none",
                                "color": Colors["Font"],
                                "wrap": false,
                                "weight": "regular",
                                "type": "text",
                                "align": "center"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical",
                        "width": "200px",
                        "height": "20px",
                        "offsetTop": "60px",
                        "offsetStart": "87px",
                        "position": "absolute"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical",
                "height": "95px"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                },
                "footer": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
                   }
    sendTemplate(to, data)
def TtempWelcomeMessage(to, readerpic, readername, readermessage, hostpic):
    true = True
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "kilo",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "20:23",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": hostpic,
                                                "size": "full",
                                                "aspectMode": "cover"
                                            }
                                        ],
                                        "position": "absolute",
                                        "flex": 0,
                                        "borderWidth": "1.5px",
                                        "cornerRadius": "10px",
                                        "borderColor": Colors["Font"],
                                        "width": "90px",
                                        "height": "90px",
                                        "offsetTop": "70px",
                                        "offsetStart": "22px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": readerpic,
                                                "size": "full",
                                                "aspectMode": "cover"
                                            }
                                        ],
                                        "position": "absolute",
                                        "flex": 0,
                                        "borderWidth": "1.5px",
                                        "cornerRadius": "10px",
                                        "borderColor": Colors["Font"],
                                        "width": "90px",
                                        "height": "90px",
                                        "offsetTop": "70px",
                                        "offsetStart": "142px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": readername,
                                                "size": "md",
                                                "color": Colors["Font"],
                                                "weight": "bold",
                                                "align": "center",
                                                "flex": 0,
                                                "gravity": "center"
                                            }
                                        ],
                                        "margin": "none",
                                        "position": "absolute",
                                        "offsetTop": "25px",
                                        "width": "220px",
                                        "offsetStart": "20px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "Liner",
                                                "color": Colors["Font"]
                                            }
                                        ],
                                        "height": "1.5px",
                                        "backgroundColor": Colors["Font"],
                                        "position": "absolute",
                                        "offsetTop": "50px",
                                        "flex": 0,
                                        "paddingAll": "0px",
                                        "width": "215px",
                                        "offsetStart": "20px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "color": Colors["Font"],
                                                        "size": "15px",
                                                        "flex": 0,
                                                        "wrap": true,
                                                        "text": readermessage,
                                                        "align": "center"
                                                    }
                                                ],
                                                "spacing": "md",
                                                "margin": "md",
                                                "width": "190px",
                                                "position": "relative",
                                                "offsetStart": "10px",
                                                "height": "80px"
                                            }
                                        ],
                                        "cornerRadius": "10px",
                                        "spacing": "sm",
                                        "margin": "xxl",
                                        "height": "100px",
                                        "position": "absolute",
                                        "width": "210px",
                                        "backgroundColor": Colors["Template"],
                                        "offsetTop": "175px",
                                        "offsetStart": "22px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": Colors["Background"],
                                "paddingAll": "20px",
                                "paddingTop": "18px",
                                "borderColor": Colors["Background"],
                                "margin": "none",
                                "offsetTop": "0px"
                            }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "1.5px",
                        "cornerRadius": "10px",
                        "borderColor": Colors["Font"]
                    }
                }
            ]
        }
                   }
    sendTemplate(to, data)
def TtempLeftMessage(to, readerpic, readername, readermessage, hostpic):
    true = True
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "kilo",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "20:23",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": hostpic,
                                                "size": "full",
                                                "aspectMode": "cover"
                                            }
                                        ],
                                        "position": "absolute",
                                        "flex": 0,
                                        "borderWidth": "1.5px",
                                        "cornerRadius": "10px",
                                        "borderColor": Colors["Font"],
                                        "width": "90px",
                                        "height": "90px",
                                        "offsetTop": "70px",
                                        "offsetStart": "22px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": readerpic,
                                                "size": "full",
                                                "aspectMode": "cover"
                                            }
                                        ],
                                        "position": "absolute",
                                        "flex": 0,
                                        "borderWidth": "1.5px",
                                        "cornerRadius": "10px",
                                        "borderColor": Colors["Font"],
                                        "width": "90px",
                                        "height": "90px",
                                        "offsetTop": "70px",
                                        "offsetStart": "142px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": readername,
                                                "size": "md",
                                                "color": Colors["Font"],
                                                "weight": "bold",
                                                "align": "center",
                                                "flex": 0,
                                                "gravity": "center"
                                            }
                                        ],
                                        "margin": "none",
                                        "position": "absolute",
                                        "offsetTop": "25px",
                                        "width": "220px",
                                        "offsetStart": "20px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "Liner",
                                                "color": Colors["Font"]
                                            }
                                        ],
                                        "height": "1.5px",
                                        "backgroundColor": Colors["Font"],
                                        "position": "absolute",
                                        "offsetTop": "50px",
                                        "flex": 0,
                                        "paddingAll": "0px",
                                        "width": "215px",
                                        "offsetStart": "20px"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "baseline",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "color": Colors["Font"],
                                                        "size": "15px",
                                                        "flex": 0,
                                                        "wrap": true,
                                                        "text": readermessage,
                                                        "align": "center"
                                                    }
                                                ],
                                                "spacing": "md",
                                                "margin": "md",
                                                "width": "190px",
                                                "position": "relative",
                                                "offsetStart": "10px",
                                                "height": "80px"
                                            }
                                        ],
                                        "cornerRadius": "10px",
                                        "spacing": "sm",
                                        "margin": "xxl",
                                        "height": "100px",
                                        "position": "absolute",
                                        "width": "210px",
                                        "backgroundColor": Colors["Template"],
                                        "offsetTop": "175px",
                                        "offsetStart": "22px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": Colors["Background"],
                                "paddingAll": "20px",
                                "paddingTop": "18px",
                                "borderColor": Colors["Background"],
                                "margin": "none",
                                "offsetTop": "0px"
                            }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "1.5px",
                        "cornerRadius": "10px",
                        "borderColor": Colors["Font"]
                    }
                }
            ]
        }
            }
    sendTemplate(to, data)
def TtempTagResponse(to, readerpic, readername, readermessage):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": readerpic,
                                                "size": "full",
                                                "aspectMode": "cover",
                                                "aspectRatio": "2:3"
                                            }
                                        ],
                                        "width": "56px",
                                        "height": "61.5px",
                                        "borderWidth": "1.5px",
                                        "borderColor": Colors["Font"],
                                        "cornerRadius": "xl",
                                        "action": {
                                            "type": "uri",
                                            "uri": Customer["makerLineid"]
                                        }
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": readername,
                                                "weight": "bold",
                                                "size": "lg",
                                                "color": Colors["Font"],
                                                "align": "center"
                                            },
                                            {
                                                "type": "separator",
                                                "color": Colors["Font"],
                                                "margin": "sm"
                                            },
                                            {
                                                "type": "text",
                                                "text": readermessage,
                                                "size": "md",
                                                "margin": "md",
                                                "color": Colors["Font"],
                                                "align": "center",
                                                "wrap": true
                                            }
                                        ],
                                        "margin": "lg"
                                    }
                                ]
                            }
                        ],
                        "paddingAll": "5px",
                        "backgroundColor": Colors["Background"],
                        "borderWidth": "1.5px",
                        "borderColor": Colors["Font"],
                        "cornerRadius": "xl"
                    }
                ],
                "paddingAll": "0px"
            }
        }
            }
    sendTemplate(to, data)
def TtempWelcomeMessage2(to, hostname, hostpic, readername, readerpic):
    true = True
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "micro",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": hostpic,
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:3",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": hostname,
                                                "size": "xxs",
                                                "color": Colors["Font"],
                                                "weight": "bold",
                                                "style": "normal",
                                                "wrap": true,
                                                "align": "center"
                                            }
                                        ],
                                        "offsetTop": "12px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": Colors["Background"],
                                "paddingAll": "5px",
                                "paddingTop": "4px",
                                "height": "50px"
                            }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "2px",
                        "cornerRadius": "10px",
                        "borderColor": Colors["Border"]
                    }
                },
                {
                    "type": "bubble",
                    "size": "micro",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": readerpic,
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:3",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": readername,
                                                "size": "xxs",
                                                "color": Colors["Font"],
                                                "weight": "bold",
                                                "style": "normal",
                                                "wrap": true,
                                                "align": "center"
                                            }
                                        ],
                                        "offsetTop": "12px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": Colors["Background"],
                                "paddingAll": "5px",
                                "paddingTop": "4px",
                                "height": "50px"
                            }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "2px",
                        "cornerRadius": "10px",
                        "borderColor": Colors["Border"]
                    }
                }
            ]
        }
            }
    sendTemplate(to, data)
#
def groupscast(to, message):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": Colors["Font"],
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://obs.line-scdn.net/" + noobcoder.profile.pictureStatus,
                                "aspectMode": "cover"
                            }
                        ],
                        "position": "absolute",
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "1.5px",
                        "borderColor": Colors["Font"],
                        "cornerRadius": "10px",
                        "offsetTop": "12px",
                        "offsetStart": "12px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "150px",
                        "height": "2px",
                        "offsetStart": "80px"
                    },
                    {
                        "contents": [
                            {
                                "text": "GROUPCAST",
                                "size": "md",
                                "align": "center",
                                "color": Colors["Font"],
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical",
                        "offsetStart": "80px",
                        "width": "150px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "150px",
                        "height": "2px",
                        "offsetStart": "80px"
                    },
                    {
                        "contents": [
                            {
                                "type": "spacer",
                                "size": "xxl"
                            },
                            {
                                "contents": [
                                    {
                                        "text": message,
                                        "size": "md",
                                        "margin": "none",
                                        "color": Colors["Font"],
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text",
                                        "align": "center"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                },
                "footer": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
            }
    bcTemplate(to, data)
def friendscast(receiver, message):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": Colors["Font"],
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://obs.line-scdn.net/" + noobcoder.profile.pictureStatus,
                                "aspectMode": "cover"
                            }
                        ],
                        "position": "absolute",
                        "width": "50px",
                        "height": "50px",
                        "borderWidth": "1.5px",
                        "borderColor": Colors["Font"],
                        "cornerRadius": "10px",
                        "offsetTop": "18px",
                        "offsetStart": "10px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(receiver).pictureStatus),
                                "aspectMode": "cover"
                            }
                        ],
                        "position": "absolute",
                        "width": "50px",
                        "height": "50px",
                        "borderWidth": "1.5px",
                        "borderColor": Colors["Font"],
                        "cornerRadius": "10px",
                        "offsetTop": "18px",
                        "offsetStart": "195px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"],
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "110px",
                        "height": "2px",
                        "offsetStart": "60px"
                    },
                    {
                        "contents": [
                            {
                                "text": "FRIENDCAST",
                                "size": "md",
                                "align": "center",
                                "color": Colors["Font"],
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical",
                        "offsetStart": "60px",
                        "width": "110px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Font"]
                            }
                        ],
                        "backgroundColor": Colors["Font"],
                        "width": "110px",
                        "height": "2px",
                        "offsetStart": "60px"
                    },
                    {
                        "contents": [
                            {
                                "type": "spacer",
                                "size": "xxl"
                            },
                            {
                                "contents": [
                                    {
                                        "text": message,
                                        "size": "xs",
                                        "margin": "none",
                                        "color": Colors["Font"],
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text",
                                        "align": "center"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                },
                "footer": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
            }
    bcTemplate2(receiver, data)
def taboutMe1(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "{}".format(noobcoder.getProfile().displayName),
                                                "size": "lg",
                                                "align": "center",
                                                "weight": "bold",
                                                "color": Colors["Font"]
                                            }
                                        ],
                                        "margin": "md"
                                    }
                                ]
                            },
                            {
                                "type": "separator",
                                "color": Colors["Font"],
                                "margin": "sm"
                            }
                        ],
                        "paddingAll": "3px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "Friends",
                                                        "size": "xs",
                                                        "color": Colors["Font"],
                                                        "align": "center",
                                                        "gravity": "center"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Blocked",
                                                        "size": "xs",
                                                        "color": Colors["Font"],
                                                        "align": "center",
                                                        "gravity": "center"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Groups",
                                                        "size": "xs",
                                                        "color": Colors["Font"],
                                                        "align": "center",
                                                        "gravity": "center"
                                                    }
                                                ]
                                            },
                                            {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(str(len(noobcoder.getAllContactIds()))),
                                                        "size": "xxs",
                                                        "color": Colors["Font"],
                                                        "align": "center",
                                                        "gravity": "center"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(str(len(noobcoder.getBlockedContactIds()))),
                                                        "size": "xxs",
                                                        "color": Colors["Font"],
                                                        "align": "center",
                                                        "gravity": "center"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(str(len(noobcoder.getGroupIdsJoined()))),
                                                        "size": "xxs",
                                                        "color": Colors["Font"],
                                                        "align": "center",
                                                        "gravity": "center"
                                                    }
                                                ],
                                                "margin": "sm"
                                            }
                                        ],
                                        "margin": "lg"
                                    }
                                ]
                            },
                            {
                                "type": "separator",
                                "color": Colors["Font"],
                                "margin": "md"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "image",
                                        "url": "https://obs.line-scdn.net/" + noobcoder.profile.pictureStatus,
                                        "size": "full",
                                        "aspectMode": "cover",
                                        "aspectRatio": "1:1.2"
                                    },
                                    {
                                        "type": "separator",
                                        "color": Colors["Font"]
                                    },
                                    {
                                        "type": "separator",
                                        "color": Colors["Font"]
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": Customer["userFlag"],
                                                "size": "sm",
                                                "weight": "regular",
                                                "align": "center",
                                                "color": Colors["Font"]
                                            }
                                        ],
                                        "backgroundColor": Colors["Template"]
                                    }
                                ],
                                "flex": 2
                            }
                        ],
                        "margin": "lg"
                    }
                ],
                "cornerRadius": "10px",
                "borderColor": Colors["Font"],
                "borderWidth": "1.5px",
                "backgroundColor": Colors["Background"],
                "paddingAll": "0px"
            }
        }
            }
    sendTemplate(to, data)
def taboutMe2(to):
    true = True
    false = False
    contact = noobcoder.getContact(noobcoderMID)
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "kilo",
                    "header": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "text",
                                "text": "PROFILE PICTURE",
                                "size": "md",
                                "weight": "bold",
                                "align": "center",
                                "color": Colors["Font"]
                            }
                        ]
                    },
                    "hero": {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                        "size": "full",
                        "aspectMode": "cover",
                        "action": {
                            "type": "uri",
                            "uri": Customer["makerLineid"]
                        }
                    },
                    "footer": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": Customer["userFlag"],
                                        "align": "center",
                                        "color": Colors["Font"],
                                        "size": "md"
                                    },
                                    {
                                        "type": "spacer",
                                        "size": "sm"
                                    }
                                ]
                            }
                        ]
                    },
                    "styles": {
                        "header": {
                            "backgroundColor": Colors["Background"]
                        },
                        "hero": {
                            "backgroundColor": Colors["Background"],
                            "separator": true,
                            "separatorColor": Colors["Font"]
                        },
                        "footer": {
                            "backgroundColor": Colors["Background"],
                            "separator": true,
                            "separatorColor": Colors["Font"]
                        }
                    }
                },
                {
                    "type": "bubble",
                    "size": "kilo",
                    "header": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "text",
                                "text": "COVER PICTURE",
                                "size": "md",
                                "weight": "bold",
                                "align": "center",
                                "color": Colors["Font"]
                            }
                        ]
                    },
                    "hero": {
                        "type": "image",
                        "url": noobcoder.getProfileCoverURL(noobcoderMID),
                        "size": "full",
                        "aspectMode": "cover",
                        "action": {
                            "type": "uri",
                            "uri": Customer["makerLineid"]
                        }
                    },
                    "footer": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": Customer["userFlag"],
                                        "align": "center",
                                        "color": Colors["Font"],
                                        "size": "md"
                                    },
                                    {
                                        "type": "spacer",
                                        "size": "sm"
                                    }
                                ]
                            }
                        ]
                    },
                    "styles": {
                        "header": {
                            "backgroundColor": Colors["Background"]
                        },
                        "hero": {
                            "backgroundColor": Colors["Background"],
                            "separator": true,
                            "separatorColor": Colors["Font"]
                        },
                        "footer": {
                            "backgroundColor": Colors["Background"],
                            "separator": true,
                            "separatorColor": Colors["Font"]
                        }
                    }
                },
                {
                    "type": "bubble",
                    "size": "kilo",
                    "header": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "MY STATUS",
                                "size": "md",
                                "weight": "bold",
                                "align": "center",
                                "color": Colors["Font"]
                            }
                        ]
                    },
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "Name",
                                        "size": "lg",
                                        "color": Colors["Font"],
                                        "wrap": true
                                    },
                                    {
                                        "type": "text",
                                        "text": ":",
                                        "size": "md",
                                        "color": Colors["Font"]
                                    },
                                    {
                                        "type": "text",
                                        "text": "{}".format(str(noobcoder.getContact(noobcoderMID).displayName)),
                                        "size": "md",
                                        "color": Colors["Font"],
                                        "wrap": true,
                                        "flex": 2
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "Status",
                                        "size": "lg",
                                        "color": Colors["Font"],
                                        "wrap": true
                                    },
                                    {
                                        "type": "text",
                                        "text": ":",
                                        "size": "sm",
                                        "color": Colors["Font"]
                                    },
                                    {
                                        "type": "text",
                                        "text": "{}".format(str(contact.statusMessage)),
                                        "size": "md",
                                        "align": "center",
                                        "color": Colors["Font"],
                                        "wrap": true,
                                        "flex": 2
                                    }
                                ]
                            }
                        ]
                    },
                    "footer": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text":  Customer["userFlag"],
                                        "align": "center",
                                        "color": Colors["Font"],
                                        "size": "md"
                                    },
                                    {
                                        "type": "spacer",
                                        "size": "sm"
                                    }
                                ]
                            }
                        ],
                        "backgroundColor": Colors["Background"]
                    },
                    "styles": {
                        "header": {
                            "backgroundColor": Colors["Background"]
                        },
                        "hero": {
                            "backgroundColor": Colors["Background"],
                            "separator": true,
                            "separatorColor": Colors["Font"]
                        },
                        "body": {
                            "backgroundColor": Colors["Background"],
                            "separator": true,
                            "separatorColor": Colors["Font"]
                        },
                        "footer": {
                            "backgroundColor": Colors["Background"],
                            "separator": true,
                            "separatorColor": Colors["Font"]
                        }
                    }
                }
            ]
        }
            }
    sendTemplate(to, data)
# AFAQ TEMPLATES
def thelpmenu(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "kilo",
                    "body": {
                        "backgroundColor": "#000000",
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://obs.line-scdn.net",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:2.73",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂",
                                                "size": "md",
                                                "align": "center",
                                                "color": "#FFFFFF",
                                                "weight": "regular"
                                            }
                                        ]
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "spacer",
                                                "size": "md"
                                            },
                                            {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Mybot",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=myself"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Myself",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=profile"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Profile",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=steal"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Settings",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=mention"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Templates",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=group"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Group",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=protect"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Information",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=newlist"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Kicking",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=stickers"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Banning",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=friend"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    }
                                                ],
                                                "borderColor": "#FFFFFF",
                                                "cornerRadius": "10px",
                                                "borderWidth": "1.5px"
                                            }
                                        ]
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "paddingAll": "20px",
                                "paddingTop": "18px",
                                "offsetTop": "145px"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "image",
                                        "url": "https://obs.line-scdn.net/0huPmQk60JKn9QKDxGXGNVKGxtJBInBiw3KBtlTiAufE99GT8rbRw3TiAhcB9-Hm97bUxiH3EgdB19",
                                        "size": "full",
                                        "aspectMode": "cover",
                                        "aspectRatio": "2:3",
                                        "action": {
                                            "type": "uri",
                                            "uri": "http://line.me/ti/p/~afaqshah.512"
                                        }
                                    }
                                ],
                                "position": "absolute",
                                "offsetTop": "20px",
                                "height": "135px",
                                "width": "135px",
                                "borderWidth": "1.5px",
                                "borderColor": "#FFFFFF",
                                "cornerRadius": "10px",
                                "offsetStart": "60px"
                            }
                        ],
                        "paddingAll": "0px",
                        "cornerRadius": "10px",
                        "borderColor": "#FFFFFF",
                        "borderWidth": "1.5px"
                    }
                },
                {
                    "type": "bubble",
                    "size": "kilo",
                    "body": {
                        "backgroundColor": "#000000",
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://obs.line-scdn.net",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:2.73",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂",
                                                "size": "md",
                                                "align": "center",
                                                "color": "#FFFFFF",
                                                "weight": "regular"
                                            }
                                        ]
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "spacer",
                                                "size": "md"
                                            },
                                            {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Protection",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=myself"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Friends",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=profile"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Broadcast",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=steal"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Mention",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=mention"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "War",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=group"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Media",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=protect"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "text",
                                                                "text": "Stickers",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=newlist"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Giflist",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=stickers"
                                                                }
                                                            },
                                                            {
                                                                "type": "text",
                                                                "text": "Parameters",
                                                                "size": "xs",
                                                                "color": "#FFFFFF",
                                                                "align": "center",
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "action",
                                                                    "uri": "line://app/1621273710-QqNjYrG4?type=text&text=friend"
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "contents": [
                                                            {
                                                                "type": "spacer",
                                                                "size": "xxl"
                                                            }
                                                        ]
                                                    }
                                                ],
                                                "borderColor": "#FFFFFF",
                                                "cornerRadius": "10px",
                                                "borderWidth": "1.5px"
                                            }
                                        ]
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "paddingAll": "20px",
                                "paddingTop": "18px",
                                "offsetTop": "145px"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "image",
                                        "url": "https://obs.line-scdn.net/0huPmQk60JKn9QKDxGXGNVKGxtJBInBiw3KBtlTiAufE99GT8rbRw3TiAhcB9-Hm97bUxiH3EgdB19",
                                        "size": "full",
                                        "aspectMode": "cover",
                                        "aspectRatio": "2:3",
                                        "action": {
                                            "type": "uri",
                                            "uri": "http://line.me/ti/p/~afaqshah.512"
                                        }
                                    }
                                ],
                                "position": "absolute",
                                "offsetTop": "20px",
                                "height": "135px",
                                "width": "135px",
                                "borderWidth": "1.5px",
                                "borderColor": "#FFFFFF",
                                "cornerRadius": "10px",
                                "offsetStart": "60px"
                            }
                        ],
                        "paddingAll": "0px",
                        "cornerRadius": "10px",
                        "borderColor": "#FFFFFF",
                        "borderWidth": "1.5px"
                    }
                }
            ]
        }
            }
    sendTemplate(to, data)
def tlistmenu(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "micro",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": "#FFF8DC",
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "140px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "text": "heading",
                                "size": "md",
                                "align": "center",
                                "color": "#FFFFFF",
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "140px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "contents": [
                                    {
                                        "text": "list",
                                        "size": "xs",
                                        "margin": "none",
                                        "color": "#FFFFFF",
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": "#000000"
                },
                "footer": {
                    "backgroundColor": "#FF1493"
                }
            }
        }
            }
    sendTemplate(to, data)
def tlistmenukilo(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "borderWidth": "2px",
                "borderColor": "#FFF8DC",
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "230px",
                        "height": "2.5px"
                    },
                    {
                        "contents": [
                            {
                                "text": "HEADING",
                                "size": "lg",
                                "align": "center",
                                "color": "#FFFFFF",
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "230px",
                        "height": "2.5px"
                    },
                    {
                        "contents": [
                            {
                                "contents": [
                                    {
                                        "text": "list",
                                        "size": "sm",
                                        "margin": "none",
                                        "color": "#FFFFFF",
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": "#000000"
                },
                "footer": {
                    "backgroundColor": "#FF1493"
                }
            }
        }
            }
    sendTemplate(to, data)
def tbotmessage(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                            {
                                "type": "text",
                                "text": "Bot Message",
                                "size": "sm",
                                "wrap": true,
                                "align": "center",
                                "color": "#FFFFFF",
                                "action": {
                                    "type": "uri",
                                    "uri": "http://line.me/ti/p/~real.hacker"
                                }
                            }
                        ],
                        "margin": "xs",
                        "spacing": "xs",
                        "backgroundColor": "#000000"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "Customer Flag",
                                "align": "center",
                                "color": "#FFFFFF",
                                "size": "xs",
                                "action": {
                                    "type": "uri",
                                    "uri": "http://line.me/ti/p/~lineid"
                                }
                            }
                        ],
                        "paddingAll": "0px",
                        "backgroundColor": "#1b1b1b"
                    }
                ],
                "paddingAll": "0px",
                "borderWidth": "1.5px",
                "borderColor": "#FFFFFF",
                "cornerRadius": "10px",
                "spacing": "xs"
            },
            "styles": {
                "body": {
                    "backgroundColor": "#003333"
                }
            }
        }
            }
    sendTemplate(to, data)
def tsider1(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": "https://obs.line-scdn.net/0hqbPQIGLALk1tKDhzKuFRGlFtICAaBigFFRpjLU16dnUQHToZVRpgLxsqeHwUGmtPWR00LE0rcn0S",
                                                "size": "full",
                                                "aspectMode": "cover",
                                                "aspectRatio": "2:3"
                                            }
                                        ],
                                        "width": "56px",
                                        "height": "61.5px",
                                        "borderWidth": "1.5px",
                                        "borderColor": "#FFFFFF",
                                        "cornerRadius": "xl",
                                        "action": {
                                            "type": "uri",
                                            "uri": "http://line.me/ti/p/~afaqshah.512"
                                        }
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "Member Name 124",
                                                "weight": "bold",
                                                "size": "lg",
                                                "color": "#FFFFFF",
                                                "align": "center"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#FFFFFF",
                                                "margin": "sm"
                                            },
                                            {
                                                "type": "text",
                                                "text": "Sider Message Wrap True",
                                                "size": "md",
                                                "margin": "md",
                                                "color": "#FFFFFF",
                                                "align": "center",
                                                "wrap": true
                                            }
                                        ],
                                        "margin": "lg"
                                    }
                                ]
                            }
                        ],
                        "paddingAll": "5px",
                        "backgroundColor": "#000000",
                        "borderWidth": "1.5px",
                        "borderColor": "#FFFFFF",
                        "cornerRadius": "xl"
                    }
                ],
                "paddingAll": "0px"
            }
        }
            }
    sendTemplate(to, data)
def tsider1giga(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "giga",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": "https://obs.line-scdn.net/0hqbPQIGLALk1tKDhzKuFRGlFtICAaBigFFRpjLU16dnUQHToZVRpgLxsqeHwUGmtPWR00LE0rcn0S",
                                                "size": "full",
                                                "aspectMode": "cover",
                                                "aspectRatio": "2:3"
                                            }
                                        ],
                                        "width": "56px",
                                        "height": "61.5px",
                                        "borderWidth": "2px",
                                        "borderColor": "#FFFFFF",
                                        "cornerRadius": "6px",
                                        "action": {
                                            "type": "uri",
                                            "uri": "http://line.me/ti/p/~afaqshah.512"
                                        }
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "Member Name 124",
                                                "weight": "bold",
                                                "size": "lg",
                                                "color": "#FFFFFF",
                                                "align": "center"
                                            },
                                            {
                                                "type": "separator",
                                                "color": "#FFFFFF",
                                                "margin": "sm"
                                            },
                                            {
                                                "type": "text",
                                                "text": "Sider Message Wrap True",
                                                "size": "md",
                                                "margin": "md",
                                                "color": "#FFFFFF",
                                                "align": "center",
                                                "wrap": true
                                            }
                                        ],
                                        "margin": "lg"
                                    }
                                ]
                            }
                        ],
                        "paddingAll": "5px",
                        "backgroundColor": "#000000",
                        "borderWidth": "2px",
                        "borderColor": "#FFFFFF",
                        "cornerRadius": "6px"
                    }
                ],
                "paddingAll": "0px"
            },
            "styles": {
                "footer": {
                    "backgroundColor": "#FFFFFF"
                }
            }
        }
            }
    sendTemplate(to, data)
def tsider2(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "mega",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": "#FFFFFF",
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip13.jpg",
                                "aspectMode": "cover"
                            }
                        ],
                        "position": "absolute",
                        "width": "70px",
                        "height": "70px",
                        "borderWidth": "1.5px",
                        "borderColor": "#FFFFFF",
                        "cornerRadius": "100px",
                        "offsetTop": "10px",
                        "offsetStart": "10px"
                    },
                    {
                        "contents": [
                            {
                                "text": "Member Name 123456789",
                                "size": "sm",
                                "align": "center",
                                "color": "#FFFFFF",
                                "wrap": false,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical",
                        "offsetStart": "97px",
                        "width": "180px",
                        "offsetTop": "15px",
                        "position": "absolute"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "220px",
                        "height": "1.5px",
                        "offsetStart": "80px",
                        "offsetTop": "45px",
                        "position": "absolute"
                    },
                    {
                        "contents": [
                            {
                                "text": "message\n message\n message",
                                "size": "sm",
                                "margin": "none",
                                "color": "#FFFFFF",
                                "wrap": false,
                                "weight": "regular",
                                "type": "text",
                                "align": "center"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical",
                        "width": "200px",
                        "height": "20px",
                        "offsetTop": "60px",
                        "offsetStart": "87px",
                        "position": "absolute"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical",
                "height": "95px"
            },
            "styles": {
                "body": {
                    "backgroundColor": "#000000"
                },
                "footer": {
                    "backgroundColor": "#000000"
                }
            }
        }
            }
    sendTemplate(to, data)
def tsider3(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "mega",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": "#FFFFFF",
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip13.jpg",
                                "aspectMode": "cover"
                            }
                        ],
                        "position": "absolute",
                        "width": "90px",
                        "height": "90px",
                        "borderWidth": "1.5px",
                        "borderColor": "#FFFFFF",
                        "cornerRadius": "100px",
                        "offsetTop": "10px",
                        "offsetStart": "10px"
                    },
                    {
                        "contents": [
                            {
                                "text": "Member Name 123456789",
                                "size": "sm",
                                "align": "center",
                                "color": "#FFFFFF",
                                "wrap": false,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical",
                        "offsetStart": "107px",
                        "width": "180px",
                        "offsetTop": "20px",
                        "position": "absolute"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "200px",
                        "height": "1.5px",
                        "offsetStart": "100px",
                        "offsetTop": "50px",
                        "position": "absolute"
                    },
                    {
                        "contents": [
                            {
                                "text": "message\n message\n message",
                                "size": "sm",
                                "margin": "none",
                                "color": "#FFFFFF",
                                "wrap": false,
                                "weight": "regular",
                                "type": "text",
                                "align": "center"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical",
                        "width": "180px",
                        "height": "15px",
                        "offsetTop": "70px",
                        "offsetStart": "107px",
                        "position": "absolute"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical",
                "height": "115px"
            },
            "styles": {
                "body": {
                    "backgroundColor": "#000000"
                },
                "footer": {
                    "backgroundColor": "#000000"
                }
            }
        }
            }
    sendTemplate(to, data)
def twlcome1(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "mega",
                    "body": {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "size": "md",
                                                "color": "#FFFFFF",
                                                "weight": "bold",
                                                "align": "end",
                                                "offsetTop": "23px",
                                                "contents": [],
                                                "text": "User Name 1234567"
                                            }
                                        ],
                                        "height": "70px",
                                        "offsetTop": "139px",
                                        "offsetStart": "15px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": "#000000",
                                "paddingAll": "20px",
                                "paddingTop": "18px",
                                "width": "300px",
                                "height": "280px"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "liner",
                                        "color": "#FFFFFF"
                                    }
                                ],
                                "height": "2px",
                                "backgroundColor": "#FFFFFF",
                                "position": "absolute",
                                "offsetTop": "80px",
                                "width": "300px"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "image",
                                        "url": "https://obs.line-scdn.net/0h5rqTt857al1MLXxgCy0VCnBoZDA7A2wVNE52Pj4kZj4xSS8NcR53b2F4MWhpGyVcdkMiMm4oPDlg",
                                        "size": "4xl",
                                        "aspectMode": "cover"
                                    }
                                ],
                                "position": "absolute",
                                "borderColor": "#FFFFFF",
                                "cornerRadius": "100px",
                                "width": "64px",
                                "height": "64px",
                                "offsetTop": "6px",
                                "offsetStart": "11px"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "image",
                                        "url": "https://1.bp.blogspot.com/-hLL5MIQWipc/XtiPBl6wvqI/AAAAAAAAGcQ/vXGIC1UlUbMkHU-N0MFl0yUKw-L3zY8nACK4BGAsYHg/s1024/image%2B%25283%2529.png",
                                        "size": "full",
                                        "aspectMode": "fit",
                                        "offsetBottom": "18px",
                                        "offsetStart": "-10px"
                                    }
                                ],
                                "position": "absolute",
                                "width": "105px",
                                "height": "105px",
                                "borderColor": "#FFFFFF"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "Reader Message\n Reader Message\n READMESSAGE Readmessahge Readmessage",
                                        "color": "#FFFFFF",
                                        "wrap": true,
                                        "size": "md",
                                        "weight": "regular",
                                        "style": "italic",
                                        "align": "center",
                                        "offsetTop": "10px",
                                        "maxLines": 3
                                    }
                                ],
                                "position": "relative",
                                "height": "82px",
                                "width": "320px",
                                "borderColor": "#424242",
                                "cornerRadius": "5px",
                                "offsetTop": "80px"
                            }
                        ],
                        "paddingAll": "0px",
                        "width": "300px",
                        "height": "160px",
                        "borderWidth": "1.5px",
                        "cornerRadius": "10px",
                        "borderColor": "#000000"
                    }
                }
            ]
        }
            }
    sendTemplate(to, data)
def twlcome2(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "micro",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/01_1_cafe.png",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:3",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "HOST NAME",
                                                "size": "xxs",
                                                "color": "#FFFFFF",
                                                "weight": "bold",
                                                "style": "normal",
                                                "wrap": true,
                                                "align": "center"
                                            }
                                        ],
                                        "offsetTop": "12px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": "#000000",
                                "paddingAll": "5px",
                                "paddingTop": "4px",
                                "height": "50px"
                            }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "2px",
                        "cornerRadius": "10px",
                        "borderColor": "#000000"
                    }
                },
                {
                    "type": "bubble",
                    "size": "micro",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/01_1_cafe.png",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:3",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "READER NAME",
                                                "size": "xxs",
                                                "color": "#FFFFFF",
                                                "weight": "bold",
                                                "style": "normal",
                                                "wrap": true,
                                                "align": "center"
                                            }
                                        ],
                                        "offsetTop": "12px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": "#000000",
                                "paddingAll": "5px",
                                "paddingTop": "4px",
                                "height": "50px"
                            }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "2px",
                        "cornerRadius": "10px",
                        "borderColor": "#000000"
                    }
                }
            ]
        }
            }
    sendTemplate(to, data)
def twlcome2nano(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "nano",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/01_1_cafe.png",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:3",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "MEMBER NAME 234567890",
                                                "size": "8px",
                                                "color": "#FFFFFF",
                                                "weight": "bold",
                                                "style": "normal",
                                                "wrap": true,
                                                "align": "center"
                                            }
                                        ],
                                        "offsetTop": "15px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": "#000000",
                                "paddingAll": "5px",
                                "paddingTop": "4px",
                                "height": "50px"
                            }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "2px",
                        "cornerRadius": "10px",
                        "borderColor": "#000000"
                    }
                },
                {
                    "type": "bubble",
                    "size": "nano",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/fx/01_1_cafe.png",
                                "size": "full",
                                "aspectMode": "cover",
                                "aspectRatio": "2:3",
                                "gravity": "top"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "MEMBER NAME 234567890",
                                                "size": "8px",
                                                "color": "#FFFFFF",
                                                "weight": "bold",
                                                "style": "normal",
                                                "wrap": true,
                                                "align": "center"
                                            }
                                        ],
                                        "offsetTop": "15px"
                                    }
                                ],
                                "position": "absolute",
                                "offsetBottom": "0px",
                                "offsetStart": "0px",
                                "offsetEnd": "0px",
                                "backgroundColor": "#000000",
                                "paddingAll": "5px",
                                "paddingTop": "4px",
                                "height": "50px"
                            }
                        ],
                        "paddingAll": "0px",
                        "borderWidth": "2px",
                        "cornerRadius": "10px",
                        "borderColor": "#000000"
                    }
                }
            ]
        }
            }
    sendTemplate(to, data)
def tme1(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "AFAQ SHAH XP",
                                                "size": "lg",
                                                "align": "center",
                                                "weight": "bold",
                                                "color": "#FFFFFF"
                                            }
                                        ],
                                        "margin": "md"
                                    }
                                ]
                            },
                            {
                                "type": "separator",
                                "color": "#FFFFFF",
                                "margin": "sm"
                            }
                        ],
                        "paddingAll": "3px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "Friends",
                                                        "size": "xs",
                                                        "color": "#FFFFFF",
                                                        "align": "center",
                                                        "gravity": "center"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Blocked",
                                                        "size": "xs",
                                                        "color": "#FFFFFF",
                                                        "align": "center",
                                                        "gravity": "center"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "Groups",
                                                        "size": "xs",
                                                        "color": "#FFFFFF",
                                                        "align": "center",
                                                        "gravity": "center"
                                                    }
                                                ]
                                            },
                                            {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "(293)",
                                                        "size": "xxs",
                                                        "color": "#FFFFFF",
                                                        "align": "center",
                                                        "gravity": "center"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "(0)",
                                                        "size": "xxs",
                                                        "color": "#FFFFFF",
                                                        "align": "center",
                                                        "gravity": "center"
                                                    },
                                                    {
                                                        "type": "text",
                                                        "text": "(52)",
                                                        "size": "xxs",
                                                        "color": "#FFFFFF",
                                                        "align": "center",
                                                        "gravity": "center"
                                                    }
                                                ],
                                                "margin": "sm"
                                            }
                                        ],
                                        "margin": "lg"
                                    }
                                ]
                            },
                            {
                                "type": "separator",
                                "color": "#FFFFFF",
                                "margin": "md"
                            },
                            {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "image",
                                        "url": "https://obs.line-scdn.net/0huPmQk60JKn9QKDxGXGNVKGxtJBInBiw3KBtlTiAufE99GT8rbRw3TiAhcB9-Hm97bUxiH3EgdB19",
                                        "size": "full",
                                        "aspectMode": "cover",
                                        "aspectRatio": "1:1.2"
                                    },
                                    {
                                        "type": "separator",
                                        "color": "#FFFFFF"
                                    },
                                    {
                                        "type": "separator",
                                        "color": "#FFFFFF"
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": "Customer Flag",
                                                "size": "sm",
                                                "weight": "regular",
                                                "align": "center",
                                                "color": "#FFFFFF"
                                            }
                                        ],
                                        "backgroundColor": "#1b1b1b"
                                    }
                                ],
                                "flex": 2
                            }
                        ],
                        "margin": "lg"
                    }
                ],
                "cornerRadius": "10px",
                "borderColor": "#FFFFFF",
                "borderWidth": "1.5px",
                "backgroundColor": "#000000",
                "paddingAll": "0px"
            }
        }
            }
    sendTemplate(to, data)
def tme2(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "carousel",
            "contents": [
                {
                    "type": "bubble",
                    "size": "kilo",
                    "header": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "text",
                                "text": "PROFILE PICTURE",
                                "size": "md",
                                "weight": "bold",
                                "align": "center",
                                "color": "#FFFFFF"
                            }
                        ]
                    },
                    "hero": {
                        "type": "image",
                        "url": "https://obs.line-scdn.net/0huPmQk60JKn9QKDxGXGNVKGxtJBInBiw3KBtlTiAufE99GT8rbRw3TiAhcB9-Hm97bUxiH3EgdB19",
                        "size": "full",
                        "aspectMode": "cover",
                        "action": {
                            "type": "uri",
                            "uri": "http://line.me/ti/p/~real.hacker"
                        }
                    },
                    "footer": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "Customer Flag",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "size": "md"
                                    },
                                    {
                                        "type": "spacer",
                                        "size": "sm"
                                    }
                                ]
                            }
                        ]
                    },
                    "styles": {
                        "header": {
                            "backgroundColor": "#000000"
                        },
                        "hero": {
                            "backgroundColor": "#000000",
                            "separator": true,
                            "separatorColor": "#FFFFFF"
                        },
                        "footer": {
                            "backgroundColor": "#000000",
                            "separator": true,
                            "separatorColor": "#FFFFFF"
                        }
                    }
                },
                {
                    "type": "bubble",
                    "size": "kilo",
                    "header": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "text",
                                "text": "COVER PICTURE",
                                "size": "md",
                                "weight": "bold",
                                "align": "center",
                                "color": "#FFFFFF"
                            }
                        ]
                    },
                    "hero": {
                        "type": "image",
                        "url": "https://obs-sg.line-apps.com/myhome/c/download.nhn?userid=ud1fd79110c30ccfd85a273c0367591c1&oid=085310cc02deb0e7915f353e502a64eb",
                        "size": "full",
                        "aspectMode": "cover",
                        "action": {
                            "type": "uri",
                            "uri": "http://line.me/ti/p/~real.hacker"
                        }
                    },
                    "footer": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "🔥HâÇkêR💓ShãÑï💓",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "size": "md"
                                    },
                                    {
                                        "type": "spacer",
                                        "size": "sm"
                                    }
                                ]
                            }
                        ]
                    },
                    "styles": {
                        "header": {
                            "backgroundColor": "#000000"
                        },
                        "hero": {
                            "backgroundColor": "#000000",
                            "separator": true,
                            "separatorColor": "#FFFFFF"
                        },
                        "footer": {
                            "backgroundColor": "#000000",
                            "separator": true,
                            "separatorColor": "#FFFFFF"
                        }
                    }
                },
                {
                    "type": "bubble",
                    "size": "kilo",
                    "header": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "MY STATUS",
                                "size": "md",
                                "weight": "bold",
                                "align": "center",
                                "color": "#FFFFFF"
                            }
                        ]
                    },
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "Name",
                                        "size": "lg",
                                        "color": "#FFFFFF",
                                        "wrap": true
                                    },
                                    {
                                        "type": "text",
                                        "text": ":",
                                        "size": "md",
                                        "color": "#FFFFFF"
                                    },
                                    {
                                        "type": "text",
                                        "text": "displayname",
                                        "size": "md",
                                        "color": "#FFFFFF",
                                        "wrap": true,
                                        "flex": 2
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "Status",
                                        "size": "lg",
                                        "color": "#FFFFFF",
                                        "wrap": true
                                    },
                                    {
                                        "type": "text",
                                        "text": ":",
                                        "size": "sm",
                                        "color": "#FFFFFF"
                                    },
                                    {
                                        "type": "text",
                                        "text": "profile status",
                                        "size": "md",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "wrap": true,
                                        "flex": 2
                                    }
                                ]
                            }
                        ]
                    },
                    "footer": {
                        "type": "box",
                        "layout": "vertical",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "baseline",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "Customer Flag",
                                        "align": "center",
                                        "color": "#FFFFFF",
                                        "size": "md"
                                    },
                                    {
                                        "type": "spacer",
                                        "size": "sm"
                                    }
                                ]
                            }
                        ],
                        "backgroundColor": "#000000"
                    },
                    "styles": {
                        "header": {
                            "backgroundColor": "#000000"
                        },
                        "hero": {
                            "backgroundColor": "#003333",
                            "separator": true,
                            "separatorColor": "#FFFF00"
                        },
                        "body": {
                            "backgroundColor": "#000000",
                            "separator": true,
                            "separatorColor": "#FFFFFF"
                        },
                        "footer": {
                            "backgroundColor": "#000000",
                            "separator": true,
                            "separatorColor": "#FFFFFF"
                        }
                    }
                }
            ]
        }
            }
    sendTemplate(to, data)
def gcast(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": "#FFFFFF",
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip13.jpg",
                                "aspectMode": "cover"
                            }
                        ],
                        "position": "absolute",
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "1.5px",
                        "borderColor": "#FFFFFF",
                        "cornerRadius": "10px",
                        "offsetTop": "12px",
                        "offsetStart": "12px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "150px",
                        "height": "2px",
                        "offsetStart": "80px"
                    },
                    {
                        "contents": [
                            {
                                "text": "Groupscast",
                                "size": "md",
                                "align": "center",
                                "color": "#FFFFFF",
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical",
                        "offsetStart": "80px",
                        "width": "150px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "150px",
                        "height": "2px",
                        "offsetStart": "80px"
                    },
                    {
                        "contents": [
                            {
                                "type": "spacer",
                                "size": "xxl"
                            },
                            {
                                "contents": [
                                    {
                                        "text": "messsage",
                                        "size": "xs",
                                        "margin": "none",
                                        "color": "#FFFFFF",
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text",
                                        "align": "center"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": "#000000"
                },
                "footer": {
                    "backgroundColor": "#000000"
                }
            }
        }
            }
    sendTemplate(to, data)
def fcast(to):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "borderWidth": "1.5px",
                "borderColor": "#FFFFFF",
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip13.jpg",
                                "aspectMode": "cover"
                            }
                        ],
                        "position": "absolute",
                        "width": "50px",
                        "height": "50px",
                        "borderWidth": "1.5px",
                        "borderColor": "#FFFFFF",
                        "cornerRadius": "10px",
                        "offsetTop": "18px",
                        "offsetStart": "10px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "image",
                                "url": "https://scdn.line-apps.com/n/channel_devcenter/img/flexsnapshot/clip/clip13.jpg",
                                "aspectMode": "cover"
                            }
                        ],
                        "position": "absolute",
                        "width": "50px",
                        "height": "50px",
                        "borderWidth": "1.5px",
                        "borderColor": "#FFFFFF",
                        "cornerRadius": "10px",
                        "offsetTop": "18px",
                        "offsetStart": "195px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "110px",
                        "height": "2px",
                        "offsetStart": "60px"
                    },
                    {
                        "contents": [
                            {
                                "text": "Friendscast",
                                "size": "md",
                                "align": "center",
                                "color": "#FFFFFF",
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical",
                        "offsetStart": "60px",
                        "width": "110px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": "#FFFFFF"
                            }
                        ],
                        "backgroundColor": "#FFFFFF",
                        "width": "110px",
                        "height": "2px",
                        "offsetStart": "60px"
                    },
                    {
                        "contents": [
                            {
                                "type": "spacer",
                                "size": "xxl"
                            },
                            {
                                "contents": [
                                    {
                                        "text": "message",
                                        "size": "xs",
                                        "margin": "none",
                                        "color": "#FFFFFF",
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text",
                                        "align": "center"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": "#000000"
                },
                "footer": {
                    "backgroundColor": "#000000"
                }
            }
        }
            }
    sendTemplate(to, data)
#=====================================================================
Nolep = {"auto":False,}
async def noobcoderBot(op):
    try:
        if settings["restartPoint"] != None:
            if wait["flex"] == False:
                noobcoder.sendMessage(settings["restartPoint"], "Selfbot activated.")
            else:
                TBotMessageWithFooter(settings["restartPoint"], "Selfbot activated.")
            settings["restartPoint"] = None
        if op.type == 0:
            return
        if op.type == 5:
            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
            if wtf["autoBlock"]:
                noobcoder.blockContact(op.param1)
                noobcoder.sendMessage(op.param1,"YOUR ACCOUNT HAS BEEN BLOCKED !")
        if op.type == 5:
            if(settings["addPesan"] in [""," ","\n",None]):
                return
            if '@!' not in settings["addPesan"]:
                settings["addPesan"] = '@!'+settings["addPesan"]
            sd = noobcoder.waktunjir()
            noobcoder.sendMention(op.param1,settings["addPesan"].replace('greeting',sd),' 「 Autoadd 」\n',[op.param1]*settings["addPesan"].count('@!'))
            msgSticker = settings["messageSticker"]["listSticker"]["addSticker"]
            if msgSticker != None:
                sid = msgSticker["STKID"]
                spkg = msgSticker["STKPKGID"]
                sver = msgSticker["STKVER"]
                sendSticker(op.param1, op.param1, sver, spkg, sid)
            if settings["autoAdd"] == True:noobcoder.findAndAddContactsByMid(op.param1)
        if op.type in [123, 124]:
            getLexeInvite(op)
        if op.type in [133,132]:
            getLexeKick(op)
            Nolep["auto"] = True
        if op.type in [126,125]:
            getLexeCancel(op)
        if op.type  == 130:
            getLexeJoin(op)
        if op.type == 61:
            if Nolep["auto"] == True:
                Nolep["auto"] = False
                return
            getLexeLeave(op)
#=====================================================================
        if op.type == 22:
            print ("[ 11 ] NOTIFIED UPDATE GROUP")
            if op.param3 == "1" and op.param1 in groupName:
                if op.param2 not in noobcoderMID:
                    try:
                        TBotMessage(op.param1,"Do not change Group Name!")
                        try: noobcoder.kickoutFromGroup(op.param1,[op.param2])
                        except: TBotMessage(op.param1, "Limited")
                        G = noobcoder.getGroup(op.param1)
                        G.name = groupName[op.param1]
                        noobcoder.updateGroup(G)
                    except:
                        pass
            if op.param3 == "4" and op.param1 in groupQr:
                if op.param2 not in noobcoderMID:
                    try:
                        TBotMessage(op.param1,"Do not open Group Link!")
                        try: noobcoder.kickoutFromGroup(op.param1,[op.param2])
                        except: TBotMessage(op.param1, "Limited")
                        group = noobcoder.getGroup(op.param1)
                        group.preventedJoinByTicket = True
                        contact = noobcoder.getContact(op.param2)
                        noobcoder.updateGroup(group)
                    except:
                        pass
#=====================================================================
        if op.type == 124:
            print (">OP 13<")
            if op.param1 in blockInvite:
                if op.param2 not in noobcoderMID:
                    group = noobcoder.getCompactGroup(op.param1)
                    targets = [contact.mid for contact in group.invitee]
                    for target in targets:
                        if target in op.param3:
                            try:
                                try:
                                    noobcoder.cancelGroupInvitation(op.param1,[target])
                                    noobcoder.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    noobcoder.kickoutFromGroup(op.param1,[target])
                                    noobcoder.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                pass
#join temp
        if op.type == 124:
            if noobcoder.getProfile().mid in op.param3:
                G = noobcoder.getCompactGroup(op.param1)
                if settings["autoJoin"] == True:
                    if len(G.members) <= wait["Members"]:
                        noobcoder.acceptGroupInvitation(op.param1)
                        contact = noobcoder.getContact(op.param2)
                        ginfo = noobcoder.getGroup(op.param1)
                        noobcoder.acceptGroupInvitation(op.param1)
                        mentions(op.param1,"Small Group",[op.param2])
                        noobcoder.leaveGroup(op.param1)
                    else:
                        noobcoder.acceptGroupInvitation(op.param1)
# Flex
                inviter = noobcoder.getContact(op.param2)
                ginfo = noobcoder.getGroup(op.param1)
                if gjoin["jMessage"] == True:
                    noobcoderName = "{}".format(str(noobcoder.getContact(noobcoderMID).displayName))
                    noobcoderPP = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
                    noobcoderCV = "https://obs.line-scdn.net/{}".format(noobcoder.getProfileCoverURL(noobcoderMID))
                    inviterName = "{}".format(str(noobcoder.getContact(op.param2).displayName))
                    inviterPP = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(op.param2).pictureStatus)
                    inviterCV = "https://obs.line-scdn.net/{}".format(noobcoder.getProfileCoverURL(op.param2))
                    Message = gjoin["textnya"]
                    TtempWelcomeMessage(op.param1, inviterPP, inviterName, Message, noobcoderPP)
            else:pass
        if op.type == 124:
            if noobcoder.getProfile().mid in op.param3:
                G = noobcoder.getCompactGroup(op.param1)
                if settings["autoJoin"] == True:
                    if len(G.members) <= wait["Members"]:
                        noobcoder.acceptGroupInvitation(op.param1)
                        mentions(op.param1,"Hallo @! You Are Not My Author\nI Leave , See ya",[op.param2])
                        noobcoder.leaveGroup(op.param1)
                    else:
                        noobcoder.acceptGroupInvitation(op.param1)
                if len(G.members) <= wait["Members"]:
                    time.sleep(0.5)
                    noobcoder.rejectGroupInvitation(op.param1)
                else:
                    if admins in op.param2:
                        noobcoder.acceptGroupInvitation(op.param1)
            else:pass
        if op.type == 124:
            if op.param1 in protectinvite:
                if op.param2 not in noobcoderMID:
                    noobcoder.cancelGroupInvitation(op.param1,[op.param3])
        if op.type == 61:
            if op.param1 in wait["GROUP"]['LM']['AP']:
                if op.param1 in wait["GROUP"]['LM']['S']:
                    TBotMessage(op.param2, text=None, contentMetadata=wait["GROUP"]['LM']['S'][op.param1]['Sticker'], contentType=7)
                noobcoder.sendMention(op.param2, "{}".format(wait["GROUP"]['LM']['P'][op.param1].replace('|', ' @!')), ' 「 Leave Detect 」\n', [op.param2])
        if op.type == 61:
            print ("[ 15 ] NOTIFIED LEAVE INTO GROUP")
            if settings["leaveMessage"] == True:
                g = noobcoder.getGroup(op.param1)
                c = noobcoder.getContact(op.param2)
                if "@!" not in settings["messageLeave"]:
                    mentions(op.param1, settings["messageLeave"] + " @!",[op.param2])
                    stc = lstckr["sticker"]["stkid"]            		
                    pkc = lstckr["sticker"]["pkgid"]
                    noobcoder.sendSticker(op.param1, pkc, stc)            	
                else:
                    mentions(op.param1, settings["messageLeave"],[op.param2])
                    stc = lstckr["sticker"]["stkid"]            		
                    pkc = lstckr["sticker"]["pkgid"]
                    noobcoder.sendSticker(op.param1, pkc, stc)
 # Leave Temp
        if op.type == 61:
            print ("[ 61 ] NOTIFIED LEAVE GROUP")
            if lvin["lMessage"] == True:
                noobcoderName = "{}".format(str(noobcoder.getContact(noobcoderMID).displayName))
                noobcoderPP = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
                noobcoderCV = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
                memmberName = "{}".format(str(noobcoder.getContact(op.param2).displayName))
                memmberPP = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(op.param2).pictureStatus)
                memmberCV = "https://obs.line-scdn.net/{}".format(noobcoder.getProfileCoverURL(op.param2))
                Message = lvin["textnya"]
                TtempLeftMessage(op.param1, memmberPP, memmberName, Message, memmberCV)
                time.sleep(2)
#=====================================================================
        if op.type == 130:
            print ("[ 17 ] NOTIFIED WELCOME INTO GROUP")
            if settings["welcomeMessage"] == True:
                dan = noobcoder.getContact(op.param2)
                tgb = noobcoder.getGroup(op.param1)
                if "@!" not in settings["messageWelcome"]:
                    mentions(op.param1, settings["messageWelcome"] + " @!",[op.param2])
                    stc = wstckr["sticker"]["stkid"]
                    pkc = wstckr["sticker"]["pkgid"]
                    noobcoder.sendSticker(op.param1, pkc, stc)
                else:
                    mentions(op.param1, settings["messageWelcome"],[op.param2])
                    stc = wstckr["sticker"]["stkid"]
                    pkc = wstckr["sticker"]["pkgid"]
                    noobcoder.sendSticker(op.param1, pkc, stc)
        if op.type == 130:
            print ("[ 17 ] NOTIFIED INVITE INTO GROUP")
            if wmin["wMessage"] == True:
                Message = wmin["textnya"]
                noobcoderName = "{}".format(str(noobcoder.getContact(noobcoderMID).displayName))
                noobcoderPP = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
                noobcoderCV = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
                memmberName = "{}".format(str(noobcoder.getContact(op.param2).displayName))
                memmberPP = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(op.param2).pictureStatus)
                memmberCV = "https://obs.line-scdn.net/{}".format(noobcoder.getProfileCoverURL(op.param2))
                TtempWelcomeMessage(op.param1, memmberPP, memmberName, Message, noobcoderPP)
                time.sleep(2)
        if op.type == 130:
            if op.param1 in wait["GROUP"]['WM']['AP']:
                if op.param1 in wait["GROUP"]['WM']['S']:
                    TBotMessage(op.param1,text=None,contentMetadata=wait["GROUP"]['WM']['S'][op.param1]['Sticker'], contentType=7)
                if(wait["GROUP"]['WM']['P'][op.param1] in [""," ","\n",None]):
                    return
                if '@!' not in wait["GROUP"]['WM']['P'][op.param1]:
                    wait["GROUP"]['WM']['P'][op.param1] = '@!'+wait["GROUP"]['WM']['P'][op.param1]
                nama = noobcoder.getGroup(op.param1).name
                sd = noobcoder.waktunjir()
                noobcoder.sendMention(op.param1,wait["GROUP"]['WM']['P'][op.param1].replace('greeting',sd).replace('Greeting',sd).replace(';',nama),' 「 Welcome Message 」\n',[op.param2]*wait["GROUP"]['WM']['P'][op.param1].count('@!'))
        if op.type == 130:
            if op.param1 in protectjoin:
                if op.param2 not in noobcoderMID:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            noobcoder.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
        if op.type == 130:
            if op.param2 in wait["blacklist"]:
                try:
                    group = noobcoder.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    noobcoder.updateGroup(group)
                    noobcoder.kickoutFromGroup(op.param1,[op.param2])
                    group.preventedJoinByTicket = True
                    noobcoder.updateGroup(group)
                except Exception as e:
                    group = noobcoder.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    noobcoder.kickoutFromGroup(op.param1,[op.param2])
                    noobcoder.updateGroup(group)
#=====================================================================
        if op.type == 133:
            if op.param1 in protectKick:
                if op.param2 not in noobcoderMID:
                    try:
                        TBotMessage(op.param1, "Kick Detected , Protection on in this Group")
                        try: noobcoder.kickoutFromGroup(op.param1,[op.param2])
                        except: pass
                        noobcoder.sendContact(op.param1, op.param2)
                    except:
                        pass
#=====================================================================
        if op.type in [22,24]:
#    	if noobcoder.getProfile().mid in op.param3:
            if wait["leaveMC"] == True:
                #noobcoder.sendMessage(op.param1,"Auto Leave Multi Chat")
                noobcoder.leaveRoom(op.param1)
#=====================================================================
        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}               
            text = msg.text
            msg_id = msg.id
            receiver = msg.to             
            sender = msg._from
            s = noobcoder.getProfile().mid
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False:
               setKey = ''
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:                    	
                    if sender != noobcoder.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if sender != s:
                            peler["receivercount"] += 1
                        if sender == s:
                            peler["sendcount"] += 1
#=====================================================================
        if op.type == 25 or op.type == 26:
            msg = op.message 
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.contentType == 0:
                msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
            if msg.contentType == 1:
                    path = noobcoder.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Picture is Below',"data":path,"from":msg._from,"createdTime":msg.createdTime}
            if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n│ Sticker ID : {}".format(stk_id)
                   ret_ += "\n│ Sticker Version : {}".format(stk_ver)
                   ret_ += "\n│ Sticker Package : {}".format(pkg_id)
                   ret_ += "\n│ Sticker Url : line://shop/detail/{}".format(pkg_id)
                   ret_ += "\n╰─「 Finish 」"
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = noobcoder.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}         
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
            if msg.contentType == 13:
                if msg._from in noobcoderMID:
                    if settings["invite"] == True:
                        msg.contentType = 0
                        contact = noobcoder.getContact(msg.contentMetadata["mid"])
                        invite = msg.contentMetadata["mid"]
                        groups = noobcoder.getGroup(msg.to)
                        pending = groups.invitee
                        targets = []
                        for s in groups.members:
                            if invite in wait["blacklist"]:
                                noobcoder.sendMessage(msg.to, "Unban before Inviting.")
                                break
                            else:
                                targets.append(invite)
                        if targets == []:
                            pass
                        else:
                             for target in targets:
                                 try:
                                      noobcoder.findAndAddContactsByMid(target)
                                      noobcoder.inviteIntoGroup(msg.to,[target])
                                      ryan = noobcoder.getContact(target)
                                      zx = ""
                                      zxc = ""
                                      zx2 = []
                                      xpesan =  "•Invite• : "
                                      ret_ = "• ♥"
                                      ry = str(ryan.displayName)
                                      pesan = ''
                                      pesan2 = pesan+"@MAX\n"
                                      xlen = str(len(zxc)+len(xpesan))
                                      xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                      zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                      zx2.append(zx)
                                      zxc += pesan2
                                      text = xpesan + zxc + ret_ + ""
                                      noobcoder.sendMessage(msg.to, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                      settings["invite"] = False
                                      break
                                 except:
                                      noobcoder.sendText(msg.to,"• คุณมีขีด จำกัด ในการเชิญเพื่อน")
                                      settings["invite"] = False
                                      break
# =====================================================================
        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
            if komen["komenan"] == True:
                if msg.contentType == 16:
                    try:
                        purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                        if purl[1] not in wait['postId']:
                            noobcoder.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            TBotMessage(to, "Your post has been liked")
                            noobcoder.createComment(purl[0], purl[1], settings["commentPost"])
                            wait['postId'].append(purl[1])
                    except Exception as e:
                        purl = msg.contentMetadata['postEndUrl'].split('homeId=')[1].split('&postId=')
                        if purl[1] not in wait['postId']:
                            noobcoder.likePost(msg._from, purl[1], random.choice([1001,1002,1003,1004,1005]))
                            TBotMessage(to, "Your post has been liked")
                            noobcoder.createComment(msg._from, purl[1], settings["commentPost"])
                            wait['postId'].append(purl[1])
                        else:pass
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 6:
                    try:
                        contact = noobcoder.getContact(sender)
                        if msg.toType == 2:
                            anu = noobcoder.getGroup(to)
                            if msg.contentMetadata['GC_EVT_TYPE'] == 'S' and msg.contentMetadata['GC_MEDIA_TYPE'] == 'LIVE':
                                anu = msg.contentMetadata={'GC_EVT_TYPE': 'S', 'GC_CHAT_MID': to, 'RESULT': 'INFO', 'SKIP_BADGE_COUNT': 'false', 'GC_IGNORE_ON_FAILBACK': 'false', 'TYPE': 'G', 'DURATION': '0', 'GC_MEDIA_TYPE': 'VIDEO', 'VERSION': 'X', 'CAUSE': '16'}
                    except Exception as e:
                        TBotMessage(to, str(e))
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.contentType == 0 and sender not in noobcoderMID and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        if sets["tagsticker"] == True:
                            name = re.findall(r'@(\w+)', msg.text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            for mention in mentionees:
                                 if noobcoderMID in mention["M"]:
                                      msg = sets["messageStickerz"]["listStickerz"]["responSticker"]
                                      if msg != None:
                                          contact = noobcoder.getContact(noobcoderMID)
                                          a = contact.displayName
                                          stk = msg['STKID']
                                          spk = msg['STKPKGID']
                                          data={'type':'template','altText': str(a)+' Respon Sticker','template':{'type':'image_carousel','columns':[{'imageUrl':'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png'.format(stk),'action':{'type':'uri','uri':'https://line.me/S/sticker/{}'.format(spk)}}]}}
                                          sendTemplate(to, data)
                                      else:
                                          contact = noobcoder.getContact(noobcoderMID)
                                          a = contact.displayName
                                          stk = msg['STKID']
                                          spk = msg['STKPKGID']
                                          data={'type':'template','altText': str(a)+' send a sticker','template':{'type':'image_carousel','columns':[{'imageUrl':'https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png'.format(stk),'action':{'type':'uri','uri':'https://line.me/S/sticker/{}'.format(spk)}}]}}
                                          sendTemplate(to, data)
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            cmd = command(text)
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ""
            isValid = True
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.toType == 0 and settings["autoReply"] and sender != noobcoderMID:
                    contact = noobcoder.getContact(sender)
                    if contact.attributes != 32 and "[ auto reply ]" not in text.lower():
                        msgSticker = settings["messageSticker"]["listSticker"]["replySticker"]
                        if msgSticker != None:
                            sid = msgSticker["STKID"]
                            spkg = msgSticker["STKPKGID"]
                            sver = msgSticker["STKVER"]
                            sendSticker(to, sver, spkg, sid)
                        if "@!" in settings["replyPesan"]:
                            msg_ = settings["replyPesan"].split("@!")
                            sendMention(to, sender, "「Sleep Mode」\n" + msg_[0], msg_[1])
                        sendMention(to, sender, "「Sleep Mode」\n", settings["replyPesan"])
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.contentType == 0 and sender not in noobcoderMID and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if noobcoderMID in mention["M"]:
                                if settings["autoRespon"] == True:
                                    if "@!" not in settings["responMessage"]:
                                        mentions(to, settings["responMessage"] + " @!", [sender])
                                        stc = dstckr["sticker"]["stkid"]
                                        pkc = dstckr["sticker"]["pkgid"]
                                        noobcoder.sendSticker(to, pkc, stc)
                                    else:
                                        mentions(to, settings["responMessage"], [sender])
                                        stc = dstckr["sticker"]["stkid"]
                                        pkc = dstckr["sticker"]["pkgid"]
                                        noobcoder.sendSticker(to, pkc, stc)
                                        break
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 0 and sender not in noobcoderMID:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if noobcoderMID in mention["M"]:
                                if to not in wait['ROM']:
                                    wait['ROM'][to] = {}
                                if msg._from not in wait['ROM'][to]:
                                    wait['ROM'][to][msg._from] = {}
                                if 'msg.id' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['msg.id'] = []
                                if 'waktu' not in wait['ROM'][to][msg._from]:
                                    wait['ROM'][to][msg._from]['waktu'] = []
                                wait['ROM'][to][msg._from]['msg.id'].append(msg.id)
                                wait['ROM'][to][msg._from]['waktu'].append(msg.createdTime)
                                autoresponuy(to,msg,wait)
                                break
                if msg._from not in noobcoderMID:
                    if msg._from in banlist:
                        noobcoder.kickoutFromGroup(msg.to, [msg._from])
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    if settings["notag"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if noobcoderMID in mention["M"]:
                               noobcoder.sendMention(to, "I said the fuck up @!:)","",[msg._from])
                               noobcoder.kickoutFromGroup(msg.to, [msg._from])
                               break
                if 'MENTION' in msg.contentMetadata.keys() != None:
                    if temptag["stealtag"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if noobcoderMID in mention["M"]:                      	
                                contact = noobcoder.getContact(sender)
                                TaggerPP = "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                                Message = temptag["pesanya"]
                                TaggerName= "{}".format(contact.displayName)
                                TtempTagResponse(to, TaggerPP, TaggerName, Message)
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if settings["autoRead"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                if msg.text:
                    if msg.text.lower().lstrip().rstrip() in wbanlist:
                        if msg.text not in noobcoderMID:
                            try:
                                noobcoder.kickoutFromGroup(msg.to,[sender])
                            except Exception as e:
                                 print(e)
                if msg.contentType == 22 and inSteals(sender):
                    if msg.toType == 0:to = sender
                    true=True
                    data = {
                        "type": "flex",
                        "altText": msg.contentMetadata["ALT_TEXT"],
                        "contents": json.loads(msg.contentMetadata['FLEX_JSON'])
                    }
                    sendTemplate(to, data)
                    with open("flex.txt", "w+") as f:
                      f.write(str(json.dumps(data, indent=4, sort_keys=True)))                                 
                if msg.contentType == 13:
                    if wait2["detectSContact"]["status"] == True and msg.toType==2 and sender not in wait["bots"]:
                        if msg.to not in wait2["detectSContact"]["tmp"]:
                            wait2["detectSContact"]["tmp"][msg.to]={sender:{"pelaku":sender,"createdTime":time.time(),"spamCount":1}}
                            print("[DETECT SPAM CONTACT] INITIALIZE")
                        elif msg.to in wait2["detectSContact"]["tmp"]:
                            if sender not in wait2["detectSContact"]["tmp"][msg.to]:
                                wait2["detectSContact"]["tmp"][msg.to][sender]={"pelaku":sender,"createdTime":time.time(),"spamCount":1}
                                print("[DETECT SPAM CONTACT] 2")
                            elif sender in wait2["detectSContact"]["tmp"][msg.to]:
                                wait2["detectSContact"]["tmp"][msg.to][sender]["spamCount"]=wait2["detectSContact"]["tmp"][msg.to][sender]["spamCount"]+1
                                print("[DETECT SPAM CONTACT] 3")
                                if wait2["detectSContact"]["tmp"][msg.to][sender]["spamCount"]==3:
                                    if time.time() - wait2["detectSContact"]["tmp"][msg.to][sender]["createdTime"]<=30:
                                        print(time.time() - wait2["detectSContact"]["tmp"][msg.to][sender]["createdTime"])
                                        mentions(to, "Kicker Lo Ya @! Jancuk", [sender])
                                        Thread(target=noobcoder.kickoutFromGroup, args=(msg.to, [sender])).start()
                                        del wait2["detectSContact"]["tmp"][msg.to][sender]
                                    else:
                                        del wait2["detectSContact"]["tmp"][msg.to][sender] 
                if msg.contentType == 6:
                    if msg.toType == 2 and msg._from not in noobcoderMID:
                        ps = msg._from
                        if to in wait["notificationCall"]:
                            b = msg.contentMetadata['GC_EVT_TYPE']
                            c = msg.contentMetadata["GC_MEDIA_TYPE"]
                            if c == "VIDEO" and b == "S":
                                a = '「 Video Call Group Started 」\n'
                                a += "\nGroup {} Started".format(c)
                                a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                a += "\nStarted In: {}".format(humanize.naturaltime(datetime.fromtimestamp(msg.createdTime/1000)))
                                a += "\nStarted By: @!"
                                noobcoder.sendMention(to, str(a),"",[msg._from])
                            if c == 'AUDIO' and b == "S":
                                a = '「 Audio Call Group Started 」\n'
                                a += "\nGroup {} Started".format(c)
                                a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                a += "\nStarted In: {}".format(humanize.naturaltime(datetime.fromtimestamp(msg.createdTime/1000)))
                                a += "\nStarted By: @!"
                                noobcoder.sendMention(to, str(a),"",[msg._from])
                            if c == 'LIVE' and b == 'S':
                                a = '「 Live Group Started 」\n'
                                a += "\nGroup {} Started".format(c)
                                a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                a += "\nStarted In: {}".format(humanize.naturaltime(datetime.fromtimestamp(msg.createdTime/1000)))
                                a += "\nStarted By: @!"
                                noobcoder.sendMention(to, str(a),"",[msg._from])
                            else:
                                mills = int(msg.contentMetadata["DURATION"])
                                seconds = (mills/1000)%60
                                if c == "VIDEO" and b == "E":
                                    a = '「 Video Call Group Ended 」\n'
                                    a += "\nGroup {} Ended".format(c)
                                    a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                    a += "\nDuration: {} Second".format(seconds)
                                    a += "\nEnded By: @!"
                                    noobcoder.sendMention(to, str(a),"",[msg._from])
                                if c == "AUDIO" and b == "E":
                                    a = '「 Audio Call Group Ended 」\n'
                                    a += "\nGroup {} Ended".format(c)
                                    a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                    a += "\nDuration: {} Second".format(seconds)
                                    a += "\nEnded By: @!"
                                    noobcoder.sendMention(to, str(a),"",[msg._from])
                                if c == "LIVE" and b == "E":
                                    a = '「 Live Group Ended 」\n'
                                    a += "\nGrup {} Ended".format(c)
                                    a += "\nIn Group: {}".format(noobcoder.getGroup(to).name)
                                    a += "\nDuration: {} Second".format(seconds)
                                    a += "\nEnded By: @!"
                                    noobcoder.sendMention(to, str(a),"",[msg._from])
                        if to in wait["notificationCallPrank"]:
                            b = msg.contentMetadata['GC_EVT_TYPE']
                            c = msg.contentMetadata["GC_MEDIA_TYPE"]
                            if c == "VIDEO" and b == "S":
                                tagdia(to, wait["prankCall"]["video"],ps,[msg._from])
                            if c == 'AUDIO' and b == "S":
                                tagdia(to, wait["prankCall"]["audio"],ps,[msg._from])
                            if c == 'LIVE' and b == 'S':
                                tagdia(to, wait["prankCall"]["live"],ps,[msg._from])
                if msg.contentType == 0:
                    if "/ti/g/" in text.lower():
                        if settings["autoJoin"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = noobcoder.findGroupByTicket(ticket_id)
                                if len(group.members) >= wait["Members"]:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                else:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    noobcoder.leaveGroup(group.id)
#=====================================================================
        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] BOT SEND MESSAGE")
            else: print ("[ 26 ] BOT RECEIVE MESSAGE")
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.contentType == 13:
                if len(Lexe["lscon"]) <= 100:
                            if Lexe["lscon"] == {}:
                                Lexe["lscon"][1] = msg.contentMetadata["mid"]
                                Lexe["lstatus"] = False
                            else:
                                if Lexe["lstatus"] == True:
                                    Lexe["lscon"] = {}
                                num = len(Lexe["lscon"])
                                num +=1
                                Lexe["lscon"][num] = msg.contentMetadata["mid"]
                else:
                            Lexe["lscon"] = {}
                            if Lexe["lscon"] == {}:
                                Lexe["lscon"][1] = msg.contentMetadata["mid"]
                                Lexe["lstatus"] = False
            if msg.to not in unsendchat:
                unsendchat[msg.to] = {}
            if msg_id not in unsendchat[msg.to]:
                unsendchat[msg.to][msg_id] = msg_id
            msgdikirim[msg_id] = {"text":text}
            to = msg.to
            isValid = True
            cmd = command(text)
            setkey = settings['keyCommand'].title()
            if settings['setKey'] == False: setkey = ''
            if isValid != False:
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    try:
                        if msg.to not in wait['Unsend']:
                            wait['Unsend'][msg.to] = {'B':[]}
                        #if msg._from not in [noobcoderMID]:
                            #return
                        wait['Unsend'][msg.to]['B'].append(msg.id)
                    except:pass
                if msg.contentType == 0:
                    if msg.toType == 0 or msg.toType == 2:
                        if cmd == "existsb" and sender == noobcoderMID:
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyMessage(msg.id, to, "Your selfbot has been logged out.")
                            sys.exit("Logout")
                    if waitgroup["cmd"] == "":
                        cmds = command(text)
                        cmd = " ".join(cmds.split())
                    else:
                        cmds = waitgroup["cmd"]
                        cmd = " ".join(cmds.split())
                        to = waitgroup["remotGroup"]
                    if sender in noobcoderMID or sender in admins or sender in maker:
                      for cmd in cmd.split(" & "):
                        if cmd == "unmute":
                            if to in wait["muteGroup"]:
                                del wait["muteGroup"][to]
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(to, "Selfbot activated now.")
                                else:
                                    TBotMessage(msg.to, "Selfbot activated now.")
                            else:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(to, "Selfbot Already activated.")
                                else:
                                    TBotMessage(msg.to, "Selfbot Already activated.")
                        elif cmd == "muteall":
                            groups = noobcoder.getGroupIdsJoined()
                            for g in groups:
                                wait["muteGroup"][g] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Selfbot deactivated in {} groups.".format(len(groups)))
                            else:
                                TBotMessage(msg.to, "Selfbot deactivated in {} groups.".format(len(groups)))
                        elif cmd == "unmuteall":
                            groups = noobcoder.getGroupIdsJoined()
                            for g in groups:
                                del wait["muteGroup"][g]
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Selfbot activated in {} groups.".format(len(groups)))
                            else:
                                TBotMessage(msg.to, "Selfbot activated in {} groups.".format(len(groups)))
                        elif cmd == "list mutes" or cmd == "mutes":
                            groups = wait["muteGroup"]
                            ret_ = ""
                            no = 0 + 1
                            for gid in groups:
                                group = noobcoder.getGroup(gid)
                                ret_ += "\n{}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                no += 1
                            ret_ += "\n\nSelfbot on mute for {} groups.".format(str(len(groups)))
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "𝗚𝗥𝗢𝗨𝗣𝗦 𝗢𝗡 𝗠𝗨𝗧𝗘\n\n" + str(ret_))
                            else:
                                TBotMessageWithHeader(msg.to, "𝗚𝗥𝗢𝗨𝗣𝗦 𝗢𝗡 𝗠𝗨𝗧𝗘" , str(ret_))
#-------------------------------------------------------------------------------
                        elif to in wait["muteGroup"]: return
#-------------------------------------------------------------------------------
                        elif "#remote" in cmd:
                            function = lambda s:s[:1].lower() + s[1:] if s else ''
                            number = cmd.split("#remote:")[1];number = number.split()[0];noobcoder.getGroupIdsJoined()
                            if number.isdigit():number = int(number);lol = noobcoder.getGroupIdsJoined()[number-1];to = lol
                            cmd = cmd.replace("#remote:%s"%number,"").lstrip().rstrip()
                            if '#remote:' in text:text = text.replace("#remote:%s"%number,"").lstrip().rstrip();function(text)
                            else:text = text.replace("#remote:%s"%number,"").lstrip().rstrip();function(text)
                            if msg.toType == 0:msg.to = sender
                            elif msg.toType == 2:msg.to = msg.to
                            noobcoder.sendMessage(msg.to, "Command '%s' has been send to : %s" % (cmd, noobcoder.getGroup(lol).name))
#"  • Cleanse #remote:1"
                        elif cmd == "help":
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, textMainHelp)
                            else:
                                TtempMainHelp(to)
                        elif cmd == "mute":
                            if to not in wait["muteGroup"]:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(to, "Selfbot deactivated in here.")
                                else:
                                    TBotMessage(msg.to, "Selfbot deactivated in here.")
                                wait["muteGroup"][to] = True
#=====================================================================
# Mybot: Done
                        elif cmd == "mybot":
                            ret  = " ☞  here\n"
                            ret += " ☞  ping\n"
                            ret += " ☞  speed\n"
                            ret += " ☞  about\n"
                            ret += " ☞  check\n"
                            ret += " ☞  status\n"
                            ret += " ☞  restart\n"
                            ret += " ☞  .unsend [num]\n"
                            ret += " ☞  unsend [num]\n"
                            ret += " ☞  undo [num]\n"
                            ret += " ☞  set flag: [text]\n"
                            ret += " ☞  mute\n"
                            ret += " ☞  muteall\n"
                            ret += " ☞  unmute\n"
                            ret += " ☞  unmuteall\n"
                            ret += " ☞  admin [mention]\n"
                            ret += " ☞  admin lcon[num]\n"
                            ret += " ☞  adminslist\n"
                            ret += " ☞  contact admins\n"
                            ret += " ☞  clear admins\n"
                            ret += " ☞  addinvite [mention]\n"
                            ret += " ☞  addinvite lcon[num]\n"
                            ret += " ☞  invitelist\n"
                            ret += " ☞  expel [mention]\n"
                            ret += " ☞  expel lcon[num]"
                            if wait["flex"] == True:
                                TtempListMenu(to, "MYBOT", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗠𝗬𝗕𝗢𝗧\n\n" + str(ret))
                        elif cmd == "here":
                            noobcoder.sendMention(to, "Yes I am here @!","",[msg._from])
                        elif cmd == "ping":
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyMessage(msg.id, to,"Pong")
                        elif cmd == "speed":
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, speedTestSelfbot())
                            else:
                                TBotMessage(msg.to, speedTestSelfbot())
                        elif cmd == "about":
                            arr = []
                            today = datetime.today()
                            thn = 2018
                            bln = 8    #isi bulannya yg sewa
                            hr = 9   #isi tanggalnya yg sewa
                            future = datetime(thn, bln, hr)
                            days = (str(future - today))
                            comma = days.find(",")
                            days = days[:comma]
                            h = noobcoder.getContact(noobcoderMID)
                            groups = noobcoder.getGroupIdsJoined()
                            contactlist = noobcoder.getAllContactIds()
                            kontak = noobcoder.getContacts(contactlist)
                            favorite = noobcoder.getFavoriteMids()
                            pendinglist = noobcoder.getGroupIdsInvited()
                            userid = noobcoder.getProfile().userid
                            region = noobcoder.getProfile().regionCode
                            autoblock = noobcoder.talk.getBlockedRecommendationIds() + noobcoder.getBlockedContactIds()
                            fil = noobcoder.getSettings().privacyReceiveMessagesFromNotFriend
                            seal = noobcoder.getSettings().e2eeEnable
                            blockedlist = noobcoder.getBlockedContactIds()
                            src = noobcoder.getSettings().privacySearchByUserid
                            nnm = noobcoder.getSettings().notificationNewMessage
                            ngi = noobcoder.getSettings().notificationGroupInvitation
                            nsm = noobcoder.getSettings().notificationShowMessage
                            nic = noobcoder.getSettings().notificationIncomingCall
                            psc = noobcoder.getSettings().privacySyncContacts
                            psbpn = noobcoder.getSettings().privacySearchByPhoneNumber
                            psbe = noobcoder.getSettings().privacySearchByEmail
                            pasddl = noobcoder.getSettings().privacyAllowSecondaryDeviceLogin
                            ppiptmh = noobcoder.getSettings().privacyProfileImagePostToMyhome
                            pan = noobcoder.getSettings().privacyAllowNearby
                            nm = noobcoder.getSettings().notificationMention
                            kontak2 = noobcoder.getContacts(blockedlist)
                            if src == True:alid = "Add From LineID : True"
                            else:alid = "Add From LineID : False"
                            if seal == True:letsel = "Letter Sealing : True"
                            if seal == False:letsel = "Letter Sealing : False"
                            if fil == True:fpes = "Filter Message : False"
                            if fil == False:fpes = "Filter Message : True"
                            if nnm == True:notificationNewMessage = "True"
                            if nnm == False:notificationNewMessage = "False"
                            if ngi == True:notificationGroupInvitation = "True"
                            if ngi == False:notificationGroupInvitation = "False"
                            if nsm == True:notificationShowMessage = "True"
                            if nsm == False:notificationShowMessage = "False"
                            if nic == True:notificationIncomingCall = "True"
                            if nic == False:notificationIncomingCall = "False"
                            if psc == True:privacySyncContacts = "True"
                            if psc == False:privacySyncContacts = "False"
                            if psbpn == True:privacySearchByPhoneNumber = "True"
                            if psbpn == False:privacySearchByPhoneNumber = "False"
                            if psbe == True:privacySearchByEmail = "True"
                            if psbe == False:privacySearchByEmail = "False"
                            if pasddl == True:privacyAllowSecondaryDeviceLogin = "True"
                            if pasddl == False:privacyAllowSecondaryDeviceLogin = "False"
                            if ppiptmh == True:privacyProfileImagePostToMyhome = "True"
                            if ppiptmh == False:privacyProfileImagePostToMyhome = "False"
                            if pan == True:privacyAllowNearby = "True"
                            if pan == False:privacyAllowNearby = "False"
                            if nm == True:notificationMention = "True"
                            if nm == False:notificationMention = "False"
                            ret_ = "\nName : {}".format(h.displayName)
                            ret_ += "\nGroup : {}".format(str(len(groups)))
                            ret_ += "\nGpending : {}".format(str(len(pendinglist)))
                            ret_ += "\nFriend : {}".format(str(len(kontak)))
                            ret_ += "\nFavorite: {}".format(str(len(favorite)))
                            ret_ += "\nBlocked : {}".format(str(len(kontak2)))
                            ret_ += "\nAutoBlock : {}".format(str(len(autoblock)))
                            ret_ += "\nUserID : {}".format(str(userid))
                            ret_ += "\nRegion : {}".format(str(region))
                            ret_ += "\nChat send : {}".format(str(peler["sendcount"]))
                            ret_ += "\nChat received : {}".format(str(peler["receivercount"]))
                            ret_ += "\n{}".format(alid)
                            ret_ += "\n{}".format(letsel)
                            ret_ += "\n{}".format(fpes)
                            ret_ += "\nNewMessage : {}".format(notificationNewMessage)
                            ret_ += "\nGroupInvitation : {}".format(notificationGroupInvitation)
                            ret_ += "\nShowMessage : {}".format(notificationShowMessage)
                            ret_ += "\nIncomingCall : {}".format(notificationIncomingCall)
                            ret_ += "\nSyncContacts : {}".format(privacySyncContacts)
                            ret_ += "\nSearchByPNumber : {}".format(privacySearchByPhoneNumber)
                            ret_ += "\nSearchByEmail : {}".format(privacySearchByEmail)
                            ret_ += "\nAllowDeviceLogin : {}".format(privacyAllowSecondaryDeviceLogin)
                            ret_ += "\nPImagePostToMyhome : {}".format(privacyProfileImagePostToMyhome)
                            ret_ += "\nAllowNearby : {}".format(privacyAllowNearby)
                            ret_ += "\nNotifMention : {}".format(notificationMention)
                            ret_ += "\n\nType : Selfbot Template"
                            ret_ += "\nVersion : V.2 R.43"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "𝗔𝗕𝗢𝗨𝗧 𝗦𝗘𝗟𝗙𝗕𝗢𝗧\n"+ str(ret_))
                            else:
                                TBotMessageWithHeaderFooter(msg.to, "ABOUT SELFBOT", str(ret_))
                        elif cmd == "check":
                            try:
                                noobcoder.inviteIntoGroup(to, noobcoder.profile.mid)
                                has1 = "OK"
                            except BaseException:
                                has1 = "NOT"
                            if has1 == "OK":
                                sil1 = "OK"
                            else:
                                sil1 = "NOT OK"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Kick/Invite: {}".format(sil1))
                            else:
                                TBotMessage(msg.to, "Kick/Invite: {}".format(sil1))
                        elif cmd == "status":
                            if settings["autoAdd"] == True:txt = "\n ☞  Autoadd: ON♪"
                            else:txt = "\n ☞  Autoadd: OFF♪"
                            if settings["autoJoin"] == True:txt += "\n ☞  AutoJoin: ON♪"
                            else:txt += "\n ☞  AutoJoin: OFF♪"
                            if settings["notag"] == True:txt += "\n ☞  Antitag: ON♪"
                            else:txt += "\n ☞  Antitag: OFF♪"
                            if komen["komenan"] == True:txt += "\n ☞  LikePost: ON♪"
                            else:txt += "\n ☞  LikePost: OFF♪"
                            if temptag["stealtag"] == True:txt += "\n ☞  Respontag: ON♪"
                            else:txt += "\n ☞  Respontag: OFF♪"
                            if wmin["wMessage"] == True:txt += "\n ☞  Welcometemp: ON♪"
                            else:txt += "\n ☞  Welcometemp: OFF♪"
                            if lvin["lMessage"] == True:txt += "\n ☞  Leavetemp: ON♪"
                            else:txt += "\n ☞  Leavetemp: OFF♪"
                            if settings["autoReply"] == True:txt += "\n ☞  SleepMode: ON♪"
                            else:txt += "\n ☞  SleepMode: OFF♪"
                            if settings["unsendMessage"] == True:txt += "\n ☞  Resendchat: ON♪"
                            else:txt += "\n ☞  Resendchat: OFF♪"
                            if wait["leaveMC"] == True:txt += "\n ☞  MultiChat: ON♪"
                            else:txt += "\n ☞  MultiChat: OFF♪"
                            if sets["tagsticker"] == True:txt += "\n ☞  ResponSticker: ON♪"
                            else:txt += "\n ☞  ResponSticker: OFF♪"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "𝗦𝗘𝗟𝗙𝗕𝗢𝗧 𝗦𝗧𝗔𝗧𝗨𝗦\n"+ str(txt))
                            else:
                                TBotMessageWithHeaderFooter(msg.to, "SELFBOT STATUS", str(txt))
                        elif cmd == "restart":# and sender == noobcoderMID:
                            try:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Restarting selfbot ...")
                                else:
                                    TBotMessageWithFooter(to, "Restarting selfbot ...")
                            except: pass
                            settings["restartPoint"] = to
                            restartBot()
                        elif cmd.startswith(".unsend "):
                            args = removeCmd(".unsend", text)
                            mes = 0
                            try:
                                mes = int(args[1])
                            except:
                                mes = 1
                            M = noobcoder.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind, i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == noobcoder.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break

                            def unsMes(id):
                                noobcoder.unsendMessage(id)

                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                                test = noobcoder.generateReplyMessage(msg_id)
                                noobcoder.unsendMessage(test.relatedMessageId)
                        elif cmd.startswith('unsend '):
                            noobcoder.unsendMessage(msg.id)
                            j = int(msg.text.split(' ')[1])
                            a = [noobcoder.adityasplittext(msg.text, 's').replace('{} '.format(j), '')] * j
                            if len(msg.text.split(' ')) == 2:
                                h = wait['Unsend'][msg.to]['B']
                                n = len(wait['Unsend'][msg.to]['B'])
                                for b in h[:j]:
                                    try:
                                        noobcoder.unsendMessage(b)
                                        wait['Unsend'][msg.to]['B'].remove(b)
                                    except:
                                        pass
                                t = len(wait['Unsend'][msg.to]['B'])
                            #                              noobcoder.generateReplyMessage(msg.id)
                            #                              noobcoder.sendReplyMessage(msg.id, to," 「 Unsend 」\nUnsend {} message".format((n-t)))
                            if len(msg.text.split(' ')) >= 3: h = [noobcoder.unsendMessage(TBotMessage(to, noobcoder.adityasplittext(msg.text, 's')).id) for b in a]
                        elif cmd.startswith("set flag: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Customer["userFlag"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to,"Squad flag name changed to " + Customer["userFlag"])
                            else:
                                TBotMessage(msg.to,"Squad flag name changed to " + Customer["userFlag"])
                        elif cmd.startswith("admin "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num = 0
                                for a in hasil:
                                    if a not in admins:
                                        admins.append(a)
                                        num += 1
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Promoted {} as Admins.".format(num))
                                else:
                                    TBotMessage(msg.to, "Promoted {} as Admins.".format(num))
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    num = 0
                                    for a in targets:
                                        if a not in admins:
                                            admins.append(a)
                                            num += 1
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Promoted {} as Admins.".format(num))
                                    else:
                                        TBotMessage(msg.to, "Promoted {} as Admins.".format(num))
                        elif cmd == "adminslist" or cmd == "admins" or cmd == "listadmins":
                            if wait["flex"] == False:
                                list20WithHeading(to,"𝗔𝗗𝗠𝗜𝗡𝗦","Admins",admins)
                            else:
                                Tlist20WithHeading(to,"ADMINS","Admins",admins)
                        elif cmd == "contact admins" or cmd == "adminscontact":
                            for a in admins:
                                noobcoder.sendContact(msg.to, a)
                        elif cmd == "clear admins" or cmd == "clearadminslist":
                            admins.clear()
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to,"Adminslist is cleared.")
                            else:
                                TBotMessage(msg.to, "Adminslist is  cleared.")
                        elif cmd.startswith("addinvite "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num = 0
                                for a in hasil:
                                    if a not in invitelist:
                                        invitelist.append(a)
                                        num += 1
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Added {} to Invitelist.".format(num))
                                else:
                                    TBotMessage(msg.to, "Added {} to Invitelist.".format(num))
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    num = 0
                                    for a in targets:
                                        if a not in invitelist:
                                            invitelist.append(a)
                                            num += 1
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Added {} to Invitelist.".format(num))
                                    else:
                                        TBotMessage(msg.to, "Added {} to Invitelist.".format(num))
                        elif cmd == "ilist" or cmd == "invitelist":
                            if wait["flex"] == False:
                                list20WithHeading(to,"𝗜𝗡𝗩𝗜𝗧𝗘𝗦 𝗟𝗜𝗦𝗧", "Members in Invitelist",invitelist)
                            else:
                                Tlist20WithHeading(to,"INVITE LIST","Members in Invitelist.",invitelist)
                        elif cmd == "contact invites" or cmd == "invitescontact":
                            for a in invitelist:
                                noobcoder.sendContact(msg.to, a)
                        elif cmd == "clearinvites" or cmd == "clearinvitelist":
                            invitelist.clear()
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to,"Invitelist is cleared.")
                            else:
                                TBotMessage(msg.to, "Invitelist is  cleared.")
                        elif cmd.startswith("expel "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            friends = noobcoder.getAllContactIds()
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num2 = 0
                                tx =  ""
                                for a in hasil:
                                    if a in admins and (sender in maker or sender in noobcoderMID):
                                        admins.remove(a)
                                        num2 += 1
                                        tx += "{} is Expelled from Adminstlist.\n".format(noobcoder.getContact(a).displayName)
                                    elif a in bots:
                                        bots.remove(a)
                                        num2 += 1
                                        tx += "{} is Expelled from Botslist.\n".format(noobcoder.getContact(a).displayName)
                                    elif a in invitelist:
                                        invitelist.remove(a)
                                        num2 += 1
                                        tx += "{} is Expelled from Invitelist.\n".format(noobcoder.getContact(a).displayName)
                                    elif a in whitelist:
                                        whitelist.remove(a)
                                        num2 += 1
                                        tx += "{} is Expelled from Whitelist.\n".format(noobcoder.getContact(a).displayName)
                                tx += "\n{} Users expelled.".format(num2)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, tx)
                                else:
                                    TBotMessage(to, tx)
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    num2 = 0
                                    tx =  ""
                                    for a in targets:
                                        if a in admins and (sender in maker or sender in noobcoderMID):
                                            admins.remove(a)
                                            num2 += 1
                                            tx += "{} is expelled from Adminstlist.\n".format(noobcoder.getContact(a).displayName)
                                        elif a in bots:
                                            bots.remove(a)
                                            num2 += 1
                                            tx += "{} is expelled from Botslist.\n".format(noobcoder.getContact(a).displayName)
                                        elif a in invitelist:
                                            invitelist.remove(a)
                                            num2 += 1
                                            tx += "{} is expelled from Invitelist.\n".format(noobcoder.getContact(a).displayName)
                                        elif a in whitelist:
                                            whitelist.remove(a)
                                            num2 += 1
                                            tx += "{} is Expelled from Whitelist.\n".format(noobcoder.getContact(a).displayName)
                                    tx += "\n{} Users expelled.".format(num2)
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, tx)
                                    else:
                                        TBotMessage(to, tx)
#=====================================================================
# Myself Done
                        elif cmd == "myself":
                            ret = " ☞  myname\n"
                            ret += " ☞  mybio\n"
                            ret += " ☞  mypicture\n"
                            ret += " ☞  mycover\n"
                            ret += " ☞  myvideo\n"
                            ret += " ☞  myprofile\n"
                            ret += " ☞  mymid\n"
                            ret += " ☞  delallchat\n"
                            ret += " ☞  me\n"
                            ret += " ☞  me2\n"
                            ret += " ☞  me3\n"
                            ret += " ☞  myticket"
                            if wait["flex"] == True:
                                TtempListMenu(to, "MYSELF", str(ret))
                            else:
                                noobcoder.sendMessage(to, "   𝗠𝗬𝗦𝗘𝗟𝗙\n\n" + str(ret))
                        elif cmd == "myname" and sender == noobcoderMID:
                            h = noobcoder.getContact(noobcoderMID)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(to, "𝗣𝗥𝗢𝗙𝗜𝗟𝗘 𝗡𝗔𝗠𝗘\n\n"+str(h.displayName))
                            else:
                                TBotMessageWithHeader(msg.to, "PROFILE NAME", str(h.displayName))
                        elif cmd == "mybio" and sender == noobcoderMID:
                            h = noobcoder.getContact(noobcoderMID)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(to, "𝗣𝗥𝗢𝗙𝗜𝗟𝗘 𝗦𝗧𝗔𝗧𝗨𝗦\n\n" + str(h.statusMessage))
                            else:
                                TBotMessageWithHeader(msg.to, "PROFILE STATUS", str(h.statusMessage))
                        elif cmd == "mypicture" and sender == noobcoderMID:
                            h = noobcoder.getContact(noobcoderMID)
                            image = "https://obs.line-scdn.net/" + h.pictureStatus
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyImageWithURL(msg.id, to, image)
                        elif cmd == "mycover" and sender == noobcoderMID:
                            h = noobcoder.getContact(noobcoderMID)
                            cu = noobcoder.getProfileCoverURL(noobcoderMID)
                            image = str(cu)
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyImageWithURL(msg.id, to, image)
                        elif cmd == "myvideo" and sender == noobcoderMID:
                            contact = noobcoder.getContact(sender)
                            if contact.videoProfile == None:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(to, "No Profile Video found.")
                                else:
                                    TBotMessage(msg.to, "No Profile Video found.")

                                
                            else:
                                data = {
                                    "type": "video",
                                    "originalContentUrl": "https://obs.line-scdn.net/{}/vp".format(contact.pictureStatus),
                                    "previewImageUrl": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                    }
                                sendTemplate(to, data)
                        elif cmd == "myprofile" and sender == noobcoderMID:
                            contact = noobcoder.getContact(noobcoderMID)
                            cu = noobcoder.getProfileCoverURL(noobcoderMID)
                            path = str(cu)
                            image = "https://obs.line-scdn.net/" + contact.pictureStatus
                            noobcoder.sendImageWithURL(to, image)
                            noobcoder.sendImageWithURL(to, path)
                            if wait["flex"] == False:
                                TBotMessage(msg.to, "𝗣𝗥𝗢𝗙𝗜𝗟𝗘\nMid : " + str(sender) + "\nName : " + str(contact.displayName) + "\nStatus :\n" + str(contact.statusMessage))
                            else:
                                TBotMessageWithHeader(msg.to, "PROFILE","Mid : "+str(sender)+"\nName : "+str(contact.displayName)+"\nStatus :\n"+str(contact.statusMessage))
                        elif cmd == "mymid" and sender == noobcoderMID:
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.id, to, "𝗠𝗜𝗗\n "+str(sender))
                            else:
                                TBotMessage(msg.to, "𝗠𝗜𝗗\n "+str(sender))
                        elif cmd == "delallchat" and sender == noobcoderMID:
                            noobcoder.removeAllMessages(op.param2)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.id, to, "All chat deleted.")
                            else:
                                TBotMessage(msg.to, "All chat deleted.")
                        elif cmd == "me" and sender == noobcoderMID:
                            taboutMe1(to)
                        elif cmd == "me2" and sender == noobcoderMID:
                            taboutMe2(to)
                        elif cmd == "me3" and sender == noobcoderMID:
                            msg.contentType = 13
                            # msg.contentMetadata = {'mid': mid}
                            noobcoder.sendContact(to, msg._from)
                            noobcoder.sendMessage(to, msg._from)
                        elif cmd == "myticket" and sender == noobcoderMID:
                            noobcoder.reissueUserTicket()
                            userid = "https://line.me/ti/p/" + noobcoder.getUserTicket().id
                            noobcoder.sendMessage(to, "𝗠𝘆 𝗧𝗶𝗰𝗸𝗲𝘁\n"+str(userid))
#=====================================================================
# profile Done
                        elif cmd == "profile":
                            ret  = " ☞  changepic\n"
                            ret += " ☞  changecover\n"
                            ret += " ☞  changedp video\n"
                            ret += " ☞  upname [name]\n"
                            ret += " ☞  upstatus [text]"
                            if wait["flex"] == True:
                                TtempListMenu(to, "MYPROFILE", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗠𝗬𝗣𝗥𝗢𝗙𝗜𝗟𝗘\n\n" + str(ret))
                        elif cmd == "changepic" and sender == noobcoderMID:
                            settings["changePicture"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "𝗖𝗛𝗔𝗡𝗚𝗘 𝗣𝗜𝗖𝗧𝗨𝗥𝗘\n"+" • Detail: Change Profile Picture\n • Status: Waiting for picture\n Please send a picture...")
                            else:
                                TBotMessageWithHeader(msg.to, "CHANGE PICTURE", " • Detail: Change Profile Picture\n • Status: Waiting for picture\n Please send a picture...")
                        elif cmd == "changecover" and sender == noobcoderMID:
                            settings["changeCoverProfile"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "aaa")
                                noobcoder.sendMessage(msg.to, "𝗖𝗛𝗔𝗡𝗚𝗘 𝗖𝗢𝗩𝗘𝗥\n"+" • Detail: Change Cover Picture\n • Status: Waiting for picture\n Please send a picture...")
                            else:
                                TBotMessageWithHeader(msg.to, "CHANGE COVER", " • Detail: Change Cover Picture\n • Status: Waiting for picture\n Please send a picture...")
                        elif cmd == "changedp video" and sender == noobcoderMID:
                            settings['changeProfileVideo']['status'] = True
                            settings['changeProfileVideo']['stage'] = 1
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "𝗖𝗛𝗔????𝗘 𝗩𝗜𝗗𝗘𝗢\n"+" • Detail: Change Video Profile\n • Status: Waiting for video\nPlease send a video...")
                            else:
                                TBotMessageWithHeader(msg.to, "CHANGE VIDEO", " • Detail: Change Video Profile\n • Status: Waiting for video\nPlease send a video...")
                        elif cmd.startswith("upname ") and sender == noobcoderMID:
                            string = removeCmd("upname", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).displayName
                                profile = noobcoder.getProfile()
                                profile.displayName = string
                                noobcoder.updateProfile(profile)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to,"𝗨𝗣𝗗𝗔𝗧𝗘 𝗡𝗔𝗠𝗘\n" + "Status : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                                else:
                                    TBotMessageWithHeader(msg.to, "UPDATE NAME", "Status : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                        elif cmd.startswith("upstatus ") and sender == noobcoderMID:
                            string = removeCmd("upstatus", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).statusMessage
                                profile = noobcoder.getProfile()
                                profile.statusMessage = string
                                noobcoder.updateProfile(profile)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to,"𝗨𝗣𝗗𝗔𝗧𝗘 𝗦𝗧𝗔𝗧𝗨𝗦\n" + "Status : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                                else:
                                    TBotMessageWithHeader(msg.to, "UPDATE STATUS", "Status : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
#=====================================================================
# SETTINGS
# take stickers off the menu for now
                        elif cmd == "settings":
                            txt  = " ☞  autoadd\n"
                            txt  = " ☞  autoadd\n"
                            txt += " ☞  autoaddmsg [text]\n"
                            txt += " ☞  autoblock on/off\n"
                            txt += " ☞  autojoin\n"
                            txt += " ☞  autojoinset [num]\n"
                            txt += " ☞  autolike on/off\n"
                            txt += " ☞  comment: [text]\n"
                            txt += " ☞  autoread on/off\n"
                            txt += " ☞  autoresend on/off\n"
                            txt += " ☞  antitag on/off\n"
                            txt += " ☞  mc on/off\n"
                            txt += " ☞  restagmsg [text]\n"
                            txt += " ☞  sleepmode on/off\n"
                            txt += " ☞  sleepmsg [text]\n"
                            txt += " ☞  lurk on/off\n"
                            txt += " ☞  lurktag on/off\n"
                            txt += " ☞  set lurkmsg [text]\n"
                            txt += " ☞  sider on/off\n"
                            txt += " ☞  sidermsg [text]\n"
                            txt += " ☞  jointemp on/off\n"
                            txt += " ☞  joinmsg [text]\n"
                            txt += " ☞  welcome on/off\n"
                            txt += " ☞  welcomemsg [text]\n"
                            txt += " ☞  leavetemp on/off\n"
                            txt += " ☞  leavemsg [text]\n"
                            txt += " ☞  groupcall on/off"
###
                            txtt  = " ☞  autoadd\n"
                            txtt += " ☞  autoaddmsg [text]\n"
                            txtt += " ☞  autoblock on/off\n"
                            txtt += " ☞  autojoin\n"
                            txtt += " ☞  autojoin set [num]\n"
                            txtt += " ☞  autolike on/off\n"
                            txtt += " ☞  commentpost: [text]\n"
                            txtt += " ☞  autoread on/off\n"
                            txtt += " ☞  autoresend on/off\n"
                            txtt += " ☞  antitag on/off\n"
                            txtt += " ☞  mc on/off\n"
                            txtt += " ☞  groupcall on/off\n"
                            txtt += " ☞  restag on/off\n"
                            txtt += " ☞  restagmsg [text]\n"
                            txtt += " ☞  sleepmode\n"
                            txtt += " ☞  sleepmsg [text]\n"
                            txtt += " ☞  lurk on/off\n"
                            txtt += " ☞  lurktag on/off\n"
                            txtt += " ☞  lurkmsg [text]\n"
                            txtt += " ☞  groupcall on/off"
                           
                            if wait["flex"] == True:
                                TtempListMenu(to, "SETTINGS", str(txt))
                            else:
                                noobcoder.sendMessage(to, "  𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦\n\n" + str(txtt))
                        elif cmd == "autoadd":
                            key = settings['keyCommand']
                            key = key.title()
                            b = settings['messageSticker']['listSticker']['addSticker']
                            a = b['STKPKGID']
                            z = noobcoder.shop.getProduct(packageID=int(a), language='ID', country='ID')
                            if settings["messageSticker"]["listSticker"]["addSticker"]["status"] == True:c = z.title
                            else:c = 'None'
                            if settings['setKey'] == False:key = ""
                            if settings["autoAdd"] == True:
                                if settings["addPesan"] == '':
                                    msgs="𝗔𝗨𝗧𝗢𝗔𝗗𝗗\nAdd Back: True♪\nAdd Sticker: "+c+"\nAdd Message: False♪\n\n\n"
                                else:
                                    msgs="𝗔𝗨𝗧𝗢𝗔𝗗𝗗\nAdd Back: True♪\nAdd Sticker: "+c+"\nAdd Message: True♪"
                                    msgs+="\n" + settings["addPesan"] + "\n\n"
                            else:
                                if settings["addPesan"] == '':
                                    msgs="𝗔𝗨𝗧𝗢𝗔𝗗𝗗\nAdd Back: False♪\nAdd Sticker: "+c+"\nAdd Message: False♪\n\n\n"
                                else:
                                    msgs="𝗔𝗨𝗧𝗢𝗔𝗗𝗗\nAdd Back: False♪\nAdd Sticker: "+c+"\nAdd Message: True♪"
                                    msgs+="\n" + settings["addPesan"] + "\n"
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, msgs+"\nType: Autoadd friend\n  Usage:"+key+" autoadd on|off\nType: Autoadd msg setting\n  Usage:"+key+" autoadd msg set [text]\nType: Autoadd Sticker\n  Usage:"+key+" add autoaddsticker\n  Usage:"+key+" del autoaddsticker")
                                    else:
                                        TBotMessage(msg.to, msgs+"\nType: Autoadd friend\n  Usage:"+key+" autoadd on|off\nType: Autoadd msg setting\n  Usage:"+key+" autoadd msg set [text]\nType: Autoadd Sticker\n  Usage:"+key+" add autoaddsticker\n  Usage:"+key+" del autoaddsticker")
                        elif cmd.startswith('autoaddmsg '):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            if len(msg.text.split("\n")) >= 2:
                                settings["addPesan"] = msg.text.replace(msg.text.split("\n")[0]+"\n","").replace('|','@!')
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Autoadd message is set to:\n" + settings["addPesan"])
                                else:
                                    TBotMessage(msg.to, "Autoadd message is set to:\n" + settings["addPesan"])
                        elif cmd == "autoadd on":
                            if settings["autoAdd"] == True:
                                msgs="Autoadd already enabled.\nNote: Auto add message is not affected."
                            else:
                                msgs="Autoadd is now enabled.\nNote: Auto add message is not affected."
                                settings["autoAdd"]=True

                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autoadd off":
                            if settings["autoAdd"] == False:
                                msgs="Autoadd already disabled.\nNote: Autoadd message is not affected."
                            else:
                                msgs="Autoadd is now disabled.\nNote: Autoadd message is not affected."
                                settings['autoAdd']=False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autoblock on":
                            if wtf["autoBlock"] == True:
                                msgs="Autoblock is already enabled."
                            else:
                                msgs="Autoblock is now enabled."
                                wtf["autoBlock"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autoblock off":
                            if wtf["autoBlock"] == False:
                                msgs="Autoblock is already disabled."
                            else:
                                msgs="Autoblock is now disabled."
                                wtf["autoBlock"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autojoin":
                            if settings["autoJoin"] == True:a = "Enabled"
                            else:a = "Disabled"
                            if wait["Members"]:
                                b = "{}".format(int(wait["Members"]))
                            else:b = "0"
                            key = settings['keyCommand']
                            key = key.title()
                            if settings['setKey'] == False:key = ""
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "𝗔𝗨𝗧𝗢𝗝𝗢𝗜𝗡\nEvent Trigger:\n Autojoin: "+a+"\n Stage: "+b+"\n\nCommand:\n Autojoin\n • Usage: "+key+" autojoin on|off\n • Usage: "+key+" autojoin set 「numb」")
                            else:
                                TBotMessage(msg.to, "𝗔𝗨𝗧𝗢𝗝𝗢𝗜𝗡\nEvent Trigger:\n Autojoin: "+a+"\n Stage: "+b+"\n\nCommand:\n Autojoin\n • Usage: "+key+" autojoin on|off\n • Usage: "+key+" autojoin set 「numb」")
                        elif cmd.startswith("autojoinset "):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            wait["Members"] = int(msg.text.split(" ")[2])
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "𝗔𝗨𝗧𝗢𝗝𝗢𝗜𝗡\nType: Minim Members\nStatus: Success Set\nTo: {} Members".format(wait["Members"]))
                            else:
                                TBotMessage(msg.to, "𝗔𝗨𝗧𝗢𝗝𝗢𝗜𝗡\nType: Minim Members\nStatus: Success Set\nTo: {} Members".format(wait["Members"]))
                        elif cmd == "autojoin on":
                            if settings['autoJoin'] == True:
                                msgs="Autojoin is already enabled."
                            else:
                                msgs="Autojoin is now enabled."
                                settings['autoJoin']=True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autojoin off":
                            if settings['autoJoin'] == False:
                                msgs="Autojoin is already disabled."
                            else:
                                msgs="Autojoin is now disabled."
                                settings['autoJoin']=False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autolike on":
                            if komen["komenan"] == True:
                                msgs="Autolike Post is already enabled."
                            else:
                                msgs="Autolike Post is now enabled."
                                komen["komenan"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autolike off":
                            if komen["komenan"] == False:
                                msgs="Autolike Post is already disabled."
                            else:
                                msgs="Autolike Post is now disabled."
                                komen["komenan"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd.startswith("comment: "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            try:
                                settings["commentPost"] = txt
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Comment changed to :\n{}".format(txt))
                                else:
                                    TBotMessage(msg.to, "Comment changed to :\n{}".format(txt))
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Comment changed to :\n{}".format(txt))
                                else:
                                    TBotMessage(msg.to, "Comment changed to :\n{}".format(txt))
                        elif cmd == "autoread on":
                            if settings["autoRead"] == True:
                                msgs="Autoread is already enabled."
                            else:
                                msgs="Autoread is now enabled."
                                settings["autoRead"]=True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autoread off":
                            if settings["autoRead"] == False:
                                msgs="nAutoread is already disabled."
                            else:
                                msgs="Autoread is now disabled."
                                settings["autoRead"]=False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autoresend on":
                            if settings["unsendMessage"] == True:
                                msgs="Resend unsent message is already enabled."
                            else:
                                msgs="Resend unsent message is now enabled."
                                settings["unsendMessage"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "autoresend off":
                            if settings["unsendMessage"] == False:
                                msgs="Resend unsent message is already disabled."
                            else:
                                msgs="Resend unsent message is now disabled."
                                settings["unsendMessage"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "antitag on":
                            if settings["notag"] == True:
                                msgs="Antitag is already enabled."
                            else:
                                msgs="Antitag is now enabled."
                                settings["notag"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "antitag off":
                            if settings["notag"] == False:
                                msgs="Antitag is already disabled."
                            else:
                                msgs="Antitag is now disabled."
                                settings["notag"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "mc on":
                            if wait['leaveMC'] == True:
                                msgs="Leave Multichat is already enabled."
                            else:
                                msgs="Leave Multichat is now enabled."
                                wait['leaveMC']=True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "mc off":
                            if wait['leaveMC'] == False:
                                msgs="𝗟𝗘𝗔𝗩𝗘 𝗠𝗨𝗟𝗧𝗜𝗖𝗛𝗔𝗧\nLeave Multichat is already disabled."
                            else:
                                msgs="𝗟𝗘𝗔𝗩𝗘 𝗠𝗨𝗟𝗧𝗜𝗖𝗛𝗔𝗧\nLeave Multichat is now disabled."
                                wait['leaveMC']=False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "restag on":
                            if temptag["stealtag"] == True:
                                msgs="Tagresponse is already enabled."
                            else:
                                msgs="Tagresponse is now enabled."
                                temptag["stealtag"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "restag off":
                            if temptag["stealtag"] == False:
                                msgs="Tagresponse is already disabled."
                            else:
                                msgs="Tagresponse is now disabled."
                                temptag["stealtag"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd.startswith("restagmsg "):
                            text_ = removeCmd("restagmsg", text)
                            try:
                                temptag["pesanya"] = text_
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Tagresponse text is changed to : " + text_)
                                else:
                                    TBotMessage(msg.to, "Tagresponse text is changed to : " + text_)
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Failed to replace Tagresponse text.")
                                else:
                                    TBotMessage(msg.to, "Failed to replace Tagresponse text.")
                        elif cmd == "sleepmode" and sender == noobcoderMID:
                            if settings["replyPesan"] is not None:
                                TBotMessage(to,"𝗦𝗟𝗘𝗘𝗣𝗠𝗢𝗗𝗘\nSet Sleep Mode: " + str(settings["replyPesan"]))
                                msgSticker = settings["messageSticker"]["listSticker"]["replySticker"]
                                if msgSticker != None:
                                    sid = msgSticker["STKID"]
                                    spkg = msgSticker["STKPKGID"]
                                    sver = msgSticker["STKVER"]
                                    sendSticker(to, sver, spkg, sid)
                            else:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "No Sleepmode message is set.")
                                else:
                                    TBotMessage(msg.to, "No Sleepmode message is set.")
                        elif cmd.startswith("sleepmsg ") and sender == noobcoderMID:
                            text_ = removeCmd("sleepmsg", text)
                            try:
                                settings["replyPesan"] = text_
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "𝗦𝗟𝗘𝗘𝗣𝗠𝗢𝗗𝗘\nChanged to : " + text_)
                                else:
                                    TBotMessage(msg.to, "𝗦𝗟𝗘𝗘𝗣𝗠𝗢𝗗𝗘\nChanged to : " + text_)
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "𝗦𝗟𝗘𝗘𝗣𝗠𝗢𝗗𝗘\nFailed to replace message")
                                else:
                                    TBotMessage(msg.to, "𝗦𝗟𝗘𝗘𝗣𝗠𝗢𝗗𝗘\nFailed to replace message")
                        elif cmd == "sleepmode on":
                            if settings["autoReply"] == True:
                                msgs="Sleep Mode is already enabled."
                            else:
                                msgs="Sleep Mode is now enabled."
                                settings["autoReply"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "sleepmode off":
                            if settings["autoReply"] == False:
                                msgs="Sleep Mode is already disabled."
                            else:
                                msgs="Sleep Mode is now disabled."
                                settings["autoReply"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd.startswith("lurk on"):
                            tailah2["siderTemp"][receiver] = []
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Lurking now ...")
                            else:
                                TBotMessage(msg.to, "Lurking now ...")
                        elif cmd.startswith("lurk off"):
                            if receiver in tailah2["siderTemp"]:
                                del tailah2["siderTemp"][receiver]
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Looking off")
                                else:
                                    TBotMessage(msg.to, "Looking off")
                        elif cmd.startswith("lurktag on"):
                            tailah2tag["siderTemp"][receiver] = []
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Lurk Tag is now on.")
                            else:
                                TBotMessage(msg.to, "Lurk Tag is now on.")
                        elif cmd.startswith("lurktag off"):
                            if receiver in tailah2tag["siderTemp"]:
                                del tailah2tag["siderTemp"][receiver]
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Lurk Tag is now off.")
                                else:
                                    TBotMessage(msg.to, "Lurk Tag is now off.")
                        elif cmd.startswith("lurkmsg ") and sender == noobcoderMID:
                            text_ = removeCmd("lurkmsg", text)
                            try:
                                tailah2["siderPesan"] = text_
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Lurk Message changed to:\n" + text_)
                                else:
                                    TBotMessage(msg.to, "Lurk Message changed to:\n" + text_)
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Failed to replace lurk message.")
                                else:
                                    TBotMessage(msg.to, "Failed to replace lurk message.")
                        elif cmd == "lurkers":
                            if to in wait['readPoint']:
                                try:
                                    anulurk(to, wait)
                                    wait['setTime'][to] = {}
                                except:
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, 'None.')
                                    else:
                                        TBotMessage(msg.to, 'None.')
                            else:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Lurk point is not on.")
                                else:
                                    TBotMessage(msg.to, "Lurk point is not on.")
#######################################################sider
                        elif cmd.startswith("sider on"):
                            tailah["siderTemp"][receiver] = []
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Sider is now on.")
                            else:
                                TBotMessage(msg.to, "Siderr is now on.")
                        elif cmd.startswith("sider off"):
                            if receiver in tailah["siderTemp"]:
                                del tailah["siderTemp"][receiver]
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Sider is now off.")
                                else:
                                    TBotMessage(msg.to, "Sider is now off.")
#######################################################sider1
                        elif cmd.startswith("sider1 on"):
                            tailah3["siderTemp"][receiver] = []
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Sider1 is now on.")
                            else:
                                TBotMessage(msg.to, "Siderr is now on.")
                        elif cmd.startswith("sider1 off"):
                            if receiver in tailah3["siderTemp"]:
                                del tailah3["siderTemp"][receiver]
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Sider is now off.")
                                else:
                                    TBotMessage(msg.to, "Sider is now off.")
#######################################
                        elif cmd.startswith("sidermsg ") and sender == noobcoderMID:
                            text_ = removeCmd("sidermsg", text)
                            try:
                                tailah["siderPesan"] = text_
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Sider Message changed to:\n" + text_)
                                else:
                                    TBotMessage(msg.to, "Sider Message changed to:\n" + text_)
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Failed to replace Sider Message.")
                                else:
                                    TBotMessage(msg.to, "Failed to replace Sider Message.")
                        elif cmd == "jointemp on":
                            if gjoin["jMessage"] == True:
                                msgs="Join templates are already enabled."
                            else:
                                msgs="Join templates are now enabled."
                                gjoin["jMessage"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "jointemp off":
                            if gjoin["jMessage"] == False:
                                msgs="Join templates are already disabled."
                            else:
                                msgs="Join templates are now disabled."
                                gjoin["jMessage"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd.startswith("joinmsg ") and sender == noobcoderMID:
                            text_ = removeCmd("joinmsg", text)
                            try:
                                gjoin["textnya"] = text_
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Join Message changed to:\n" + text_)
                                else:
                                    TBotMessage(msg.to, "Join Message changed to:\n" + text_)
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Failed to replace Join Message.")
                                else:
                                    TBotMessage(msg.to, "Failed to replace Join Message.")
                        elif cmd == "welcome on":
                            if wmin["wMessage"] == True:
                                msgs="Welcome templates are already enabled."
                            else:
                                msgs="Welcome templates are now enabled."
                                wmin["wMessage"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "welcome off":
                            if wmin["wMessage"] == False:
                                msgs="Welcome templates are already disabled."
                            else:
                                msgs="Welcome templates are now disabled."
                                wmin["wMessage"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd.startswith("wlcmmsg ") and sender == noobcoderMID:
                            text_ = removeCmd("wlcmmsg", text)
                            try:
                                wmin["textnya"] = text_
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Welcome Message changed to:\n" + text_)
                                else:
                                    TBotMessage(msg.to, "Welcome Message changed to:\n" + text_)
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Failed to replace Welcome Message.")
                                else:
                                    TBotMessage(msg.to, "Failed to replace Welcome Message.")
                        elif cmd == "leavetemp on":
                            if lvin["lMessage"] == True:
                                msgs="Leave templates are already enabled."
                            else:
                                msgs="Leave templates are now enabled."
                                lvin["lMessage"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "leavetemp off":
                            if lvin["lMessage"] == False:
                                msgs="Leave templates are already disabled."
                            else:
                                msgs="Leave templates are now disabled."
                                lvin["lMessage"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd.startswith("leavemsg ") and sender == noobcoderMID:
                            text_ = removeCmd("leavemsg", text)
                            try:
                                lvin["textnya"] = text_
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Leave Message changed to:\n" + text_)
                                else:
                                    TBotMessage(msg.to, "Leave Message changed to:\n" + text_)
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Failed to replace Leave Message.")
                                else:
                                    TBotMessage(msg.to, "Failed to replace Leave Message.")
                        elif cmd == "groupcall on":
                            if to not in wait["notificationCall"]:
                                wait["notificationCall"].append(to)
                                msgs="Groupcall notifications are now on."
                            else:
                                msgs="Groupcall notifications are already on."
                        elif cmd == "groupcall off":
                            if to in wait["notificationCall"]:
                                wait["notificationCall"].remove(to)
                                msgs="Groupcall notifications are now off."
                            else:
                                msgs="Groupcall notifications are already off."
# Add these later
                        elif cmd == "add autoaddsticker" and sender == noobcoderMID:
                            settings["messageSticker"]["addStatus"] = True
                            settings["messageSticker"]["addName"] = "addSticker"
                            TBotMessage(to, " 「 Auto Add 」\nType: Auto add\n • Detail: Add autoadd sticker\n • Status: Send sticker")
                        elif cmd == "del autoaddsticker" and sender == noobcoderMID:
                            settings["messageSticker"]["listSticker"]["addSticker"]["status"] = False
                            TBotMessage(to, " 「 Auto Add 」\nType: Auto add\n • Detail: Del autoadd sticket\n • Status: Succes")
                        elif cmd == "add responsticker":
                            sets["messageStickerz"]["addStatusz"] = True
                            sets["messageStickerz"]["addNamez"] = "responSticker"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Send a sticker ...")
                            else:
                                TBotMessage(to, "Send a sticker ...")
                        elif cmd == "responsticker on":
                            if sets["tagsticker"] == True:
                                msgs="Response sticker is already enabled."
                            else:
                                msgs="Response sticker is now enabled."
                                sets["tagsticker"] = True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(to, msgs)
                        elif cmd == "responsticker off":
                            if sets["tagsticker"] == False:
                                msgs="Response sticker is now disabled."
                            else:
                                msgs="Response sticker is already disabled."
                                sets["tagsticker"] = False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(to, msgs)
                        elif cmd == "add welcomesticker":
                            wstckr["sticker"]["status"] = True
                            wstckr["sticker"]["sender"].append(to)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Send a sticker ...")
                            else:
                                TBotMessage(to, "Send a sticker ...")
                        elif cmd == "del welcomesticker":
                            wstckr["sticker"]["status"] = False
                            wstckr["sticker"]["sender"].append(to)
                            noobcoder.sendReplyMessage(msg.id, to, "Sticker Deleted")
                        elif cmd == "add leavesticker":
                            lstckr["sticker"]["status"] = True
                            lstckr["sticker"]["sender"].append(to)
                            noobcoder.sendReplyMessage(msg.id, to, "Please Send Sticker If You Want Use To Leave Message")
                        elif cmd == "del leavesticker":
                            wstckr["sticker"]["status"] = False
                            wstckr["sticker"]["sender"].append(to)
                            noobcoder.sendReplyMessage(msg.id, to, "Sticker Deleted")
                        elif cmd == "add readersticker" and sender == noobcoderMID:
                            settings["messageSticker"]["addStatus"] = True
                            settings["messageSticker"]["addName"] = "readerSticker"
                            TBotMessage(to, "Please send a sticker.")
                        elif cmd == "del readersticker" and sender == noobcoderMID:
                            settings["messageSticker"]["listSticker"]["readerSticker"]["status"] = False
                            TBotMessage(to, "Succes delete a sticker.")
                        elif cmd == "contactmsg on":
                            if wait2["detectSContact"]['status'] == True:
                                msgs="Detect Contact is already enabled."
                            else:
                                msgs="Detect Contact is now enabled."
                                wait2["detectSContact"]['status']=True
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "contactmsg off":
                            if wait2["detectSContact"]['status'] == False:
                                msgs="Detect Contact is already disabled."
                            else:
                                msgs="Detect Contact is now disabled."
                                wait2["detectSContact"]['status']=False
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, msgs)
                            else:
                                TBotMessage(msg.to, msgs)
                        elif cmd == "add detectmentionsticker":
                            dstckr["sticker"]["status"] = True
                            dstckr["sticker"]["sender"].append(to)
                            noobcoder.sendReplyMessage(msg.id, to, "Please Send Sticker If You Want Use To Detect Mention")
#=====================================================================
# Colors Themes etc.
                        elif cmd == "themes":
                            ret  = " ☞ temps on/off\n"
                            ret += " ☞ theme default\n"
                            ret += " ☞ theme red\n"
                            ret += " ☞ theme pink\n"
                            ret += " ☞ theme blue\n"
                            ret += " ☞ theme cyan\n"
                            ret += " ☞ theme black\n"
                            ret += " ☞ theme white\n"
                            ret += " ☞ theme yellow\n"
                            ret += " ☞ theme purple\n"
                            ret += " ☞ theme golden\n"
                            ret += " ☞ theme green\n"
                            ret += " ☞ setid: [lineid]\n"
                            ret += " ☞ clrfont: [code]\n"
                            ret += " ☞ clrbg: [code]\n"
                            ret += " ☞ clrtemp: [code]\n"
                            ret += " ☞ color selection"
                            if wait["flex"] == True:
                                TtempListMenu(to, "THEMES", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗧𝗛𝗘𝗠𝗘𝗦\n\n" + str(ret))
                        elif cmd == "temps on":
                            if wait["flex"] == True:
                                TBotMessage(to,"Templates are already enabled.")
                            elif wait["flex"] == False:
                                wait["flex"] = True
                                TBotMessage(msg.to,"Templates are now enabled.")
                        elif cmd == "temps off":
                            if wait["flex"] == False:
                                noobcoder.sendMessage(to,"Templates are already disabled.")
                            elif wait["flex"] == True:
                                wait["flex"] = False
                                noobcoder.sendMessage(msg.to,"Templates are now disabled.")
                        elif cmd == "theme default":
                            Colors["Font"] = "#FFFFFF"
                            Colors["Background"] = "#000000"
                            Colors["Template"] = "#13598b"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Default theme is active now")
                            else:
                                TBotMessage(msg.to, "Default theme is active now")
                        elif cmd == "theme red":
                            Colors["Font"] = "#00CC00"
                            Colors["Background"] = "#660000"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Red theme is active now")
                            else:
                                TBotMessage(msg.to, "Red theme is active now")
                        elif cmd == "theme pink":
                            Colors["Font"] = "#FFF8DC"
                            Colors["Background"] = "#FF1493"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Pink theme is active now")
                            else:
                                TBotMessage(msg.to, "Pink theme is active now")
                        elif cmd == "theme blue":
                            Colors["Font"] = "#00FFFF"
                            Colors["Background"] = "#000066"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Blue theme is active now")
                            else:
                                TBotMessage(msg.to, "Blue theme is active now")
                        elif cmd == "theme cyan":
                            Colors["Font"] = "#66FFFF"
                            Colors["Background"] = "#006600"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Cyan theme is active now")
                            else:
                                TBotMessage(msg.to, "Cyan theme is active now")
                        elif cmd == "theme black":
                            Colors["Font"] = "#FFFFFF"
                            Colors["Background"] = "#000000"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Black theme is active now")
                            else:
                                TBotMessage(msg.to, "Black theme is active now")
                        elif cmd == "theme white":
                            Colors["Font"] = "#000000"
                            Colors["Background"] = "#FFFFFF"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "White theme is active now")
                            else:
                                TBotMessage(msg.to, "White theme is active now")
                        elif cmd == "theme yellow":
                            Colors["Font"] = "#660066"
                            Colors["Background"] = "#FFFF00"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Yellow theme is active now")
                            else:
                                TBotMessage(msg.to, "Yellow theme is active now")
                        elif cmd == "theme purple":
                            Colors["Font"] = "#FFFF00"
                            Colors["Background"] = "#660066"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Purple theme is active now")
                            else:
                                TBotMessage(msg.to, "Purple theme is active now")
                        elif cmd == "theme golden":
                            Colors["Font"] = "#000000"
                            Colors["Background"] = "#DAA520"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Golden theme is active now")
                            else:
                                TBotMessage(msg.to, "Golden theme is active now")
                        elif cmd == "theme green":
                            Colors["Font"] = "#CCFFCC"
                            Colors["Background"] = "#006666"
                            Colors["Template"] = "#708090"
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Green theme is active now")
                            else:
                                TBotMessage(msg.to, "Green theme is active now")
                        elif cmd.startswith("setid: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Customer["makerLineid"] = "https://line.me/ti/p/~"+anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "ID is set to:\n" +Customer["makerLineid"])
                            else:
                                TBotMessage(msg.to, "ID is set to:\n" +Customer["makerLineid"])
                        elif cmd.startswith("clrfont: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Colors["Font"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Font color has been changed to:\n" + Colors["Template"])
                            else:
                                TBotMessage(msg.to, "Font color has been changed to:\n" + Colors["Template"])
                        elif cmd.startswith("clrbg: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Colors["Background"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Background color has been changed to:\n" + Colors["Template"])
                            else:
                                TBotMessage(msg.to, "Background color has been changed to:\n" + Colors["Template"])
                        elif cmd.startswith("clrtemp: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Colors["Template"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Template color has been changed to:\n" + Colors["Template"])
                            else:
                                TBotMessage(msg.to, "Template color has been changed to:\n" + Colors["Template"])
                        elif cmd == "color selection":
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Select the Colors from Website:\n\nhttps://www.colorhexa.com/")
                            else:
                                TBotMessage(msg.to, "Select the Colors from Website:\n\nhttps://www.colorhexa.com/")
#=====================================================================
# INFORMATION Done
                        elif cmd == "information":
                            ret  = " ☞  pict [@]\n"
                            ret += " ☞  cover [@]\n"
                            ret += " ☞  profile [@]\n"
                            ret += " ☞  video [@]\n"
                            ret += " ☞  name [@]\n"
                            ret += " ☞  bio [@]\n"
                            ret += " ☞  contact [@]\n"
                            ret += " ☞  clone [@]\n"
                            ret += " ☞  cloneprofile [@]\n"
                            ret += " ☞  unclone\n"
                            ret += " ☞  uncloneprofile\n"
                            ret += " ☞  lineid [lineid]\n"
                            ret += " ☞  mid [@]\n"
                            ret += " ☞  contactmid [mid]"
                            if wait["flex"] == True:
                                TtempListMenu(to, "INFORMATION", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡\n\n" + str(ret))
                        elif cmd.startswith("pict "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                 names = re.findall(r'@(\w+)', text)
                                 mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                 mentionees = mention['MENTIONEES']
                                 lists = []
                                 for mention in mentionees:
                                      if mention["M"] not in lists:
                                          lists.append(mention["M"])
                                 for ls in lists:
                                     contact =noobcoder.getContact(ls)
                                     dt={
                                        'type': 'image',
                                        'originalContentUrl': 'https://obs.line-scdn.net/{}'.format(contact.pictureStatus),
                                        'previewImageUrl': 'https://obs.line-scdn.net/{}'.format(contact.pictureStatus),
                                        'sentBy': {
                                            'label': '{}'.format(noobcoder.getProfile().displayName),
                                            'iconUrl' : "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                            'linkUrl' : 'line://nv/profilePopup/mid=u83c66fc3bf16c0ec7ecd3c5da8707025'
                                        }
                                     }
                                     sendTemplate(to, dt)
                        elif cmd.startswith("cover "):
                            if noobcoder != None:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        path = noobcoder.getProfileCoverURL(ls)
                                        path = str(path)
                                        noobcoder.generateReplyMessage(msg.id)
                                        noobcoder.sendReplyImageWithURL(msg.id, to, str(path))
                        elif cmd.startswith("profile "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    cu = noobcoder.getProfileCoverURL(ls)
                                    path = str(cu)
                                    image = "https://obs.line-scdn.net/" + contact.pictureStatus
                                    TBotMessage(msg.to,"Nama :\n" + contact.displayName + "\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage)
                                    noobcoder.sendImageWithURL(msg.to,image)
                                    noobcoder.sendImageWithURL(msg.to,path)
                        elif cmd.startswith("video "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                 names = re.findall(r'@(\w+)', text)
                                 mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                 mentionees = mention['MENTIONEES']
                                 lists = []
                                 for mention in mentionees:
                                     if mention["M"] not in lists:
                                         lists.append(mention["M"])
                                 for ls in lists:
                                     contact =noobcoder.getContact(ls)
                                     if contact.videoProfile == None:
                                      continue
                                     data = {
                                        "type": "video",
                                        "originalContentUrl": "https://obs.line-scdn.net/{}/vp".format(contact.pictureStatus),
                                        "previewImageUrl": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                        }
                                     sendTemplate(to, data)
                        elif cmd.startswith("name "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "{}".format(str(contact.displayName)))
                                    else:
                                        TBotMessage(msg.to, "{}".format(str(contact.displayName)))
                        elif cmd.startswith("bio "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "{}".format(str(contact.statusMessage)))
                                    else:
                                        TBotMessage(msg.to, "{}".format(str(contact.statusMessage)))
                        elif cmd.startswith("contact "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    mi_d = contact.mid
                                    noobcoder.sendContact(to, mi_d)
                        elif cmd.startswith("clone "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                clone = ast.literal_eval(msg.contentMetadata['MENTION'])
                                clones = clone['MENTIONEES']
                                target = []
                                for clone in clones:
                                    if clone["M"] not in target:
                                        target.append(clone["M"])
                                for she in target:
                                    BackupProfile = noobcoder.getContact(sender)
                                    Save1 = "https://obs.line-scdn.net/{}".format(BackupProfile.pictureStatus);Save2 = "{}".format(BackupProfile.displayName);ProfileMe["PictureMe"] = Save1;ProfileMe["NameMe"] = Save2
                                    contact = noobcoder.getContact(she);ClonerV2(she)
                                    sendMention(to, contact.mid, "𝗖𝗟𝗢𝗡𝗘 𝗣𝗥𝗢𝗙𝗜𝗘\n", "\nStatus : Success");noobcoder.sendContact(to, str(BackupProfile.mid));noobcoder.sendContact(to, str(contact.mid))
                        elif cmd.startswith("cloneprofile "):
                            if 'MENTION' in msg.contentMetadata.keys() != None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                if len(lists) != []:
                                    ls = random.choice(lists)
                                    cloneProfile(ls)
                                    noobcoder.sendContact(to, noobcoderMID)
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Cloned.")
                                    else:
                                        TBotMessage(msg.to, "Cloned.")
                        elif cmd == "unclone":
                            try:
                                noobcoderProfile = noobcoder.getProfile()
                                noobcoderName = noobcoder.getProfile()
                                noobcoderProfile.statusMessage = str(ProfileMe["myProfile"]["statusMessage"])
                                noobcoderProfile.pictureStatus = str(ProfileMe["myProfile"]["pictureStatus"])
                                noobcoderName.displayName = ProfileMe["NameMe"]
                                noobcoder.updateProfile(noobcoderName)
                                path = noobcoder.downloadFileURL(ProfileMe["PictureMe"])
                                noobcoder.updateProfilePicture(path)
                                coverId = str(ProfileMe["myProfile"]["coverId"])
                                noobcoder.updateProfileCoverById(coverId)
                                BackupProfile = noobcoder.getContact(sender)
                                sendMention(to, BackupProfile.mid, "𝗨𝗡𝗖𝗟𝗢𝗡𝗘 𝗣𝗥𝗢𝗙𝗜𝗘\n", "\nStatus : Success");noobcoder.sendContact(to, str(BackupProfile.mid))
                            except Exception as error:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Failed to Backup.")
                                else:
                                    TBotMessage(msg.to, "Failed to Backup.")
                        elif cmd == "uncloneprofile":
                            try:
                                reTeamProfile()
                                noobcoder.sendContact(to,noobcoderMID)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Back to the beginning.")
                                else:
                                    TBotMessage(msg.to, "Back to the beginning.")
                            except Exception as e:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "ERROR")
                                    noobcoder.sendMessage(msg.to, str(e))
                                else:
                                    TBotMessage(msg.to, "ERROR")
                                    TBotMessage(msg.to, str(e))
                        elif cmd.startswith("lineid "):
                            a = removeCmd("lineid", text)
                            b = noobcoder.findContactsByUserid(a)
                            line = b.mid
                            TBotMessage(msg.to, "http://line.me/ti/p/~" + a)
                            noobcoder.sendContact(to, line)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, str(hasil))
                            else:
                                TBotMessage(msg.to, str(hasil))
                        elif cmd.startswith("mid "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                ret_ = "「 Mid User 」"
                                for ls in lists:
                                    ret_ += "\n{}".format(str(ls))
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, str(ret_))
                                    else:
                                        TBotMessage(msg.to, str(ret_))
                        elif cmd.startswith("contactmid "):
                            contact = removeCmd("contactmid", text)
                            noobcoder.sendContact(to, contact)
                        elif cmd.startswith('getid'):
                            if 'MENTION' in msg.contentMetadata.keys()!=None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                noobcoder.getinformation(msg.to,key1,wait)
                            else:
                                if len(cmd.split(' ')) == 2:
                                    a = noobcoder.getGroupIdsJoined()
                                    noobcoder.getinformation(msg.to,a[int(cmd.split(' ')[1])-1],wait)
                                if cmd == 'getid':noobcoder.getinformation(msg.to,msg.to,wait)
                        elif cmd.startswith('locate '):
                            if 'MENTION' in msg.contentMetadata.keys() != None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                a = noobcoder.getGroupIdsJoined();
                                i = noobcoder.getGroups(a)
                                c = []
                                for h in i:
                                    g = [c.append(h.name[0:20] + ',.s/' + str(len(h.members))) for d in h.members if
                                         key1 in d.mid]
                                h = "╭「 Find Contact 」─"
                                no = 0
                                for group in c:
                                    no += 1
                                    h += "\n│{}. {} | {}".format(no, group.split(',.s/')[0], group.split(',.s/')[1])
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, h + "\n╰─「 {} Groups I Found it 」".format(len(c)))
                                else:
                                    TBotMessage(msg.to, h + "\n╰─「 {} Groups I Found it 」".format(len(c)))
                        elif cmd.startswith("find "):
                            if 'MENTION' in msg.contentMetadata.keys() != None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                userid = "https://line.me/ti/p/~" + noobcoder.profile.userid
                                G = noobcoder.getGroupIdsJoined()
                                cgroup = noobcoder.getGroups(G)
                                groups = noobcoder.groups
                                ngroup = ""
                                ngroup += "「 Find Groups 」\n"
                                no = 0 + 1
                                num = 0
                                for mention in mentionees:
                                    for x in range(len(cgroup)):
                                        gMembMids = [contact.mid for contact in cgroup[x].members]
                                        if mention['M'] in gMembMids:
                                            ngroup += "\n{}. {} | {}".format(str(no), str(cgroup[x].name), str(len(cgroup[x].members)))
                                            no += 1
                                            num += 1
                                    ngroup += "\n\n{} groups".format(str(num))
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, str(ngroup))
                                else:
                                    TBotMessage(msg.to, str(ngroup))
                                if ngroup == "":
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Not found")
                                    else:
                                        TBotMessage(msg.to, "Not found")
                        elif cmd.startswith("lastseen ") and msg.toType == 2:
                            if msg._from in [noobcoderMID]:
                                if 'MENTION' in msg.contentMetadata.keys() != None:
                                    names = re.findall(r'@(\w+)', msg.text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    for mention in mentionees:
                                        if mention['M'] in lastseen["find"]:
                                            noobcoder.sendMention(to, "@!{}".format(lastseen["username"][mention['M']]), '', [mention['M']])
                                        else:
                                            noobcoder.sendMention(to, "Oops!!\nI can't found @!","", [mention['M']])
#=====================================================================
# GROUP
                        elif cmd == "group":
                            ret  = " ☞  grouplist\n"
                            ret += " ☞  groupinfo\n"
                            ret += " ☞  ginfo [num]\n"
                            ret += " ☞  members [num]\n"
                            ret += " ☞  cmembers [num]\n"
                            ret += " ☞  pendings [num]\n"
                            ret += " ☞  cpendings [num]\n"
                            ret += " ☞  openqr\n"
                            ret += " ☞  openqr [num]\n"
                            ret += " ☞  closeqr\n"
                            ret += " ☞  closeqr [num]\n"
                            ret += " ☞  invite [parameters]\n"
                            ret += " ☞  inviteid [Line ID]\n"
                            ret += " ☞  cancel [parameters]\n"
                            ret += " ☞  cancelall\n"
                            ret += " ☞  leave\n"
                            ret += " ☞  leavegroup [num]\n"
                            ret += " ☞  invited\n"
                            ret += " ☞  reject [num]\n"
                            ret += " ☞  rejectall\n"
                            ret += " ☞  gcall[Num] [@]\n"
                            ret += " ☞  gcall[Num]\n"
                            ret += " ☞  creategroup [text]\n"
                            ret += " ☞  changegn [text]\n"
                            ret += " ☞  changepic group\n"
                            ret += " ☞  createnote [text]\n"
                            ret += " ☞  get note [num]\n"
                            if wait["flex"] == True:
                                TtempListMenu(to, "GROUP", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗚𝗥𝗢𝗨𝗣\n\n" + str(ret))
                        elif cmd == "grouplist":
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False: key = ''
                            gid = noobcoder.getGroupIdsJoined()
                            sd = noobcoder.getGroups(gid)
                            ret = ""
                            no = 0
                            total = len(gid)
                            #cd = "\n\nTotal {} Groups\n\n「 Command 」\n\nRemote Mention\nUsage: Grouplist [num] tag [1|<|>|-]\n\nRemote Kick\nUsage: Grouplist [num] kick [1|<|>|-]\n\nLeave Groups\nUsage: Leave [num]\n\nGet QR\nUsage: OpenQr  [num]\n\nCek Member\nUsage: Grouplist [num]\nUsage: Grouplist [num] mem [num]".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} {}".format(no, G.name[0:45], member)
                            #ret += cd
                            k = len(ret) // 10000
                            for aa in range(k + 1):
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, '{}'.format(ret[aa * 10000: (aa + 1) * 10000]))
                                else:
                                    TtempListMenu(msg.to, "𝗚𝗥𝗢𝗨𝗣𝗦 𝗟𝗜𝗦𝗧", '{}'.format(ret[aa * 10000: (aa + 1) * 10000]))
                        elif cmd == "groupinfo":
                            group = noobcoder.getGroup(to)
                            try:
                                gCreator = group.creator.displayName
                            except:
                                gCreator = "Group Creator"
                            if group.invitee is None:
                                gPending = "0"
                            else:
                                gPending = str(len(group.invitee))
                            if group.preventedJoinByTicket == True:
                                gQr = "Closed"
                                gTicket = "QR Closed"
                            else:
                                gQr = "Open"
                                gTicket = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(group.id)))
                            path = "https://obs.line-scdn.net/" + group.pictureStatus
                            ret_ = "𝗚𝗥𝗢𝗨𝗣 𝗜𝗡𝗙𝗢\n"
                            ret_ += "\n➭ Group  Name  : {}".format(str(group.name))
                            ret_ += "\n➭ Group Id     : {}".format(group.id)
                            ret_ += "\n➭ Group Creator: {}".format(str(gCreator))
                            ret_ += "\n➭ Members      : {}".format(str(len(group.members)))
                            ret_ += "\n➭ Pendings     : {}".format(gPending)
                            ret_ += "\n➭ Status       : {}".format(gQr)
                            ret_ += "\n➭ Group QR     : {}".format(gTicket)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, str(ret_))
                            else:
                                TBotMessage(msg.to, str(ret_))
                        elif cmd.startswith("members"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number) - 1]
                                G = noobcoder.getGroup(group)
                                jembut = [contact.mid for contact in G.members]
                                num = 0
                                tot = {}
                                for mid in jembut:
                                    tot[mid] = True
                                    if 20 == len(tot):
                                        tx = "𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗼𝗳:\n" + noobcoder.getGroup(group).name + "\n\n"
                                        for a in tot:
                                            num += 1
                                            tx += "{}. {}\n".format(num, noobcoder.getContact(a).displayName)
                                        tot = {}
                                        noobcoder.sendMessage(to, tx)
                                jem = "𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗼𝗳:\n" + noobcoder.getGroup(group).name + "\n\n"
                                for a in tot:
                                    num += 1
                                    jem += "{}. {}\n".format(num, noobcoder.getContact(a).displayName)
                                noobcoder.sendMessage(to, jem + "\n\nTotal Members: {}".format(len(jembut)))
                            except Exception as e:
                                print(e)
                        elif cmd.startswith("cmembers"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number) - 1]
                                G = noobcoder.getGroup(group)
                                jembut = [contact.mid for contact in G.members]
                                tx = "𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗼𝗳:\n" + noobcoder.getGroup(group).name + "\n\n"
                                noobcoder.sendMessage(to, tx)
                                num = 1
                                for mid in jembut:
                                    noobcoder.sendContact(to, mid)
                                    num += 1
                                tx3 = "Total Members: {}".format(str(len(jembut)))
                                Lexe["lscon"] = {}
                                noobcoder.sendMessage(to, tx3)
                            except Exception as e:
                                print(e)
                        elif cmd.startswith("pendings"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number) - 1]
                                G = noobcoder.getGroup(group)
                                jembut = [contact.mid for contact in G.invitee]
                                tx = "𝗣𝗘𝗡𝗗𝗜𝗡𝗚𝗦 𝗼𝗳: " + noobcoder.getGroup(group).name
                                listWithText(to, tx, "Members", jembut)
                            except:
                                noobcoder.sendMessage(to, "No pending Invites.")
                        elif cmd.startswith("cpendings"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number) - 1]
                                G = noobcoder.getGroup(group)
                                jembut = [contact.mid for contact in G.invitee]
                                tx = "𝗣𝗘𝗡𝗗𝗜𝗡𝗚𝗦 𝗼𝗳:\n" + noobcoder.getGroup(group).name + "\n\n"
                                noobcoder.sendMessage(to, tx)
                                num = 1
                                for mid in jembut:
                                    noobcoder.sendContact(to, mid)
                                    num += 1
                                tx3 = "Total Pendings: {}".format(str(len(jembut)))
                                Lexe["lscon"] = {}
                                noobcoder.sendMessage(to, tx3)
                            except Exception as e:
                                print(e)
                        elif cmd.startswith("ginfo "):
                            number = removeCmd("ginfo",text)
                            groups = noobcoder.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                path = "https://obs.line-scdn.net/" + G.pictureStatus
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Group Creator"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Closed"
                                    gTicket = "QR Closed"
                                else:
                                    gQr = "Open"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "𝗚𝗥𝗢𝗨𝗣 𝗜𝗡𝗙𝗢\n"
                                ret_ += "\n➭ Group  Name  : {}".format(G.name)
                                ret_ += "\n➭ Group Id     : {}".format(G.id)
                                ret_ += "\n➭ Group Creator: {}".format(gCreator)
                                ret_ += "\n➭ Group Created: {}".format(str(timeCreated))
                                ret_ += "\n➭ Members      : {}".format(str(len(G.members)))
                                ret_ += "\n➭ Pendings     : {}".format(gPending)
                                ret_ += "\n➭ Status       : {}".format(gQr)
                                ret_ += "\n➭ Group QR     : {}".format(gTicket)
                                noobcoder.sendImageWithURL(to, path)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, str(ret_))
                                else:
                                    TBotMessage(msg.to, str(ret_))
                                noobcoder.sendContact(to, G.creator.mid)
                            except:
                                pass
                        elif cmd == "openqr":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                group.preventedJoinByTicket = False
                                noobcoder.updateGroup(group)
                                gurl = noobcoder.reissueGroupTicket(to)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Group QR opened.")
                                else:
                                    TBotMessage(msg.to, "Group QR opened.")
                                noobcoder.sendMessage(msg.to, "http://line.me/R/ti/g/{}".format(gurl))
                        elif cmd.startswith("openqr "):
                            number = removeCmd("openqr", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "QR opened for Group " + G.name)
                                else:
                                    TBotMessage(msg.to, "QR opened for Group " + G.name)
                                noobcoder.sendMessage(msg.to, gurl)
                            except Exception as error:
                                noobcoder.sendMessage(msg.to, str(error))
                        elif cmd == "closeqr":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                group.preventedJoinByTicket = True
                                noobcoder.updateGroup(group)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Group QR closed.")
                                else:
                                    TBotMessage(msg.to, "Group QR closed.")
                        elif cmd.startswith("closeqr "):
                            number = removeCmd("closeqr", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = True
                                    noobcoder.updateGroup(G)
                                except:
                                    G.preventedJoinByTicket = True
                                    noobcoder.updateGroup(G)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "QR closed for Group " + G.name)
                                else:
                                    TBotMessage(msg.to, "QR closed for Group " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(msg.to, str(error))
                        elif cmd.startswith("invite"):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ", "")
                            lkick = text.replace(proses[0] + " lkick", "")
                            if "lkick" == proses[1] or "lkick" + lkick == proses[1]:
                                if "" == lkick:
                                    lkick = "1"
                                l = int(lkick)
                                l -= 1
                                hasil = countLexe(to,"lkick",l)
                                num = []
                                for a in hasil:
                                    try:noobcoder.findAndAddContactsByMid(a)
                                    except:pass
                                noobcoder.inviteIntoGroup(to, hasil);return
                            lleave = text.replace(proses[0] + " lleave", "")
                            if "lleave" == proses[1] or "lleave" + lleave == proses[1]:
                                if "" == lleave:
                                    lleave = "1"
                                l = int(lleave)
                                l -= 1
                                hasil = countLexe(to,"lleave",l)
                                num = []
                                for a in hasil:
                                    try:noobcoder.findAndAddContactsByMid(a)
                                    except:pass
                                noobcoder.inviteIntoGroup(to, hasil);return
                            lcancel = text.replace(proses[0] + " lcancel", "")
                            if "lcancel" == proses[1] or "lcancel" + lcancel == proses[1]:
                                if "" == lcancel:
                                    lcancel = "1"
                                l = int(lcancel)
                                l -= 1
                                hasil = countLexe(to,"lcancel",l)
                                num = []
                                for a in hasil:
                                    try:noobcoder.findAndAddContactsByMid(a)
                                    except:pass
                                noobcoder.inviteIntoGroup(to, hasil);return
                            num = text.replace(proses[0] + " lcon", "")
                            if "lcon" == proses[1] or "lcon" + num == proses[1]:
                                if "" == num:
                                    try:
                                        noobcoder.findAndAddContactsByMid(Lexe["lscon"][1])
                                        noobcoder.inviteIntoGroup(to,[Lexe["lscon"][1]])
                                        Lexe["lstatus"] = True
                                    except:pass
                                else:
                                    if int(num) <= len(Lexe["lscon"]):
                                        try:
                                            noobcoder.findAndAddContactsByMid(Lexe["lscon"][1])
                                            noobcoder.inviteIntoGroup(to,Lexe["lscon"][1])
                                            Lexe["lstatus"] = True
                                        except:pass
                            else:
                                key = []
                                try:key = eval(msg.contentMetadata["MENTION"])
                                except:key =[]
                                if key == []:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:targets.append(x["M"])
                                    for a in targets:
                                        try:
                                            noobcoder.findAndAddContactsByMid(a)
                                            noobcoder.inviteIntoGroup(to, [a]);
                                            return
                                        except:pass
                        elif cmd.startswith("cancel"):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ", "")
                            linvite = text.replace(proses[0] + " linvite", "")
                            if "linvite" == proses[1] or "linvite" + linvite == proses[1]:
                                if "" == linvite:
                                    linvite = "1"
                                l = int(linvite)
                                l -= 1
                                hasil = countLexe(to,"linvite",l)
                                num = []
                                for a in hasil:
                                    noobcoder.cancelGroupInvitation(to, [a])
                            num = text.replace(proses[0] + " lcon", "")
                            if "lcon" == proses[1] or "lcon" + num == proses[1]:
                                if "" == num:
                                    try:
                                        noobcoder.cancelGroupInvitation(to,[Lexe["lscon"][1]])
                                        Lexe["lstatus"] = True
                                    except:pass
                                else:
                                    if int(num) <= len(Lexe["lscon"]):
                                        try:
                                            noobcoder.cancelGroupInvitation(to,Lexe["lscon"][1])
                                            Lexe["lstatus"] = True
                                        except:pass
                        elif cmd == "cancelall" and sender == noobcoderMID:
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                if group.invitee is None or group.invitee == []:
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Nothing to cancel.")
                                    else:
                                        TBotMessage(msg.to, "Nothing to cancel.")
                                else:
                                    invitee = [contact.mid for contact in group.invitee]
                                    for inv in invitee:
                                        time.sleep(0.5)
                                        noobcoder.cancelGroupInvitation(to, [inv])
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Cancelled {} users.".format(str(len(invitee))))
                                    else:
                                        TBotMessage(msg.to, "Cancelled {} users.".format(str(len(invitee))))
                        elif cmd == "leave":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Bye All\n " + str(group.name))
                                else:
                                    TBotMessage(msg.to, "Bye All\n " + str(group.name))
                                noobcoder.leaveGroup(to)
                        elif cmd.startswith("leavegroup ") and sender == noobcoderMID:
                            number = removeCmd("leavegroup", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.leaveGroup(G.id)
                                except:
                                    noobcoder.leaveGroup(G.id)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Left group\n " + G.name)
                                else:
                                    TBotMessage(msg.to, "Left group\n " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(msg.to, str(error))
                        elif cmd == "invited":
                            groups = noobcoder.getGroupIdsInvited()
                            ret_ = "𝗜𝗡𝗩𝗜𝗧𝗔𝗧𝗜𝗢𝗡𝗦 𝗟𝗜𝗦𝗧\n"
                            no = 1
                            for gid in groups:
                                group = noobcoder.getGroup(gid)
                                ret_ += "\n{}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                no = (no+1)
                            ret_ += "\n\nTotal {} Pending".format(str(len(groups)))
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, str(ret_))
                            else:
                                TBotMessage(msg.to, str(ret_))
                        elif cmd.startswith("reject "):
                            number = removeCmd("reject", text)
                            groups = noobcoder.getGroupIdsInvited()
                            try:
                                group = groups[int(number) - 1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.rejectGroupInvitation(G.id)
                                except:
                                    noobcoder.rejectGroupInvitation(G.id)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "𝗥𝗘𝗝𝗘𝗖𝗧𝗘𝗗\n\nGroup : " + G.name)
                                else:
                                    TBotMessage(msg.to, str(ret_))

                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to, "𝗥𝗘𝗝𝗘𝗖𝗧𝗘𝗗\n\nGroup : " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(msg.to, str(error))
                        elif cmd == "rejectall" and sender == noobcoderMID:
                            ginvited = noobcoder.getGroupIdsInvited()
                            if ginvited != [] and ginvited != None:
                                for gid in ginvited:
                                    time.sleep(0.5)
                                    noobcoder.rejectGroupInvitation(gid)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "𝗥𝗘𝗝𝗘𝗖𝗧𝗘𝗗\n\nGroup : " + G.name)
                                else:
                                    TBotMessage(msg.to, "Rejected {} invitations".format(str(len(ginvited))))
                            else:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "No invitations pending.")
                                else:
                                    TBotMessage(msg.to, "No invitations pending.")
                        elif cmd == "gcall" or cmd.startswith('gcall '):
                            if msg._from in [noobcoderMID]:
                                if len(cmd.split(' ')) <= 1:
                                    a = "╭───「 Gcall 」─\n│    | Command |  \n│Get Gcall\n│  Key: GetGroupCall\n│Spam Gcall\n│  Key: Gcall [num|@]\n╰──────"
                                    kntl(to, str(a))
                                else:
                                    if msg.toType == 2:
                                        j = int(cmd.split(' ')[1])
                                        a = [noobcoder.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                                            key = eval(msg.contentMetadata["MENTION"])
                                            key1 = key["MENTIONEES"][0]["M"]
                                            nama = [key1]
                                            b = [noobcoder.call.inviteIntoGroupCall(to,nama,mediaType=2) for b in a];noobcoder.sendMention(to, '𝗚𝗥𝗢𝗨𝗣 𝗖𝗔𝗟𝗟\n\n@!has been invited {} times to call.'.format(j),'',[key1])
                                        else:
                                            group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];b = [noobcoder.call.inviteIntoGroupCall(to,nama,mediaType=2) for b in a]
                                            if wait["flex"] == False:
                                                noobcoder.sendMessage(msg.to, '𝗚𝗥𝗢𝗨𝗣 𝗖𝗔𝗟𝗟\ninvited all members {} times to Groupcall.'.format(j))
                                            else:
                                                TBotMessage(msg.to, '𝗚𝗥𝗢𝗨𝗣 𝗖𝗔𝗟𝗟\ninvited all members {} times to Groupcall.'.format(j))
                                    if msg.toType == 1:
                                        j = int(cmd.split(' ')[1])
                                        a = [noobcoder.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                                        group = noobcoder.getRoom(to);nama = [contact.mid for contact in group.contacts];b = [noobcoder.call.inviteIntoGroupCall(to,nama,mediaType=2) for b in a]
                                        if wait["flex"] == False:
                                            noobcoder.sendMessage(msg.to, '𝗚𝗥𝗢𝗨𝗣 𝗖𝗔𝗟𝗟\ninvited all members {} times to Groupcall.'.format(j))
                                        else:
                                            TBotMessage(msg.to, '𝗚𝗥𝗢𝗨𝗣 𝗖𝗔𝗟𝗟\n\invited all members {} times to Groupcall.'.format(j))
                        elif cmd.startswith("inviteid "):
                            text = removeCmd("inviteid", text)
                            sep = text.split(" ")
                            idnya = text.replace(sep[0] + " ", text)
                            conn = noobcoder.findContactsByUserid(idnya)
                            noobcoder.findAndAddContactsByMid(conn.mid)
                            noobcoder.inviteIntoGroup(msg.to,[conn.mid])
                            group = noobcoder.getGroup(msg.to)
                            xname = noobcoder.getContact(conn.mid)
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = '「 Invited from Id 」\nName '
                            HOOKZ = str(xname.displayName)
                            pesan = ''
                            pesan2 = pesan+"@a\n"
                            xlen = str(len(zxc)+len(xpesan))
                            xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                            zx = {'S':xlen, 'E':xlen2, 'M':xname.mid}
                            zx2.append(zx)
                            zxc += pesan2
                            text = xpesan+ zxc + "To group " + str(group.name) +""
                            TBotMessage(receiver, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                        elif cmd.startswith("creategroup "):
                            text = removeCmd("creategroup", text)
                            sep = text.split(" ")
                            name = text.replace(sep[0] + " ", text)
                            noobcoder.createGroup(name, [noobcoderMID])
                            gids = noobcoder.getGroupIdsByName(name)
                            for gid in gids:
                                try:
                                    x = noobcoder.getGroup(gid)
                                    x.preventedJoinByTicket = False
                                    noobcoder.updateGroup(x)
                                except Exception as e:
                                    TBotMessage(msg.to, str(e))
                            TBotMessage(to, "Group Created {}\n\nQR : http://line.me/R/ti/g/{}".format(str(name), str(noobcoder.reissueGroupTicket(x.id))))
                        elif cmd.startswith("changegn"):
                            if msg.toType == 2:
                                X = noobcoder.getGroup(to)
                                X.name = removeCmd("changegn", text)
                                noobcoder.updateGroup(X)
                        elif cmd == "changepic group":
                            if msg.toType == 2:
                                if to not in settings["changeGroupPicture"]:
                                    settings["changeGroupPicture"].append(to)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Please send a picture...")
                                else:
                                    TBotMessage(msg.to, "Please send a picture...")
                        elif cmd.startswith('createnote ') or cmd == 'mentionnote':NoteCreate(to,cmd,msg)
                        elif cmd == "get note":
                            try:
                                if msg._from in [noobcoderMID]:
                                    data = noobcoder.getGroupPost(to)
                                    if data['result'] != []:
                                        try:
                                            no = 0
                                            b = []
                                            a = "𝗚𝗥𝗢𝗨𝗣"
                                            for i in data['result']['feeds']:
                                                b.append(i['post']['userInfo']['writerMid'])
                                                try:
                                                    for aasd in i['post']['contents']['textMeta']:b.append(aasd['mid'])
                                                except:pass
                                                no += 1
                                                gtime = i['post']['postInfo']['createdTime']
                                                try:g = i['post']['contents']['text'].replace('@','@!')
                                                except:g="None"
                                                if no == 1:sddd = '\n'
                                                else:sddd = '\n\n'
                                                a +="{}{}. Penulis : @!\nDescription: {}\nTotal Like: {}\nCreated at: {}\n".format(sddd,no,g,i['post']['postInfo']['likeCount'],humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                            a +="Status: Success Get "+str(data['result']['homeInfo']['postCount'])+" Note"
                                            noobcoder.sendMention(to,a,'',b)
                                        except Exception as e:
                                            return noobcoder.sendMessage(to,"𝗔𝗨𝗧𝗢 𝗥𝗘𝗦𝗣𝗢𝗡𝗗\n"+str(e))
                            except Exception as e:print(e)
                        elif cmd.startswith("get note "):
                            try:
                                if msg._from in [noobcoderMID]:
                                    data = noobcoder.getGroupPost(to)
                                    try:
                                        music = data['result']['feeds'][int(cmd.split(' ')[2]) - 1]
                                        b = [music['post']['userInfo']['writerMid']]
                                        try:
                                            for a in music['post']['contents']['textMeta']:b.append(a['mid'])
                                        except:pass
                                        try:
                                            g= "\n\nDescription:\n"+str(music['post']['contents']['text'].replace('@','@!'))
                                        except:
                                            g=""
                                        a="\n   Total Like: "+str(music['post']['postInfo']['likeCount'])
                                        a +="\n   Total Comment: "+str(music['post']['postInfo']['commentCount'])
                                        gtime = music['post']['postInfo']['createdTime']
                                        a +="\n   Created at: "+str(humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                        a += g
                                        zx = ""
                                        zxc = "𝗚𝗥𝗢𝗨𝗣\nType: Get Note\n   Penulis : @!"+a
                                        try:
                                            noobcoder.sendMention(to,zxc,'',b)
                                        except Exception as e:
                                            noobcoder.sendMessage(to, str(e))
                                        try:
                                            for c in music['post']['contents']['media']:
                                                params = {'userMid': noobcoder.getProfile().mid, 'oid': c['objectId']}
                                                s = noobcoder.server.urlEncode(noobcoder.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                                                if 'PHOTO' in c['type']:
                                                    try:
                                                        anunanu(to,s,wait)
                                                    except:pass
                                                else:
                                                    pass
                                                if 'VIDEO' in c['type']:
                                                    try:
                                                        anuanu(to,s,wait)
                                                    except:pass
                                                else:
                                                    pass
                                        except:
                                            pass
                                    except Exception as e:
                                        return noobcoder.sendMessage(to,"𝗔𝗨𝗧𝗢 𝗥𝗘𝗦𝗣𝗢𝗡𝗗\n"+str(e))
                            except Exception as e:print(e)
                        elif cmd == "get announ":
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            to = msg.to
                            a = noobcoder.getChatRoomAnnouncements(msg.to)
                            if a == []:
                                noobcoder.sendMention(to, '@!In {} there are no announcements.'.format(self.getGroup(to).name),'𝗔𝗡𝗡𝗢𝗨𝗡𝗖𝗘𝗠𝗘𝗡𝗧𝗦\n', [self.getProfile().mid])
                                return
                            no = 0
                            c = '𝗔𝗡𝗡𝗢𝗨𝗡𝗖𝗘𝗠𝗘𝗡𝗧𝗦'
                            h = []
                            ds = [a[b].creatorMid for b in range(len(a)) if a[b].creatorMid not in h]
                            for b in a:
                                if b.creatorMid not in h:
                                    h.append(b.creatorMid)
                                    no += 1
                                    c += "\n{}. @! #{}x".format(no,str(a).count(b.creatorMid))
                                noobcoder.sendMention(msg.to,c,'',h)
                        elif cmd.startswith("get announ "):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            to = msg.to
                            a = noobcoder.getChatRoomAnnouncements(msg.to)
                            if a == []:
                                noobcoder.sendMention(to, '@!In {} there are no announcements.'.format(noobcoder.getGroup(to).name),'𝗔𝗡𝗡𝗢𝗨𝗡𝗖𝗘𝗠𝗘𝗡𝗧𝗦\n', [noobcoder.getProfile().mid])
                                return
                            c = '𝗔𝗡𝗡𝗢𝗨𝗡𝗖𝗘𝗠𝗘𝗡𝗧𝗦'
                            no = 0
                            h = []
                            ds = [a[b].creatorMid for b in range(len(a)) if a[b].creatorMid not in h]
                            if len(msg.text.split(' ')) == 3:
                                sd = ds[int(msg.text.split(' ')[2])-1]
                            c+= '\nCreate by: @!'
                            no=0
                            for b in a:
                                if b.contents.link != None:
                                    if b.creatorMid in sd:
                                        no+=1
                                if 'line://nv/chatMsg?chatId=' in b.contents.link:sdg = '{}'.format(b.contents.link)
                                else:sdg = '{}'.format(b.contents.text)
                                if no == 1:c+= '\n{}. 「 {} 」\n{}'.format(no,humanize.naturaltime(datetime.fromtimestamp(b.createdTime/1000)),sdg)
                                else:c+= '\n\n{}. 「 {} 」\n{}'.format(no,humanize.naturaltime(datetime.fromtimestamp(b.createdTime/1000)),sdg)
                            noobcoder.sendMention(msg.to,c,'',[sd])
#=====================================================================
# Parameters Done
                        elif cmd == "parameters":
                            ret = " ☞  lkicks\n"
                            ret += " ☞  linvites\n"
                            ret += " ☞  lcancels\n"
                            ret += " ☞  ljoins\n"
                            ret += " ☞  lleaves"
                            if wait["flex"] == True:
                                TtempListMenu(to, "PARAMETERS", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗣𝗔𝗥𝗔𝗠𝗘𝗧𝗘𝗥\n\n" + str(ret))
                        elif cmd == "whois lexe":
                            tx = "𝗟𝗮𝘀𝘁 𝗘𝘅𝗲𝗰𝘂𝘁𝗶𝗼𝗻𝘀\n"
                            nul = []
                            for a in Lexe:
                                if a not in "lstatus" and a not in "lscon" and a not in "lban":
                                    if Lexe[a] == {}:nul.append(a)
                                    else:
                                        if to in Lexe[a]:
                                            tx += "{}:\n".format(a)
                                            try:
                                                num = 0
                                                for c in Lexe[a][to]["op3"]:
                                                    num += 1
                                                    tx += "	> {}.{}\n".format(num,noobcoder.getContact(c).displayName)
                                            except:
                                                nom = 0
                                                for c in Lexe[a][to]:
                                                    nom += 1
                                                    tx += "	> {}.{}\n".format(nom,noobcoder.getContact(c).displayName)
                                        else:nul.append(a)
                            tx += "______________\n"
                            for b in nul:
                                tx+= "{}: Not Found\n".format(b)
                            tx += "______________"
                            noobcoder.sendMessage(msg.to, tx)
                        elif cmd == "lkicks":
                            if to not in Lexe["lkick"]:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "No last kicked in this group.")
                                else:
                                    TBotMessage(msg.to, "No last kicked in this group.")
                            else:
                                dataMid = []
                                if Lexe["lkick"][to]["op3"] != {}:
                                    for a in Lexe["lkick"][to]["op3"]:
                                        dataMid.append(a)
                                    noobcoder.datamention(to, '𝗟𝗔𝗦𝗧 𝗞𝗜𝗖𝗞𝗘𝗗 𝗛𝗘𝗥𝗘', dataMid)
                                else:
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "No last kicked in this group.")
                                    else:
                                        TBotMessage(msg.to, "No last kicked in this group.")
                        elif cmd == "linvites":
                            if to not in Lexe["linvite"]:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "No last invited in this group.")
                                else:
                                    TBotMessage(msg.to, "No last invited in this group.")
                            else:
                                if Lexe["linvite"][to]["op3"] != {}:noobcoder.datamention(to,'𝗟𝗔𝗦𝗧 𝗜𝗡𝗩𝗜𝗧𝗘𝗗 𝗛𝗘𝗥𝗘',[mid for mid in Lexe["linvite"][to]["op3"]])
                                else:
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "No last invited in this group.")
                                    else:
                                        TBotMessage(msg.to, "No last invited in this group.")
                        elif cmd == "lcancels":
                            if to not in Lexe["lcancel"]:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "No last canceled in this group.")
                                else:
                                    TBotMessage(msg.to, "No last canceled in this group.")
                            else:
                                if Lexe["lcancel"][to]["op3"] != {}:noobcoder.datamention(to,'𝗟𝗔𝗦𝗧 𝗖𝗔𝗡𝗖𝗘𝗟𝗘𝗗 𝗛𝗘𝗥𝗘',[mid for mid in Lexe["lcancel"][to]["op3"]])
                                else:
                                    noobcoder.sendMessage(to, "No last canceled in this group.")
                        elif cmd == "ljoins":
                            if to not in Lexe["ljoin"]:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "No last joined in this group.")
                                else:
                                    TBotMessage(msg.to, "No last joined in this group.")
                            else:
                                dataMid = []
                                for a in Lexe["ljoin"][a]:
                                    dataMid.append(a)
                                noobcoder.datamention(to,'𝗟𝗔𝗦𝗧 𝗝𝗢𝗜𝗡𝗘𝗗 𝗛𝗘𝗥𝗘',dataMid)
                        elif cmd == "lleaves":
                            if to not in Lexe["lleave"]:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "No last left in this group.")
                                else:
                                    TBotMessage(msg.to, "No last left in this group.")
                            else:
                                noobcoder.datamention(to,'𝗟𝗔𝗦𝗧 𝗟𝗘𝗙𝗧 𝗛𝗘𝗥𝗘',[mid for mid in Lexe["lleave"][to]])
#=====================================================================
# Kicking Done
                        elif cmd == "kicking":
                            ret  = " ☞  kickall\n"
                            ret += " ☞  kick [Parameters]\n"
                            ret += " ☞  vkick [Parameters]\n"
                            ret += " ☞  kickbans\n"
                            ret += " ☞  kicknum [Amount]\n"
                            ret += " ☞  reinv\n"
                            ret += " ☞  kickinv\n"
                            ret += " ☞  kickplay\n"
                            ret += " ☞  multikick [num] [@]\n"
                            ret += " ☞  skill [name]\n"
                            ret += " ☞  shoot [name]\n"
                            ret += " ☞  kicplay [name]"
                            if wait["flex"] == True:
                                TtempListMenu(to, "KICKING", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗞𝗜𝗖𝗞𝗜𝗡𝗚\n\n" + str(ret))
                        elif cmd == "kickall":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                gMembers = [contact.mid for contact in group.members]
                                for i in gMembers:
                                    time.sleep(0.008)
                                    noobcoder.kickoutFromGroup(to,[i])
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "Kicked all.")
                                else:
                                    noobcoder.sendMessage(msg.to, "Kicked all.")
                            else:
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "Failed.")
                                else:
                                    noobcoder.sendMessage(msg.to, "Failed.")
                        elif cmd.startswith("kick"):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ", "")
                            ljoin = text.replace(proses[0] + " ljoin", "")
                            if "ljoin" == proses[1] or "ljoin" + ljoin == proses[1]:
                                if "" == ljoin:
                                    ljoin = "1"
                                l = int(ljoin)
                                l -= 1
                                hasil = countLexe(to,"ljoin",l)
                                num = []
                                for a in hasil:
                                    try:
                                        noobcoder.kickoutFromGroup(to,[a])
                                    except:pass
                            num = text.replace(proses[0] + " lcon", "")
                            if "lcon" == proses[1] or "lcon" + num == proses[1]:
                                if "" == num:
                                    try:
                                        noobcoder.kickoutFromGroup(to,[Lexe["lscon"][1]])
                                        Lexe["lstatus"] = True
                                    except:pass
                                else:
                                    if int(num) <= len(Lexe["lscon"]):
                                        try:
                                            noobcoder.kickoutFromGroup(to,Lexe["lscon"][1])
                                            Lexe["lstatus"] = True
                                        except:
                                            pass
                                    else:
                                        if wait["flex"] == True:
                                            TBotMessage(msg.to, "Last contacts are only {}".forma(len(Lexe["lscon"])))
                                        else:
                                            noobcoder.sendMessage(msg.to, "Last contacts are only {}".forma(len(Lexe["lscon"])))
                            else:
                                key = []
                                try:key = eval(msg.contentMetadata["MENTION"])
                                except:key =[]
                                if key == []:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:targets.append(x["M"])
                                    for a in targets:
                                        try:
                                            noobcoder.kickoutFromGroup(to, [a]);
                                            return
                                        except:pass
                        elif cmd.startswith("vkick"):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ", "")
                            ljoin = text.replace(proses[0] + " ljoin", "")
                            if "ljoin" == proses[1] or "ljoin" + ljoin == proses[1]:
                                if "" == ljoin:
                                    ljoin = "1"
                                l = int(ljoin)
                                l -= 1
                                hasil = countLexe(to,"ljoin",l)
                                num = []
                                for a in hasil:
                                    try:
                                        noobcoder.unsendMessage(msg.id)
                                        noobcoder.kickoutFromGroup(to,[a])
                                        noobcoder.findAndAddContactsByMid(a)
                                        noobcoder.inviteIntoGroup(to, [a])
                                        noobcoder.cancelGroupInvitation(to, [a])
                                    except:pass
                            num = text.replace(proses[0] + " lcon", "")
                            if "lcon" == proses[1] or "lcon" + num == proses[1]:
                                if "" == num:
                                    try:
                                        noobcoder.unsendMessage(msg.id)
                                        noobcoder.kickoutFromGroup(to, Lexe["lscon"][1])
                                        noobcoder.findAndAddContactsByMid(to, Lexe["lscon"][1])
                                        noobcoder.inviteIntoGroup(to, Lexe["lscon"][1])
                                        noobcoder.cancelGroupInvitation(to, Lexe["lscon"][1])
                                        Lexe["lstatus"] = True
                                    except:pass
                                else:
                                    if int(num) <= len(Lexe["lscon"]):
                                        try:
                                            noobcoder.unsendMessage(msg.id)
                                            noobcoder.kickoutFromGroup(to,Lexe["lscon"][1])
                                            noobcoder.findAndAddContactsByMid(to, Lexe["lscon"][1])
                                            noobcoder.inviteIntoGroup(to, Lexe["lscon"][1])
                                            noobcoder.cancelGroupInvitation(to, Lexe["lscon"][1])
                                            Lexe["lstatus"] = True
                                        except:
                                            pass
                                    else:
                                        if wait["flex"] == True:
                                            TBotMessage(msg.to, "Last contacts are only {}".forma(len(Lexe["lscon"])))
                                        else:
                                            noobcoder.sendMessage(msg.to, "Last contacts are only {}".forma(len(Lexe["lscon"])))
                            else:
                                key = []
                                try:key = eval(msg.contentMetadata["MENTION"])
                                except:key =[]
                                if key == []:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:targets.append(x["M"])
                                    for a in targets:
                                        try:
                                            noobcoder.unsendMessage(msg.id)
                                            noobcoder.kickoutFromGroup(to, [a])
                                            noobcoder.findAndAddContactsByMid(a)
                                            noobcoder.inviteIntoGroup(to, [a])
                                            noobcoder.cancelGroupInvitation(to, [a])
                                            return
                                        except:pass
                        elif cmd == "kickbans":
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                nama = [contact.mid for contact in group.members]
                                lists = []
                                for tag in banlist:
                                    lists+=filter(lambda str: str == tag, nama)
                                if lists == []:
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Banlist not is empty.")
                                    else:
                                        TBotMessage(msg.to, "Banlist not is empty.")
                                    return
                                for jj in lists:
                                    noobcoder.kickoutFromGroup(to,[jj])
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Banlist has been purged.")
                                else:
                                    TBotMessage(msg.to, "Banlist has been purged.")
                        elif cmd.startswith("reinv "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        noobcoder.findAndAddContactsByMid(ls)
                                        noobcoder.kickoutFromGroup(to, [ls])
                                        time.sleep(5)
                                        noobcoder.inviteIntoGroup(to, [ls])
                                    except:pass
                        elif cmd.startswith("kickinv "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        noobcoder.kickoutFromGroup(to, [ls])
                                        noobcoder.findAndAddContactsByMid(ls)
                                        noobcoder.inviteIntoGroup(to, [ls])
                                        noobcoder.cancelGroupInvitation(to, [ls])                                        
                                        noobcoder.inviteIntoGroup(to, [ls])
                                        noobcoder.cancelGroupInvitation(to, [ls])
                                        time.sleep(5)
                                        noobcoder.inviteIntoGroup(to, [ls])
                                    except:pass
                        elif cmd.startswith("kickplay "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        noobcoder.kickoutFromGroup(msg.to, [target])
                                        noobcoder.findAndAddContactsByMid(target)
                                        noobcoder.inviteIntoGroup(msg.to, [target])
                                        noobcoder.cancelGroupInvitation(msg.to, [target])
                                        noobcoder.inviteIntoGroup(msg.to, [target])
                                        noobcoder.cancelGroupInvitation(msg.to, [target])
                                        noobcoder.inviteIntoGroup(msg.to, [target])
                                    except:pass
                        elif cmd.startswith('multikick '):
                            j = int(cmd.split(' ')[1])
                            a = [noobcoder.adityasplittext(cmd,'s').replace('{} '.format(j),'')]*j
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    try:
                                        group = noobcoder.getGroup(to)
                                        group.preventedJoinByTicket = True
                                        noobcoder.updateGroup(group)
                                        b = [entod_in(to, ls) for b in a];noobcoder.sendMention(to, '「 MultiKick 」\n@!has been Kicked out with {} amount of MultiKick♪'.format(j),'',[ls])
                                    except Exception as e:
                                        print(e)
                        elif cmd.startswith("skill "):
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = noobcoder.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = noobcoder.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return noobcoder.sendMessage(msg.to, "not found name "+midn)
                           for target in targets:
                               noobcoder.kickoutFromGroup(msg.to,[target])
                        elif cmd.startswith("kicknum "):
                                 amount = cmd.replace("kicknum ","")
                                 jml = int(amount[0])
                                 group = noobcoder.getGroup(to)
                                 try:                                   
                                   x = [mem.mid for mem in group.members]
                                 except:                                   
                                   x = [mem.mid for mem in group.members]                                 
                                 t = random.choice(x)
                                 for i in range(jml):
                                    noobcoder.kickoutFromGroup(msg.to,[t])       
                        elif cmd.startswith("shoot "):
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = noobcoder.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           imnoob = 'simple.js gid={} token={} app={}'.format(to, noobcoder.authToken, "IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
                           for x in members:
                               contact = noobcoder.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return noobcoder.sendMessage(msg.to, "not found name "+midn)
                           for target in targets:
                             imnoob += ' uid={}'.format(target)
                           success = execute_js(imnoob)
                        elif cmd.startswith("kickplay "):
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = noobcoder.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = noobcoder.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return noobcoder.sendMessage(msg.to, "not found name "+midn)
                           for target in targets:
                               noobcoder.kickoutFromGroup(msg.to,[target])
                               noobcoder.findAndAddContactsByMid(target)
                               noobcoder.inviteIntoGroup(msg.to,[target])
                               noobcoder.cancelGroupInvitation(msg.to,[target])
                               noobcoder.inviteIntoGroup(msg.to,[target])
                               noobcoder.cancelGroupInvitation(msg.to,[target])
                               noobcoder.inviteIntoGroup(msg.to,[target])
#=====================================================================
# Banning Done
                        elif cmd == "banning":
                            ret  = " ☞  ban [mention]\n"
                            ret += " ☞  ban lcon[num]\n"
                            ret += " ☞  unban [mention]\n"
                            ret += " ☞  unban lcon[num]\n"
                            ret += " ☞  banslist\n"
                            ret += " ☞  contact bans\n"
                            ret += " ☞  clearbans\n"
                            ret += " ☞  addwhite [mention]\n"
                            ret += " ☞  addwhite lcon[num]\n"
                            ret += " ☞  whitelist\n"
                            ret += " ☞  contact whites\n"
                            ret += " ☞  clearwhites\n"
                            if wait["flex"] == True:
                                TtempListMenu(to, "BANNING", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗕𝗔𝗡𝗡𝗜𝗡𝗚\n\n" + str(ret))
                        elif cmd.startswith("ban "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num = 0
                                for a in hasil:
                                    if a in admins:
                                        if wait["flex"] == False:
                                            noobcoder.sendMessage(msg.to, "{} is an Admin, expel first.\n".format(noobcoder.getContact(a).displayName))
                                        else:
                                            TBotMessage(msg.to, "{} is an Admin, expel first.\n".format(noobcoder.getContact(a).displayName))
                                    if a in admins:
                                        if wait["flex"] == False:
                                            noobcoder.sendMessage(msg.to, "{} is a Bot, expel first.\n".format(noobcoder.getContact(a).displayName))
                                        else:
                                            TBotMessage(msg.to, "{} is a Bot, expel first.\n".format(noobcoder.getContact(a).displayName))
                                    if a not in banlist:
                                        banlist.append(a)
                                        num += 1
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Banned {} users.".format(num))
                                else:
                                    TBotMessage(msg.to, "Banned {} users.".format(num))
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    num = 0
                                    for a in targets:
                                        if a not in banlist:
                                            banlist.append(a)
                                            num += 1
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Banned {} users.".format(num))
                                    else:
                                        TBotMessage(msg.to, "Banned {} users.".format(num))
                        elif cmd.startswith("unban "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            friends = noobcoder.getAllContactIds()
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num2 = 0
                                tx =  ""
                                for a in hasil:
                                    if a in banlist:
                                        banlist.remove(a)
                                        num2 += 1
                                        tx += "{} is unbanned.\n".format(noobcoder.getContact(a).displayName)
                                tx += "\n{} Users unbanned.".format(num2)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, tx)
                                else:
                                    TBotMessage(to, tx)
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    num2 = 0
                                    tx =  ""
                                    for a in targets:
                                        if a in banlist:
                                            banlist.remove(a)
                                            num2 += 1
                                            tx += "{} is unbanned.\n".format(noobcoder.getContact(a).displayName)
                                    tx += "\n{} Users unbanned.".format(num2)
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, tx)
                                    else:
                                        TBotMessage(to, tx)
                        elif cmd == "banslist" or cmd == "listbans":
                            if wait["flex"] == False:
                                list20WithHeading(to,"𝗕𝗔𝗡𝗦 𝗟𝗜𝗦𝗧", "Banned users.",banlist)
                            else:
                                Tlist20WithHeading(to,"BANS LIST","Banned users.",banlist)
                        elif cmd == "contact bans" or cmd == "bancontact":
                            for a in banlist:
                                noobcoder.sendContact(msg.to, a)
                        elif cmd == "clearbans" or cmd == "clear bans":
                            banlist.clear()
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to,"Banslist is cleared.")
                            else:
                                TBotMessage(msg.to, "Banslist is  cleared.")
                        elif cmd.startswith("addwhite "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num = 0
                                for a in hasil:
                                    if a not in whitelist:
                                        whitelist.append(a)
                                        num += 1
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Added {} to Whitelist.".format(num))
                                else:
                                    TBotMessage(msg.to, "Added {} to Whitelist.".format(num))
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    num = 0
                                    for a in targets:
                                        if a not in whitelist:
                                            whitelist.append(a)
                                            num += 1
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Added {} to Whitelist.".format(num))
                                    else:
                                        TBotMessage(msg.to, "Added {} to Whitelist.".format(num))
                        elif cmd == "wlist" or cmd == "whitelist":
                            if wait["flex"] == False:
                                list20WithHeading(to,"𝗪𝗛𝗜𝗧𝗘 𝗟𝗜𝗦𝗧", "Members in Whitelist",whitelist)
                            else:
                                Tlist20WithHeading(to,"WHITE LIST","Members in Whitelist.",whitelist)
                        elif cmd == "contact whitelist" or cmd == "whitelistecontacts":
                            for a in whitelist:
                                noobcoder.sendContact(msg.to, a)
                        elif cmd == "clearwhites" or cmd == "clearwhitelist":
                            whitelist.clear()
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to,"Whitelist is cleared.")
                            else:
                                TBotMessage(msg.to, "Whitelist is  cleared.")
#=====================================================================
# Protection Done
                        elif cmd == "protection":
                            ret = " ☞  list protection\n"
                            ret += " ☞  proall On/Off\n"
                            ret += " ☞  proinv On/Off\n"
                            ret += " ☞  projoin On/Off\n"
                            ret += " ☞  prokick On/Off\n"
                            ret += " ☞  protag On/Off\n"
                            ret += " ☞  proname On/Off\n"
                            ret += " ☞  Status proinvite\n"
                            ret += " ☞  Status prokick\n"
                            ret += " ☞  Status protag\n"
                            ret += " ☞  Status proname\n"
                            ret += " ☞  Status proqr\n"
                            ret += " ☞  Remove proinvite\n"
                            ret += " ☞  Remove prokick\n"
                            ret += " ☞  Remove protag\n"
                            ret += " ☞  Remove proname\n"
                            ret += " ☞  Remove proqr"
                            if wait["flex"] == True:
                                TtempListMenu(to, "PROTECTION", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗣𝗥𝗢𝗧𝗘𝗖𝗧𝗜𝗢𝗡\n\n" + str(ret))
                        elif cmd == "list protection":
                            ma = ""
                            mb = ""
                            md = ""
                            me = ""
                            a = 0
                            b = 0
                            d = 0
                            e = 0
                            gid = protectqr
                            for group in gid:
                                a = a + 1
                                end = '\n'
                                ma += str(a) + ". " + noobcoder.getGroup(group).name + "\n"
                            gid = protectkick
                            for group in gid:
                                b = b + 1
                                end = '\n'
                                mb += str(b) + ". " + noobcoder.getGroup(group).name + "\n"
                            gid = protectjoin
                            for group in gid:
                                d = d + 1
                                end = '\n'
                                md += str(d) + ". " + noobcoder.getGroup(group).name + "\n"
                            gid = protectinvite
                            for group in gid:
                                e = e + 1
                                end = '\n'
                                me += str(e) + ". " + noobcoder.getGroup(group).name + "\n"
                            if wait["flex"] == True:
                                TBotMessage(msg.to, "𝗟𝗜𝗦𝗧 𝗢𝗙 𝗣𝗥𝗢𝗧𝗘𝗖𝗧𝗜𝗢𝗡𝗦\n\n- Protect Url :\n" + ma + "\n- ProtectKick :\n" + mb + "\n- Protect Join :\n" + md + "\n- Protect Invite :\n" + me + "\nTotal %s Protections" % (str(len(protectqr) + len(protectkick) + len(protectjoin) + len(protectinvite))))
                            else:
                                noobcoder.sendMessage(msg.to, "𝗟𝗜𝗦𝗧 𝗢𝗙 𝗣𝗥𝗢𝗧𝗘𝗖𝗧𝗜𝗢𝗡𝗦\n\n- Protect Url :\n" + ma + "\n- ProtectKick :\n" + mb + "\n- Protect Join :\n" + md + "\n- Protect Invite :\n" + me + "\nTotal %s Protections" % (str(len(protectqr) + len(protectkick) + len(protectjoin) + len(protectinvite))))
                        elif cmd.startswith("proall "):
                            text = removeCmd("protectall", text)
                            spl = text.replace('protectall  ', text)
                            if spl == 'on':
                                if msg.to in protectqr:
                                     msgs = ""
                                else:
                                     protectqr.append(msg.to)
                                if msg.to in protectkick:
                                    msgs = ""
                                else:
                                    protectkick.append(msg.to)
                                if msg.to in protectinvite:
                                    msgs = ""
                                else:
                                    protectinvite.append(msg.to)
                                if msg.to in protectjoin:
                                    msgs = ""
                                else:
                                    protectjoin.append(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "Protectall Has Been On\nIn Group : " +str(ginfo.name))
                                else:
                                    noobcoder.sendMessage(msg.to, "Protectall Has Been On\nIn Group : " +str(ginfo.name))
                            elif spl == 'off':
                                  if msg.to in protectqr:
                                       protectqr.remove(msg.to)
                                  else:
                                       msgs = ""
                                  if msg.to in protectkick:
                                       protectkick.remove(msg.to)
                                  else:
                                       msgs = ""
                                  if msg.to in protectinvite:
                                       protectinvite.remove(msg.to)
                                  else:
                                       msgs = ""
                                  if msg.to in protectjoin:
                                       protectjoin.remove(msg.to)
                                       ginfo = noobcoder.getGroup(msg.to)
                                  if wait["flex"] == True:
                                       TBotMessage(msg.to, "Protectall Has Been Off\nIn Group : " +str(ginfo.name))
                                  else:
                                       noobcoder.sendMessage(msg.to, "Protectall Has Been Off\nIn Group : " +str(ginfo.name))
                        elif cmd.startswith("proinv "):
                            text = removeCmd("proinv", text)
                            spl = text.replace('proinv ', text)
                            if spl == 'on':
                                if msg.to in protectinvite:
                                    msgs = "Protect invite alredy On."
                                else:
                                    protectinvite.append(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect invite is On in:\n" + str(ginfo.name)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                            elif spl == 'off':
                                if msg.to in protectinvite:
                                    protectinvite.remove(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect invite is Off in:\n" + str(ginfo.name)
                                else:
                                    msgs = "Protect invite is already Off."
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                        elif cmd.startswith("projoin "):
                            text = removeCmd("projoin", text)
                            spl = text.replace('projoin ', text)
                            if spl == 'on':
                                if msg.to in protectjoin:
                                    msgs = "Protect join Alredy On"
                                else:
                                    protectjoin.append(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect join Has Been On\nIn Group : " + str(ginfo.name)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                            elif spl == 'off':
                                if msg.to in protectjoin:
                                    protectjoin.remove(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect join Has Been Off\nIn Group : " + str(ginfo.name)
                                else:
                                    msgs = "Protect join Alredy Off"
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                        elif cmd.startswith("prokick "):
                            text = removeCmd("prokick", text)
                            spl = text.replace('prokick ', text)
                            if spl == 'on':
                                if msg.to in protectkick:
                                    msgs = "Protect kick Alredy Off"
                                else:
                                    protectkick.append(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect kick Has been On\nIn Group : " + str(ginfo.name)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                            elif spl == 'off':
                                if msg.to in protectkick:
                                    protectkick.remove(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect kick Has been Off\nIn Group : " + str(ginfo.name)
                                else:
                                    msgs = "Protect kick Already Off"
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                        elif cmd.startswith("protag "):
                            text = removeCmd("protag", text)
                            spl = text.replace('protag ', text)
                            if spl == 'on':
                                if msg.to in notag:
                                    msgs = "Protect Tag Alredy Off"
                                else:
                                    notag.append(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect Tag Has been On\nIn Group : " + str(ginfo.name)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                            elif spl == 'off':
                                if msg.to in notag:
                                    notag.remove(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect Tag Has been Off\nIn Group : " + str(ginfo.name)
                                else:
                                    msgs = "Protect Tag Already Off"
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                        elif cmd.startswith("proname "):
                            text = removeCmd("proname", text)
                            spl = text.replace('proname ', text)
                            if spl == 'on':
                                if msg.to in groupName:
                                    msgs = "Protect Name Alredy Off"
                                else:
                                    groupName.append(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect Name Has been On\nIn Group : " + str(ginfo.name)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                            elif spl == 'off':
                                if msg.to in groupName:
                                    groupName.remove(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect Name Has been Off\nIn Group : " + str(ginfo.name)
                                else:
                                    msgs = "Protect Name Already Off"
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                        elif cmd.startswith("proqr "):
                            text = removeCmd("proqr", text)
                            spl = text.replace('proqr ', text)
                            if spl == 'on':
                                if msg.to in protectqr:
                                    msgs = "Protect Qr Alredy Off"
                                else:
                                    protectqr.append(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect Qr Has been On\nIn Group : " + str(ginfo.name)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                            elif spl == 'off':
                                if msg.to in protectqr:
                                    protectqr.remove(msg.to)
                                    ginfo = noobcoder.getGroup(msg.to)
                                    msgs = "Protect Qr Has been Off\nIn Group : " + str(ginfo.name)
                                else:
                                    msgs = "Protect Qr Already Off"
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, msgs)
                                else:
                                    noobcoder.sendMessage(msg.to, msgs)
                        elif cmd == "status proinvite":
                            try:
                                if blockInvite == []:
                                    bi = "Denyinvite < Disabled >"
                                    TBotMessage(msg.to,bi)
                                else:
                                    bi = "Denyinvite List :\n"
                                    no=0
                                    for a in blockInvite:
                                        no+=1
                                        bi+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to, bi)
                                    else:
                                        noobcoder.sendMessage(msg.to, bi)
                            except: pass
                        elif cmd == "status prokick":
                            try:
                                if protectKick == []:
                                    pk = "Pro Kick < Disabled >"
                                    TBotMessage(msg.to,pk)
                                else:
                                    pk = "Pro Kick List :\n"
                                    no=0
                                    for a in protectKick:
                                        no+=1
                                        pk+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to, pk)
                                    else:
                                        noobcoder.sendMessage(msg.to, pk)
                            except: pass
                        elif cmd == "status protag":
                            try:
                                if notag == []:
                                    nt = "Notag is disabled."
                                    TBotMessage(msg.to, nt)
                                else:
                                    nt = "  「Notag List」\nGroup:"
                                    no=0
                                    for a in notag:
                                        no+=1
                                        nt+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to, nt)
                                    else:
                                        noobcoder.sendMessage(msg.to, nt)
                            except: pass
                        elif cmd == "status proname":
                            try:
                                if groupName == []:
                                    gn = "Namelock < Disabled >"
                                    TBotMessage(msg.to,gn)
                                else:
                                    gn = "Namelock List :\n"
                                    no=0
                                    for a in groupName:
                                        no+=1
                                        gn+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to, gn)
                                    else:
                                        noobcoder.sendMessage(msg.to, gn)
                            except: pass
                        elif cmd == "status proqr":
                            try:
                                if groupQr == []:
                                    gq = "BlockQr < Disabled >"
                                    TBotMessage(msg.to,gq)
                                else:
                                    gq = "BlockQr List :\n"
                                    no=0
                                    for a in groupQr:
                                        no+=1
                                        gq+= "\n  %i. %s" % (no,noobcoder.getGroup(a).name)
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to, gq)
                                    else:
                                        noobcoder.sendMessage(msg.to, gq)
                            except: pass
                        elif cmd == "remove proinvite":
                            try:
                                if blockInvite != []:
                                    total = len(blockInvite)
                                    delBlocklist()
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to, "Removed {} Denyinvite List".format(str(total)))
                                    else:
                                        noobcoder.sendMessage(msg.to, "Removed {} Denyinvite List".format(str(total)))
                                else:
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to,"Nothing in Protect Invite.")
                                    else:
                                        noobcoder.sendMessage(msg.to, "Nothing in Protect Invite.")
                            except: pass
                        elif cmd == "remove prokick":
                            try:
                                if protectKick != []:
                                    total = len(protectKick)
                                    delKicklist()
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to,"Removed {} Denykick List".format(str(total)))
                                    else:
                                        noobcoder.sendMessage(msg.to,"Removed {} Denykick List".format(str(total)))
                                else:
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to,"Nothing in Protect Kick.")
                                    else:
                                        noobcoder.sendMessage(msg.to, "Nothing in Protect Kick.")
                            except: pass
                        elif cmd == "remove protag":
                            try:
                                if notag != []:
                                    total = len(notag)
                                    delNotaglist()
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to,"Removed {} Notag List".format(str(total)))
                                    else:
                                        noobcoder.sendMessage(msg.to,"Removed {} Notag List".format(str(total)))
                                else:
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to,"Nothing in Protect Tag.")
                                    else:
                                        noobcoder.sendMessage(msg.to, "Nothing in Protect Tag.")
                            except: pass
                        elif cmd == "remove proqr":
                            try:
                                if groupQr != []:
                                    total = len(groupQr)
                                    delQrlist()
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to,"Removed {} Blockqr List".format(str(total)))
                                    else:
                                        noobcoder.sendMessage(msg.to,"Removed {} Blockqr List".format(str(total)))
                                else:
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to,"Nothing in Protect Qr.")
                                    else:
                                        noobcoder.sendMessage(msg.to, "Nothing in Protect Qr.")
                            except: pass
                        elif cmd == "remove proname":
                            try:
                                if groupName != []:
                                    total = len(groupName)
                                    delGnamelist()
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to,"Removed {} Namelock List".format(str(total)))
                                    else:
                                        noobcoder.sendMessage(msg.to,"Removed {} Namelock List".format(str(total)))
                                else:
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to,"Nothing in Protect Name.")
                                    else:
                                        noobcoder.sendMessage(msg.to, "Nothing in Protect Name.")
                            except: pass
#=====================================================================
# War Done
                        elif cmd == "war":
                            ret  = " ☞  bot [mention]\n"
                            ret += " ☞  bot lcon[num]\n"
                            ret += " ☞  addbots\n"
                            ret += " ☞  botslist\n"
                            ret += " ☞  contact bots\n"
                            ret += " ☞  clearbots\n"
                            ret += " ☞  invitebots\n"
                            ret += " ☞  target [mention]\n"
                            ret += " ☞  target lcon[num]\n"
                            ret += " ☞  deltarget [mention]\n"
                            ret += " ☞  deltarget lcon[num]\n"
                            ret += " ☞  targetslist\n"
                            ret += " ☞  contact targets\n"
                            ret += " ☞  cleartargets\n"
                            ret += " ☞  sendvirus:\n"
                            ret += " ☞  purge:\n"
                            ret += " ☞  nuke\n"
                            ret += " ☞  cleanse\n"
                            ret += " ☞  invitebots\n"
                            ret += " ☞  kicktargets\n"
                            ret += " ☞  takegroup\n"
                            ret += " ☞  mycommands\n"
                            ret += " ☞  set sendvirus:\n"
                            ret += " ☞  set purge:\n"
                            ret += " ☞  set nuke:\n"
                            ret += " ☞  set cleanse:\n"
                            ret += " ☞  set invitebots:\n"
                            ret += " ☞  set kicktargets:\n"
                            ret += " ☞  set takegroup:"
                            if wait["flex"] == True:
                                TtempListMenu(to, "WAR", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗪𝗔𝗥\n\n" + str(ret))
                        elif cmd.startswith("bot "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            if "all"== proses[1]:
                                group = noobcoder.getGroup(to)
                                try:
                                    members = [o.mid for o in group.members if o.mid not in noobcoderMID]
                                except:
                                    members = [o.mid for o in group.members if o.mid not in noobcoderMID]
                                targets = []
                                num2 = 0
                                for b in group.members:
                                    targets.append(b.mid)
                                for a in targets:
                                    if a not in noobcoderMID:
                                        bots.append(a)
                                        num2 += 1
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Added {} as Bots.".format(num))
                                else:
                                    TBotMessage(msg.to, "Added {} as Bots.".format(num))
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num = 0
                                for a in hasil:
                                    if a not in bots:
                                        bots.append(a)
                                        num += 1
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Added {} as Bots.".format(num))
                                else:
                                    TBotMessage(msg.to, "Added {} as Bots.".format(num))
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    num = 0
                                    for a in targets:
                                        if a not in bots:
                                            bots.append(a)
                                            num += 1
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Added {} as Bots.".format(num))
                                    else:
                                        TBotMessage(msg.to, "Added {} as Bots.".format(num))
                        elif cmd == "addbots":
                            friends = noobcoder.getAllContactIds()
                            for a in bots:
                                if a not in friends:
                                    try:
                                        noobcoder.findAndAddContactsByMid(a)
                                        noobcoder.sendMessage(to, "{} Bot contacts added.".format(noobcoder.getContact(a).displayName))
                                    except:
                                        noobcoder.sendMessage(to, "Adding banned, please try again later.")
                                else:
                                    noobcoder.sendMessage(to, "Bot {} already in contact".format(noobcoder.getContact(a).displayName))
                        elif cmd == "botslist" or cmd == "bots" or cmd == "listbots":
                            if wait["flex"] == False:
                                list20WithHeading(msg.to,"𝗕𝗢𝗧𝗦","Bots",bots)
                            else:
                                Tlist20WithHeading(msg.to,"BOTS","Bots",bots)
                        elif cmd == "contactbots" or cmd == "botscontact" or cmd == "contact bots":
                            for a in bots:
                                noobcoder.sendContact(to, a)
                        elif cmd == "clearbots" or cmd == "clearbotslist":
                            bots.clear()
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to,"Botslist is cleared.")
                            else:
                                TBotMessage(msg.to, "Botslist is cleared.")
                        elif cmd.startswith("target "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num = 0
                                for a in hasil:
                                    if a not in enemies:
                                        enemies.append(a)
                                        num += 1
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Added {} as Targets.".format(num))
                                else:
                                    TBotMessage(msg.to, "Added {} as Targets.".format(num))
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    num = 0
                                    for a in targets:
                                        if a not in enemies:
                                            enemies.append(a)
                                            num += 1
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, "Added {} as Targets.".format(num))
                                    else:
                                        TBotMessage(msg.to, "Added {} as Targets.".format(num))
                        elif cmd.startswith("deltarget "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            friends = noobcoder.getAllContactIds()
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num2 = 0
                                tx =  ""
                                for a in hasil:
                                    if a in enemies:
                                        enemies.remove(a)
                                        num2 += 1
                                        tx += "Removed {} as Targets.\n".format(noobcoder.getContact(a).displayName)
                                tx += "\n{} Users removed as Targets.".format(num2)
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, tx)
                                else:
                                    TBotMessage(to, tx)
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    num2 = 0
                                    tx =  ""
                                    for a in targets:
                                        if a in banlist:
                                            banlist.remove(a)
                                            num2 += 1
                                            tx += "Removed {} as Targets.\n".format(noobcoder.getContact(a).displayName)
                                    tx += "\n{} Users removed as Targets.".format(num2)
                                    if wait["flex"] == False:
                                        noobcoder.sendMessage(msg.to, tx)
                                    else:
                                        TBotMessage(to, tx)
                        elif cmd == "targetslist" or cmd == "targets" or cmd == "listtargets":
                            if wait["flex"] == False:
                                list20WithHeading(msg.to,"𝗧𝗔𝗥𝗚𝗘𝗧𝗦","Targets",enemies)
                            else:
                                Tlist20WithHeading(msg.to,"TARGETS","Targets",enemies)
                        elif cmd == "contacttargets" or cmd == "targetscontact" or cmd == "contact targets":
                            for a in enemies:
                                noobcoder.sendContact(to, a)
                        elif cmd == "cleartargets" or cmd == "cleartargetslist":
                            enemies.clear()
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to,"Targetslist is cleared.")
                            else:
                                TBotMessage(msg.to, "Targetslist is cleared.")
                        elif cmd == ("mycommands"):
                            tx = "\nSend Virus:\n[{}]".format(ownerData["sendvirus"])
                            tx += "\n\nPurge Bans:\n[{}]".format(ownerData["purge"])
                            tx += "\n\nNuke:\n[{}]".format(ownerData["nuke"])
                            tx += "\n\nCleanse:\n[{}]".format(ownerData["cleanse"])
                            tx += "\n\nInvite Bots:\n[{}]".format(ownerData["invitebots"])
                            tx += "\n\nKick Targets:\n[{}]".format(ownerData["kicktargets"])
                            tx += "\n\nTake Group:\n[{}]".format(ownerData["takegroup"])
                            if wait["flex"] == True:
                                TBotMessageWithHeader(msg.to, "𝗟𝗜𝗦𝗧 𝗢𝗙 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦\n", str(tx))
                            else:
                                noobcoder.sendMessage(to, "𝗟𝗜𝗦𝗧 𝗢𝗙 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦\n" + str(tx))
                        elif cmd.startswith("set sendvirus: "):
                            spl = removeCmd("set sendvirus:", text)
                            ownerData["sendvirus"] = spl
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Send Virus is set to:\n [{}]".format(str(ownerData["sendvirus"])))
                            else:
                                TBotMessage(msg.to, "Send Virus is set to:\n [{}]".format(str(ownerData["sendvirus"])))
                        elif cmd == ("sendvirus") or cmd.startswith(str(ownerData["sendvirus"])):
                            for x in range(100):
                                noobcoder.sendMessage(to, covid19)
                        elif cmd.startswith("set purge: "):
                            spl = removeCmd("set purge:", text)
                            ownerData["purge"] = spl
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Purge is set to:\n [{}]".format(str(wait["purge"])))
                            else:
                                TBotMessage(msg.to, "Purge is set to:\n [{}]".format(str(wait["purge"])))
                        elif cmd == ("purge") or cmd.startswith(str(ownerData["purge"])):
                            group = noobcoder.getGroup(to)
                            pendings = []
                            memberrs = []
                            members = [o.mid for o in group.members if o.mid not in noobcoderMID]
                            if group.invitee is not None:
                                pen = [a.mid for a in group.invitee]
                                for a in pen: pendings.append(a)
                            for b in group.members:
                                memberrs.append(b.mid)
                            cmd = 'style.js gid={} token={}'.format(to, noobcoder.authToken)
                            for c in banlist:
                                if c in memberrs:
                                    if c not in maker and c not in noobcoderMID and c not in admins:
                                        cmd += ' uid={}'.format(c)
                                if c in pendings:
                                    if c not in maker and c not in noobcoderMID and c not in admins:
                                        cmd += ' cid={}'.format(c)
                            success = execute_js(cmd)
                        elif cmd.startswith("set nuke: "):
                            spl = removeCmd("set nuke:", text)
                            ownerData["nuke"] = spl
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Nuke is set to:\n [{}]".format(str(ownerData["nuke"])))
                            else:
                                TBotMessage(msg.to, "Nuke is set to:\n [{}]".format(str(ownerData["nuke"])))
                        elif cmd == ("nuke") or cmd.startswith(str(ownerData["nuke"])):
                            group = noobcoder.getGroup(to)
                            pendings = []
                            memberrs = []
                            members = [o.mid for o in group.members if o.mid not in noobcoderMID]
                            if group.invitee is not None:
                                pen = [a.mid for a in group.invitee]
                                for a in pen: pendings.append(a)
                            for b in group.members:
                                memberrs.append(b.mid)
                            cmd = 'style.js gid={} token={}'.format(to, noobcoder.authToken)
                            for c in memberrs:
                                if c not in maker and c not in noobcoderMID and c not in admins and c not in whitelist:
                                    cmd += ' uid={}'.format(c)
                            success = execute_js(cmd)
                        elif cmd.startswith("set cleanse: "):
                            spl = removeCmd("set cleanse:", text)
                            ownerData["kicker"] = spl
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Cleanse is set to:\n [{}]".format(str(ownerData["cleanse"])))
                            else:
                                TBotMessage(msg.to, "Cleanse is set to:\n [{}]".format(str(ownerData["cleanse"])))
                        elif cmd == ("cleanse") or cmd.startswith(str(ownerData["cleanse"])):
                            group = noobcoder.getGroup(to)
                            pendings = []
                            memberrs = []
                            members = [o.mid for o in group.members if o.mid not in noobcoderMID]
                            if group.invitee is not None:
                                pen = [a.mid for a in group.invitee]
                                for a in pen: pendings.append(a)
                            for b in group.members:
                                memberrs.append(b.mid)
                            cmd = 'style.js gid={} token={}'.format(to, noobcoder.authToken)
                            for c in memberrs:
                                if c not in maker and c not in noobcoderMID and c not in admins and c not in whitelist:
                                    cmd += ' uid={}'.format(c)
                            for d in pendings:
                                if d not in maker and d not in noobcoderMID and d not in admins and c not in whitelist:
                                    cmd += ' cid={}'.format(d)
                            success = execute_js(cmd)
                        elif cmd.startswith("set invitebots: "):
                            spl = removeCmd("set invitebots:", text)
                            ownerData["invitebots"] = spl
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Invite Bots is set to:\n [{}]".format(ownerData["invitebots"]))
                            else:
                                TBotMessage(msg.to, "Invite Bots is set to:\n [{}]".format(ownerData["invitebots"]))
                        elif cmd == ("invitebots") or cmd.startswith(str(ownerData["invitebots"])):
                            noobcoder.inviteIntoGroup(to, bots)
                        elif cmd.startswith("set kicktargets: "):
                            spl = removeCmd("set kicktargets:", text)
                            ownerData["kicktargets"] = spl
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Kick targets is set to:\n [{}]".format(str(wait["kicktargets"])))
                            else:
                                TBotMessage(msg.to, "Kick targets is set to:\n [{}]".format(str(wait["kicktargets"])))
                        elif cmd == ("kicktargets") or cmd.startswith(str(ownerData["kicktargets"])):
                            group = noobcoder.getGroup(to)
                            pendings = []
                            memberrs = []
                            members = [o.mid for o in group.members if o.mid not in noobcoderMID]
                            if group.invitee is not None:
                                pen = [a.mid for a in group.invitee]
                                for a in pen: pendings.append(a)
                            for b in group.members:
                                memberrs.append(b.mid)
                            cmd = 'style.js gid={} token={}'.format(to, noobcoder.authToken)
                            for c in enemies:
                                if c in memberrs:
                                    if c not in maker and c not in noobcoderMID and c not in admins:
                                        cmd += ' uid={}'.format(c)
                                if c in pendings:
                                    if c not in maker and c not in noobcoderMID and c not in admins:
                                        cmd += ' cid={}'.format(c)
                            success = execute_js(cmd)
                        elif cmd.startswith("set takegroup: "):
                            spl = removeCmd("set takegroup:", text)
                            ownerData["takegroup"] = spl
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Takegroup is set to:\n [{}]".format(str(wait["takegroup"])))
                            else:
                                TBotMessage(msg.to, "Takegroup is set to:\n [{}]".format(str(wait["takegroup"])))
                        elif cmd == ("takegroup") or cmd.startswith(str(ownerData["takegroup"])):
                            group = noobcoder.getGroup(to)
                            pendings = []
                            memberrs = []
                            members = [o.mid for o in group.members if o.mid not in noobcoderMID]
                            if group.invitee is not None:
                                pen = [a.mid for a in group.invitee]
                                for a in pen: pendings.append(a)
                            for b in group.members:
                                memberrs.append(b.mid)
                            cmd = 'style.js gid={} token={}'.format(to, noobcoder.authToken)
                            for c in enemies:
                                if c in memberrs:
                                    if c not in maker and c not in noobcoderMID and c not in admins:
                                        cmd += ' uid={}'.format(c)
                                if c in pendings:
                                    if c not in maker and c not in noobcoderMID and c not in admins:
                                        cmd += ' cid={}'.format(c)
                            for b in bots:
                                cmd += ' uik={}'.format(b)
                            success = execute_js(cmd)
#=====================================================================
# Friends Done
                        elif cmd == "friends":
                            ret  = " ☞  friendslist\n"
                            ret += " ☞  friend info [num]\n"
                            ret += " ☞  addfriend [@]\n"
                            ret += " ☞  delete <pm>\n"
                            ret += " ☞  delfriend [@]\n"
                            ret += " ☞  del friend [num]\n"
                            ret += " ☞  clearfriends\n"
                            ret += " ☞  blockfriend [@]\n"
                            ret += " ☞  blocklist [@]"
                            if wait["flex"] == True:
                                TtempListMenu(to, "FRIENDS", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗙𝗥𝗜𝗘𝗡𝗗𝗦\n\n" + str(ret))
                        elif cmd == 'friendslist':
                            linefriends = noobcoder.refreshContacts()
                            if wait["flex"] == False:
                                list20WithHeading(to,"𝗙𝗥𝗜𝗘𝗡𝗗𝗦 𝗟𝗜𝗦𝗧","Line Friends",linefriends)
                            else:
                                noobcoder.datamention(msg.to,'𝗙𝗥𝗜𝗘𝗡𝗗𝗦 𝗟𝗜𝗦𝗧',linefriends)
                        elif cmd.startswith("friend info "):
                            msg.text = msg.text = noobcoder.mycmd(msg.text,wait)
                            if len(msg.text.split(' ')) == 3:
                                b = noobcoder.refreshContacts()
                                noobcoder.getinformation(to,b[int(msg.text.split(' ')[2])-1],wait)
                        elif cmd.startswith("addfriend "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    noobcoder.findAndAddContactsByMid(ls)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "Added " + str(contact.displayName) + " as Line friend.")
                                else:
                                    noobcoder.sendMessage(msg.to, "Added " + str(contact.displayName) + " as Line friend.")
                        elif cmd == "delete":
                            n = len(noobcoder.getAllContactIds())
                            try:
                                noobcoder.deleteContact(to)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "Friend deleted.")
                                else:
                                    noobcoder.sendMessage(msg.to, "Friend deleted.")
                            except:pass
                        elif cmd.startswith("delfriend "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    n = len(noobcoder.getAllContactIds())
                                    try:
                                        noobcoder.deleteContact(ls)
                                    except:pass
                                    t = len(noobcoder.getAllContactIds())
                                    noobcoder.generateReplyMessage(msg.id)
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to, "Friend deleted.")
                                    else:
                                        noobcoder.sendMessage(msg.to, "Friend deleted.")
                        elif cmd.startswith("del friend "):
                            anu = noobcoder.refreshContacts()
                            noobcoder.deletefriendnum(to, wait, cmd)
                        elif cmd == "clearfriends":
                            n = len(noobcoder.getAllContactIds())
                            try:
                                time.sleep(0.5)
                                noobcoder.clearContacts()
                            except:
                                pass
                            t = len(noobcoder.getAllContactIds())
                            if wait["flex"] == True:
                                TBotMessage(msg.to, "All friends cleard.")
                            else:
                                noobcoder.sendMessage(msg.to, "All friends cleard.")
                        elif cmd.startswith("blockfriend "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = noobcoder.getContact(ls)
                                    noobcoder.blockContact(ls)
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to, "Added " + str(contact.displayName) + " to Blocklist.")
                                    else:
                                        noobcoder.sendMessage(msg.to, "Added " + str(contact.displayName) + " to Blocklist.")
                        elif cmd == "blocklist" and sender == noobcoderMID:
                            blockedlist = noobcoder.getBlockedContactIds()
                            if blockedlist == []:
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "No blocked contacts.")
                                else:
                                    noobcoder.sendMessage(msg.to, "No blocked contacts.")
                            else:
                                for kontak in blockedlist:
                                    if wait["flex"] == True:
                                        TBotMessage(msg.to, text=None, contentMetadata={'mid': kontak}, contentType=13)
                                    else:
                                        noobcoder.sendMessage(msg.to, text=None, contentMetadata={'mid': kontak}, contentType=13)
# Check it
                        elif cmd == "blockslist" and sender == noobcoderMID:
                            blockedlist = noobcoder.getBlockedContactIds()
                            kontak = noobcoder.getContacts(blockedlist)
                            num = 1
                            msgs = "「 Blocked List 」\n"
                            for ids in kontak:
                                msgs += "\n%i. %s" % (num, ids.displayName)
                                num = (num + 1)
                            msgs += "\n\nTotal Blocked : %i" % len(kontak)
                            msgs += "\nBlockInfo「 number 」"
                            msgs += "\nConBlock"
                            msgs += "\nBlockfriend [@]"
                            msgs += "\nBlockmid [mid]"
                            msgs += "\nUnblockmid [mid]"
                            hello = "{}".format(str(msgs))
                            data = {
                                "type": "text",
                                "text": "{}".format(str(msgs)),
                                "sentBy": {
                                    "label": "{}".format(noobcoder.getContact(noobcoderMID).displayName),
                                    "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                    "linkUrl": "line://nv/profilePopup/mid=abbu.jan"
                                }
                            }
                            sendTemplate(to, data)
#=====================================================================
# Broadcast Done
                        elif cmd == "broadcast":
                            ret  = " ☞  groupcast1 [text]\n"
                            ret += " ☞  groupcast2 [text]\n"
                            ret += " ☞  friendscast1 [text]\n"
                            ret += " ☞  friendscast2 [text]\n"
                            ret += " ☞  allbroadcast [text]\n"
                            ret += " ☞  gcastvoice [text]\n"
                            ret += " ☞  fcastvoice [text]"
                            if wait["flex"] == True:
                                TtempListMenu(to, "BROADCAST", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧\n\n" + str(ret))
                        elif cmd.startswith("groupcast1"):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ", "")
                            chat = "{}".format(matt)
                            groups = noobcoder.getGroupIdsJoined()
                            for gr in groups:
                                groupscast(gr, matt)
                                time.sleep(2)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Broadcast sent to {} groups.".format(str(len(groups))))
                            else:
                                TBotMessage(msg.to, "Broadcast sent to {} groups.".format(str(len(groups))))
                        elif cmd.startswith("groupcast2"):
                            try:
                                sep = text.split(" ")
                                bctxt = text.replace(sep[0] + " ", "")
                                gr = noobcoder.getGroupIdsJoined()
                                for group in gr:
                                    time.sleep(0.5)
                                    noobcoder.sendMessage(group, "𝗚𝗥𝗢𝗨𝗣 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧\n\n{}".format(str(bctxt)))
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Broadcast sent to {} groups.".format(str(len(groups))))
                                else:
                                    TBotMessage(msg.to, "Broadcast sent to {} groups.".format(str(len(groups))))
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Please open your letter sealing ...")
                                else:
                                    TBotMessage(msg.to, "Please open your letter sealing ...")
                        elif cmd.startswith("friendscast1"):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ", "")
                            chat = "{}".format(matt)
                            friends = noobcoder.getAllContactIds()
                            for friend in friends:
                                friendscast(friend, matt)
                                time.sleep(2)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Broadcast sent to {} friends.".format(str(len(friends))))
                            else:
                                TBotMessage(msg.to, "Broadcast sent to {} friends.".format(str(len(friends))))
                        elif cmd.startswith("friendscast2"):
                            txt = removeCmd("fbroadcast", text)
                            friends = noobcoder.getAllContactIds()
                            for friend in friends:
                                noobcoder.sendMessage(friend, "𝗙𝗥𝗜𝗘𝗡𝗗𝗦 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧\n\n{}".format(str(txt)))
                                time.sleep(0.5)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Broadcast sent to {} friends.".format(str(len(friends))))
                            else:
                                TBotMessage(msg.to, "Broadcast sent to {} friends.".format(str(len(friends))))
                        elif cmd.startswith("allbroadcast "):
                            txt = removeCmd("allbroadcast", text)
                            friends = noobcoder.getAllContactIds()
                            groups = noobcoder.getGroupIdsJoined()
                            for group in groups:
                                noobcoder.sendMessage(group, "𝗚𝗥𝗢𝗨𝗣 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧\n\n{}".format(str(txt)))
                                time.sleep(0.5)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Broadcast sent to {} groups.".format(str(len(groups))))
                            else:
                                TBotMessage(msg.to, "Broadcast sent to {} groups.".format(str(len(groups))))
                            for friend in friends:
                                noobcoder.sendMessage(friend, "𝗙𝗥𝗜𝗘𝗡𝗗𝗦 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧\n\n{}".format(str(txt)))
                                time.sleep(0.5)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Broadcast sent to {} friends.".format(str(len(friends))))
                            else:
                                TBotMessage(msg.to, "Broadcast sent to {} friends.".format(str(len(friends))))
                        elif cmd.startswith("gcastvoice "):
                                bctxt = removeCmd("gcastvoice", text)
                                bc = ("")
                                cb = (bctxt + bc)
                                tts = gTTS(cb, lang='id', slow=False)
                                tts.save('tts.mp3')
                                n = noobcoder.getGroupIdsJoined()
                                for manusia in n:
                                    noobcoder.sendAudio(manusia, 'tts.mp3')
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Voice Broadcast sent to {} groups.".format(str(len(groups))))
                                else:
                                    TBotMessage(msg.to, "Voice Broadcast sent to {} groups.".format(str(len(groups))))
                        elif cmd.startswith("fcastvoice "):
                                bctxt = removeCmd("gcastvoice", text)
                                bc = ("")
                                cb = (bctxt + bc)
                                tts = gTTS(cb, lang='id', slow=False)
                                tts.save('tts.mp3')
                                n = noobcoder.getAllContactIdsJoined()
                                for manusia in n:
                                    noobcoder.sendAudio(manusia, 'tts.mp3')
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Voice Broadcast sent to {} friends.".format(str(len(friends))))
                                else:
                                    TBotMessage(msg.to, "Voice Broadcast sent to {} friends.".format(str(len(friends))))
#=====================================================================
# Mention Done
                        elif cmd == "mention":
                            ret = " ☞  mention [num] [@]\n"
                            ret += " ☞  mentionname [name]\n"
                            ret += " ☞  tagall\n"
                            ret += " ☞  mentionMc\n"
                            ret += " ☞  mentionall -s\n"
                            ret += " ☞  check mention\n"
                            ret += " ☞  clear mention"
                            if wait["flex"] == True:
                                TtempListMenu(to, "MENTION", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗠𝗘𝗡𝗧𝗜𝗢𝗡\n\n" + str(ret))
                        elif cmd.startswith("mention "):
                            msg.text = noobcoder.mycmd(msg.text,wait)
                            if msg.toType == 0:
                                noobcoder.datamention(to,'𝗠𝗘𝗡𝗧𝗜𝗢𝗡',[to]*int(cmd.split(" ")[1]))
                            elif msg.toType == 2:
                                gs = noobcoder.getGroup(to)
                                nama = [contact.mid for contact in gs.members]
                                try:
                                    if 'MENTION' in msg.contentMetadata.keys()!=None:noobcoder.datamention(to,'Spam',[eval(msg.contentMetadata["MENTION"])["MENTIONEES"][0]["M"]]*int(cmd.split(" ")[1]))
                                    else:texst = noobcoder.adityasplittext(cmd)
                                    gs = noobcoder.getGroup(to)
                                    nama = [contact.mid for contact in gs.members];nama.remove(noobcoder.getProfile().mid)
                                    c = ['{}:-:{}'.format(a.displayName,a.mid) for a in gs.members]
                                    c.sort()
                                    b = []
                                    for s in c:
                                        if len(texst) == 1:dd = s[len(texst)-1].lower()
                                        else:dd = s[:len(texst)].lower()
                                        if texst in dd:b.append(s.split(':-:')[1])
                                    noobcoder.datamention(to,'STORE',b)
                                except:noobcoder.adityaarchi(wait,'Mention','',to,noobcoder.adityasplittext(msg.text),msg,'\n├Group: '+gs.name[:20],nama=nama)
                        elif cmd.startswith('mentionname '):
                            texst = noobcoder.adityasplittext(cmd)
                            gs = noobcoder.getGroup(to)
                            c = ['{}:-:{}'.format(a.displayName,a.mid) for a in gs.members]
                            c.sort()
                            b = []
                            for s in c:
                                if texst in s.split(':-:')[0].lower():b.append(s.split(':-:')[1])
                            noobcoder.datamention(to,'𝗠𝗘𝗡𝗧𝗜𝗢𝗡 𝗕𝗬 𝗡𝗔𝗠𝗘',b)
                        elif cmd == "tagall":
                            group = noobcoder.getGroup(to)
                            members = [o.mid for o in group.members if o.mid not in noobcoderMID]
                            noobcoder.listmention(to, '𝗧𝗔𝗚 𝗟𝗜𝗦𝗧', members)
                        elif cmd == "mentionmc":
                            a = noobcoder.getRoom(msg.to)
                            nama = [contact.mid for contact in a.contacts]
                            noobcoder.datamention(msg.to, '𝗠𝗘𝗡𝗧𝗜𝗢𝗡 𝗔𝗟𝗟', nama)
                        elif cmd == "mentionall -s":
                            noobcoder.unsendMessage(msg_id)
                            try:group = noobcoder.getGroup(msg.to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                            except:group = noobcoder.getRoom(msg.to);nama = [contact.mid for contact in group.contacts]
                            k = len(nama)//20
                            for a in range(k+1):
                                if a == 0:noobcoder.mentionmention(to=msg.to,wait=wait,text='',dataMid=nama[:20],pl=0,ps='╭「 𝗠𝗘𝗡𝗧𝗜𝗢𝗡 」─',pg='MENTIONALLUNSED',pt=nama)
                                else:noobcoder.mentionmention(to=msg.to,wait=wait,text='',dataMid=nama[a*20 : (a+1)*20],pl=a*20,ps='├「 Mention 」─',pg='MENTIONALLUNSED',pt=nama)
                        elif cmd == "clear mention":
                            try:
                                del wait['ROM'][to]
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "Mention history deleted.")
                                else:
                                    TBotMessage(msg.to, "Mention history deleted.")
                            except:
                                if wait["flex"] == False:
                                    noobcoder.sendMessage(msg.to, "No mention history found.")
                                else:
                                    TBotMessage(msg.to, "No mention history found.")
                        elif cmd == "check mention":
                            if to in wait['ROM']:
                                moneys = {}
                                msgas = ''
                                for a in wait['ROM'][to].items():
                                    moneys[a[0]] = [a[1]['msg.id'],a[1]['waktu']] if a[1] is not None else idnya
                                sort = sorted(moneys)
                                sort.reverse()
                                sort = sort[0:]
                                msgas = '𝗠𝗘𝗡𝗧𝗜𝗢𝗡 𝗛𝗜𝗦𝗧𝗢𝗥𝗬\n'
                                h = []
                                no = 0
                                for m in sort:
                                    has = ''
                                    nol = -1
                                    for kucing in moneys[m][0]:
                                        nol+=1
                                        has+= '\nline://nv/chatMsg?chatId={}&messageId={} {}'.format(to,kucing,humanize.naturaltime(datetime.fromtimestamp(moneys[m][1][nol]/1000)))
                                    h.append(m)
                                    no+=1
                                    if m == sort[0]:
                                        msgas+= '\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
                                    else:
                                        msgas+= '\n\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
                                mentions(to, msgas, h)
                                del wait['ROM'][to]
                            else:
                                try:
                                    msgas = 'Sorry @!In Group @!no mentions.'.format(noobcoder.getGroup(to).name)
                                    mentions(to, msgas, [noobcoderMID])
                                except:
                                    msgas = 'Sorry @!In Group @!no mentions.'
                                    mentions(to, msgas, [noobcoderMID])
#=====================================================================
# Media Done
                        elif cmd == "media":
                            ret  = " ☞  smule [search]\n"
                            ret += " ☞  Youtubemp3 [url]\n"
                            ret += " ☞  Youtubemp4 [url]\n"
                            ret += " ☞  Fileytmp3 [url]\n"
                            ret += " ☞  Fileytmp4 [url]"
                            if wait["flex"] == True:
                                TtempListMenu(to, "MEDIA", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗠𝗘𝗗𝗜𝗔\n\n" + str(ret))
                        elif text.lower().startswith("smule "):
                            separate = text.split(" ")
                            id = text.replace(separate[0] + " ", "")
                            cond = id.split("|")
                            search = str(cond[0])
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                r = web.get("https://smule.com/{}/performances/json".format(urllib.parse.quote(search)))
                                data = r.text
                                data = json.loads(data)
                                if len(cond) == 1:
                                    ret_ = "LIST RECORD"
                                    no = 0 + 1
                                    for smule in data["list"]:
                                        ret_ += "\n" + str(no) + "• " + str(smule["title"])
                                        no += 1
                                    ret_ += "\n"
                                    # true = True
                                    profile = "https://initiate.alphacoders.com/queue_files/1082167.jpg"
                                    chatme = ""
                                    print('Search Smule')
                                    true = True
                                    data = {
                                        "type": "flex",
                                        "altText": "SMULE MEDIA",
                                        "contents": {
                                            "styles": {
                                                "header": {
                                                    "backgroundColor": Colors["Background"]
                                                },
                                                "body": {
                                                    "backgroundColor": Colors["Background"]
                                                },
                                                "footer": {
                                                    "backgroundColor": Colors["Background"]
                                                }
                                            },
                                            "type": "bubble",
                                            "header": {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [
                                                    {
                                                        "type": "button",
                                                        "style": "secondary",
                                                        "color": tempfont["font"],
                                                        "height": "sm",
                                                        "gravity": "center",
                                                        "flex": 1,
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "SMULE MEDIA",
                                                            "uri": ""
                                                        }
                                                    },
                                                ]
                                            },
                                            "hero": {
                                                "type": "image",
                                                "url": "https://i.hizliresim.com/Z5A75o.jpg",
                                                "size": "full",
                                                "aspectRatio": "16:9",
                                                "aspectMode": "cover",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": ""
                                                }
                                            },
                                            "body": {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "spacing": "md",
                                                "contents": [
                                                    {
                                                        "type": "box",
                                                        "layout": "vertical",
                                                        "flex": 1,
                                                        "contents": [
                                                            {
                                                                "text": ret_,
                                                                "size": "sm",
                                                                "margin": "none",
                                                                "color": tempfont["font"],
                                                                "wrap": True,
                                                                "weight": "regular",
                                                                "type": "text"
                                                            }
                                                        ]
                                                    }
                                                ]
                                            },
                                            "footer": {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "contents": [
                                                    {
                                                        "type": "button",
                                                        "style": "secondary",
                                                        "color": tempfont["font"],
                                                        "height": "sm",
                                                        "gravity": "center",
                                                        "flex": 1,
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "CREATOR",
                                                            "uri": "",
                                                        }
                                                    },
                                                    {
                                                        "type": "spacer",
                                                        "size": "sm",
                                                    }
                                                ],
                                                "flex": 0
                                            }
                                        }
                                    }
                                    sendflex(to, data)

                                elif len(cond) == 2:
                                    num = int(cond[1])
                                    if num <= len(data["list"]):
                                        smule = data["list"][num - 1]
                                        r = web.get(
                                            "https://smule.com/{}/performances/json".format(urllib.parse.quote(search)))
                                        data = r.text
                                        data = json.loads(data)
                                        if data["list"] != []:
                                            am = "◽Smule Kayıt Detayı"
                                            am += "\n◽ Maker: " + str(smule["owner"]["handle"])
                                            am += "\n◽ Başlık: " + str(smule["title"])
                                            am += "\n◽ Bio: " + str(smule["message"])
                                            am += "\n◽ Oyuncu: " + str(smule["stats"]["total_listens"])
                                            am += "\n◽ Beğeni: " + str(smule["stats"]["total_loves"])
                                            am += "\n◽ Oyuncu: " + str(smule["stats"]["total_comments"])
                                            am += "\n◽ Ses Ve Video"
                                            hasil = "◽ Detay Kayıt\n\n" + str(am)
                                            dl = str(smule["cover_url"])
                                            #    image = str(smule["cover_url"])
                                            chatme = ""
                                            true = True
                                            data = {
                                                "type": "flex",
                                                "altText": "smule record",
                                                "contents": {
                                                    "styles": {
                                                        "header": {
                                                            "backgroundColor": Colors["Background"]
                                                        },
                                                        "body": {
                                                            "backgroundColor": Colors["Background"]
                                                        },
                                                        "footer": {
                                                            "backgroundColor": Colors["Background"]
                                                        }
                                                    },
                                                    "type": "bubble",
                                                    "header": {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "button",
                                                                "style": "secondary",
                                                                "color": tempfont["font"],
                                                                "height": "sm",
                                                                "gravity": "center",
                                                                "flex": 1,
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "SMULE",
                                                                    "uri": ""
                                                                }
                                                            },
                                                        ]
                                                    },
                                                    "hero": {
                                                        "type": "image",
                                                        "url": dl,
                                                        #    "url":"https://raw.githubusercontent.com/noobcodermaulana/png/master/1553688604757.gif",
                                                        #  "url":"https://obs.line-scdn.net/{".format(noobcoder.getContact(noobcoderMID).pictureStatus),
                                                        #   "url": "https://files.boteater.net/jpg-q_vxahyn.jpg",
                                                        "size": "full",
                                                        "aspectRatio": "1:1",
                                                        "aspectMode": "fit",
                                                        #    "aspectRatio": "20:13",
                                                        #  "aspectMode": "cover",
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": ""
                                                        }
                                                    },
                                                    "body": {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "spacing": "md",
                                                        "contents": [
                                                            {
                                                                "type": "box",
                                                                "layout": "vertical",
                                                                "flex": 1,
                                                                "contents": [
                                                                    {
                                                                        "text": hasil,
                                                                        "size": "sm",
                                                                        "margin": "none",
                                                                        "color": tempfont["font"],
                                                                        "wrap": True,
                                                                        "weight": "regular",
                                                                        "type": "text"
                                                                    }
                                                                ]
                                                            }
                                                        ]
                                                    },
                                                    "footer": {
                                                        "type": "box",
                                                        "layout": "horizontal",
                                                        "contents": [
                                                            {
                                                                "type": "button",
                                                                "style": "secondary",
                                                                "color": tempfont["font"],
                                                                "height": "sm",
                                                                "gravity": "center",
                                                                "flex": 1,
                                                                "action": {
                                                                    "type": "uri",
                                                                    "label": "CREATOR",
                                                                    "uri": "",
                                                                }
                                                            },
                                                            {
                                                                "type": "spacer",
                                                                "size": "sm",
                                                            }
                                                        ],
                                                        "flex": 0
                                                    }
                                                }
                                            }
                                            sendflex(to, data)
                                            key = smule["key"]
                                            qx = "https://www.smule.com/p/" + str(key)
                                            r = requests.get("https://api.eater.pw/smule?url={}".format(qx))
                                            data = r.text
                                            data = json.loads(data)
                                            noobcoder.sendAudioWithURL(to, str(data["result"][0]["video"]))
                                            noobcoder.sendVideoWithURL(to, str(data["result"][0]["video"]))
                        elif cmd.startswith("youtubemp3"):
                            link = removeCmd("youtubemp3", text)
                            youtubeMp3(to, link)
                        elif cmd.startswith("youtubemp4"):
                            link = removeCmd("youtubemp4", text)
                            youtubeMp4(to, link)
                        elif cmd.startswith("fileytmp4"):
                             link = removeCmd("fileytmp4", text)
                             fileYtMp4(to, link)
                        elif cmd.startswith("fileytmp3"):
                             link = removeCmd("fileytmp3", text)
                             fileYtMp3(to, link)
#=====================================================================
# Stickers Done
                        elif cmd == "stickers":
                            ret  = " ☞  stealsticker [name]\n"
                            ret += " ☞  addsticker [name]\n"
                            ret += " ☞  delsticker [name]\n"
                            ret += " ☞  mystickers\n"
                            ret += " ☞  list stickers"
                            if wait["flex"] == True:
                                TtempListMenu(to, "STICKERS", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗦𝗧𝗜𝗖𝗞𝗘𝗥𝗦\n\n" + str(ret))
                        elif cmd.startswith("stealsticker ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("stealsticker", text)
                            name = name.lower()
                            if msg.relatedMessageId == None:
                                return noobcoder.sendMessage(to, 'Failed to steal. no reply message detected')
                            if name not in stickers2: 
                              stickers2[name.lower()] = {}
                              M = noobcoder.getRecentMessagesV2(to, 1001)
                              anu = []
                              for ind, i in enumerate(M):
                                 if i.id == msg.relatedMessageId: 
                                    anu.append(i)
                                    try:
                                        stickers2[name]["STKID"] = int(anu[0].contentMetadata["STKID"])
                                        stickers2[name]["STKPKGID"] = anu[0].contentMetadata["STKPKGID"]
                                        stickers2[name]["STKVER"] = anu[0].contentMetadata["STKVER"]
                                        if wait["flex"] == True:
                                            TBotMessage(msg.to, "Sticker saved as:\n {}".format(name.lower()))
                                        else:
                                            noobcoder.sendMessage(to, "Sticker saved as:\n {}".format(name.lower()))
                                    except:pass
                            else:
                                if wait["flex"] == True:
                                    TlistMenuLength26(to, "Sticker {} already in list.".format(name.lower()))
                                else:
                                    noobcoder.sendMessage(to, "Sticker {} already in list.".format(name.lower()))
                        elif cmd.startswith("addsticker ") and sender == noobcoderMID:
                            load()
                            name = removeCmd("addsticker", text)
                            name = name.lower()
                            if name not in stickers2:
                                anyun["addTikel"]["status"] = True
                                anyun["addTikel"]["name"] = name.lower()
                                stickers2[name.lower()] = {}
                                f = codecs.open('sticker2.json','w','utf-8')
                                json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "Send stickers to save as {} ".format(name.lower()))
                                else:
                                    noobcoder.sendMessage(to, "Send stickers to save as {} ".format(name.lower()))
                            else:
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "Stickers {} already in list.".format(name.lower()))
                                else:
                                    noobcoder.sendMessage(to, "Stickers {} already in list.".format(name.lower()))
                        elif cmd.startswith("delsticker ") and sender == noobcoderMID:
                            name = removeCmd("delsticker", text)
                            name = name.lower()
                            if name in stickers2:
                                del stickers2[name.lower()]
                                f = codecs.open('sticker2.json','w','utf-8')
                                json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "{} deleted.".format(name.lower()))
                                else:
                                    noobcoder.sendMessage(to, "{} deleted.".format(name.lower()))
                            else:
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, "Stickers {} not found in list.".format(name.lower()))
                                else:
                                    noobcoder.sendMessage(to, "Stickers {} not found in list.".format(name.lower()))
                        elif cmd == "mystickers" and sender == noobcoderMID:
                            a = noobcoder.shop.getActivePurchases(start=0, size=1000, language='ID', country='ID').productList
                            c = "List Download Sticker:"
                            no = 0
                            for b in a:
                                no +=1
                                c += "\n"+str(no)+". "+b.title[:21]+" ID:"+str(b.packageId)
                            k = len(c)//10000
                            for aa in range(k+1):
                                if wait["flex"] == True:
                                    TBotMessage(msg.to, '{}'.format(c[aa*10000 : (aa+1)*10000]))
                                else:
                                    noobcoder.sendMessage(msg.to, '{}'.format(c[aa*10000 : (aa+1)*10000]))
                        elif cmd == "liststickers" or cmd == "stickerslist":
                            load()
                            ret_ = "𝗟𝗜𝗦𝗧 𝗢𝗙 𝗦𝗧𝗜𝗖𝗞𝗘𝗥𝗦\n"
                            for sticker in stickers2:
                                ret_ += "\n " + sticker.title()
                            ret_ += "\n\nTotal {} Stickers".format(str(len(stickers2)))
                            if wait["flex"] == True:
                                TBotMessage(msg.to, str(ret_))
                            else:
                                noobcoder.sendMessage(to, str(ret_))
#=====================================================================
# Giflist Done
                        elif cmd == "giflist":
                            ret  = " ☞  gif1: link\n"
                            ret += " ☞  gif2: link\n"
                            ret += " ☞  gif3: link\n"
                            ret += " ☞  gif4: link\n"
                            ret += " ☞  gif5: link\n"
                            ret += " ☞  gif6: link\n"
                            ret += "\nMore Coming Soon ..."
                            if wait["flex"] == True:
                                TtempListMenu(to, "GIFLIST", str(ret))
                            else:
                                noobcoder.sendMessage(to, "  𝗚𝗜𝗙𝗟𝗜𝗦𝗧\n\n" + str(ret))
                        elif cmd.startswith("gif1: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            gwcool1["squad"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "saved as gid: " + gwcool3["squad"])
                            else:
                                TBotMessage(msg.to, "saved as gid: " + gwcool3["squad"])
                        elif cmd.startswith("gif2: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            gwcool2["squad"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "saved as gid: " + gwcool2["squad"])
                            else:
                                TBotMessage(msg.to, "saved as gid: " + gwcool2["squad"])
                        elif cmd.startswith("gif3: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            gwcool3["squad"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "saved as gid: " + gwcool4["squad"])
                            else:
                                TBotMessage(msg.to, "saved as gid: " + gwcool4["squad"])
                        elif cmd.startswith("gif4: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            gwcool4["squad"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "saved as gid: " + gwcool5["squad"])
                            else:
                                TBotMessage(msg.to, "saved as gid: " + gwcool5["squad"])
                        elif cmd.startswith("gif5: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            gwcool5["squad"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "saved as gid: " + gwcool6["squad"])
                            else:
                                TBotMessage(msg.to, "saved as gid: " + gwcool6["squad"])
                        elif cmd.startswith("gif6: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            gwcool5["squad"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "saved as gid: " + gwcool7["squad"])
                            else:
                                TBotMessage(msg.to, "saved as gid: " + gwcool7["squad"])
                        elif cmd.startswith("gif6: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            gwcool6["squad"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "saved as gid: " + gwcool7["squad"])
                            else:
                                TBotMessage(msg.to, "saved as gid: " + gwcool7["squad"])
                        elif cmd.startswith("gif7: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            gwcool7["squad"] = anu
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "saved as gid: " + gwcool7["squad"])
                            else:
                                TBotMessage(msg.to, "saved as gid: " + gwcool7["squad"])
                        elif cmd == "gif1":
                            gifnya = [gwcool1["squad"], ]
                            # Flex
                            data = {
                                "type": "template",
                                "altText": "",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl": "{}".format(random.choice(gifnya)),
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": ""
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "gif2":
                            gifnya = [gwcool2["squad"], ]
                            # Flex
                            data = {
                                "type": "template",
                                "altText": "",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl": "{}".format(random.choice(gifnya)),
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": ""
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "gif3":
                            gifnya = [gwcool3["squad"], ]
                            # Flex
                            data = {
                                "type": "template",
                                "altText": "",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl": "{}".format(random.choice(gifnya)),
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": ""
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "gif4":
                            gifnya = [gwcool4["squad"], ]
                            # Flex
                            data = {
                                "type": "template",
                                "altText": "",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl": "{}".format(random.choice(gifnya)),
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": ""
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "gif5":
                            gifnya = [gwcool5["squad"], ]
                            # Flex
                            data = {
                                "type": "template",
                                "altText": "",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl": "{}".format(random.choice(gifnya)),
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": ""
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "gif6":
                            gifnya = [gwcool6["squad"], ]
                            # Flex
                            data = {
                                "type": "template",
                                "altText": "",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl": "{}".format(random.choice(gifnya)),
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": ""
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        elif cmd == "gif7":
                            gifnya = [gwcool7["squad"], ]
                            # Flex
                            data = {
                                "type": "template",
                                "altText": "",
                                "template": {
                                    "type": "image_carousel",
                                    "columns": [
                                        {
                                            "imageUrl": "{}".format(random.choice(gifnya)),
                                            "size": "full",
                                            "action": {
                                                "type": "uri",
                                                "uri": ""
                                            }
                                        }
                                    ]
                                }
                            }
                            sendTemplate(to, data)
                        thread1 = threading.Thread(target=remoteText, args=(msg.to,)).start()
#=====================================================================
                    if "/ti/g/" in msg.text.lower():
                        if settings["autoJoin"] == True or settings["autoJoin"] == False:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = noobcoder.findGroupByTicket(ticket_id)
                                noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                    for image in images:
                        if msg.text.lower() == image:
                            noobcoder.generateReplyMessage(msg.id)
                            noobcoder.sendReplyImage(msg.id, to, images[image])
                    for sticker in stickers:
                        if text.lower() == sticker:
                            sid = stickers[sticker]["STKID"]
                            spkg = stickers[sticker]["STKPKGID"]
                            sver = stickers[sticker]["STKVER"]
                            try:
                                sendSticker(to, msg._from, sver, spkg, sid)
                            except Exception as e:
                                sendSticker2(to, msg._from, sver, spkg, sid)
                    for sticker in stickers2:
                        try:
                            if text.lower() == sticker:
                                sid = stickers2[sticker]["STKID"]
                                spkg = stickers2[sticker]["STKPKGID"]
                                sver = stickers2[sticker]["STKVER"]
                                a = noobcoder.shop.getProduct(packageID=int(spkg), language='ID', country='ID')
                                if a.hasAnimation == True:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                                else:data = {"type": "template","altText": "{} sent a sticker.".format(noobcoder.getProfile().displayName),"template": {"type": "image_carousel","columns": [{"imageUrl": "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker@2x.png".format(sid),"size": "full","action": {"type": "uri","uri": "http://line.me/S/sticker/{}".format(spkg)}}]}}
                                sendTemplate(to,data)
                        except Exception as e:
                            print(e)
#=====================================================================
                elif msg.contentType == 1:
                    if settings["changePicture"] == True and sender == noobcoderMID:
                        path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        settings["changePicture"] = False
                        noobcoder.updateProfilePicture(path)
                        if wait["flex"] == False:
                            noobcoder.sendMessage(msg.to, "Profile picture changed.")
                        else:
                            TBotMessage(msg.to, "Profile picture changed.")
                    if settings["changeCoverProfile"] == True and sender == noobcoderMID:
                        path = noobcoder.downloadObjectMsg(msg_id)
                        settings["changeCoverProfile"] = False
                        noobcoder.updateCover(path)                        
                        if wait["flex"] == False:
                            noobcoder.sendMessage(msg.to, "Cover picture changed.")
                        else:
                            TBotMessage(msg.to, "Cover picture changed.")
                    if settings['changeProfileVideo']['status'] == True and sender == noobcoderMID:
                        path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        if settings['changeProfileVideo']['stage'] == 1:
                            settings['changeProfileVideo']['picture'] = path
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Video profile changed.")
                            else:
                                TBotMessage(msg.to, "Video profile changed.")
                            settings['changeProfileVideo']['stage'] = 2
                        elif settings['changeProfileVideo']['stage'] == 2:
                            settings['changeProfileVideo']['picture'] = path
                            changeProfileVideo(to)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Video profile changed.")
                            else:
                                TBotMessage(msg.to, "Video profile changed.")
                    if settings["addImage"]["status"] == True and sender == noobcoderMID:
                        path = noobcoder.downloadObjectMsg(msg_id)
                        images[settings["addImage"]["name"]] = str(path)
                        f = codecs.open("image.json","w","utf-8")
                        json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                        if wait["flex"] == False:
                            noobcoder.sendMessage(msg.to, "added picture {} in list".format(str(settings["addImage"]["name"])))
                        else:
                            TBotMessage(msg.to, "added picture {} in list".format(str(settings["addImage"]["name"])))
                        settings["addImage"]["status"] = False
                        settings["addImage"]["name"] = ""
                    if msg.toType == 2:
                        if to in settings["changeGroupPicture"]:
                            path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/video.bin")
                            settings["changeGroupPicture"].remove(to)
                            noobcoder.updateGroupPicture(to, path)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Group picture changed.")
                            else:
                                TBotMessage(msg.to, "Group picture changed.")
                    if msg.toType == 2:
                        if to in settings["changeGroupPicture"]:
                            path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/video.bin")
                            settings["changeGroupPicture"].remove(to)
                            noobcoder.updateGroupPicture(to, path)
                            if wait["flex"] == False:
                                noobcoder.sendMessage(msg.to, "Group picture changed.")
                            else:
                                TBotMessage(msg.to, "Group picture changed.")
                elif msg.contentType == 2:
                    if settings['changeProfileVideo']['status'] == True and sender == noobcoderMID:
                        path = noobcoder.downloadObjectMsg(msg_id)
                        if settings['changeProfileVideo']['stage'] == 1:
                            settings['changeProfileVideo']['video'] = path
                            TBotMessage(to, "Type: Profile\n • Detail: Change Video Profile\n • Status: Send picture ~")
                            settings['changeProfileVideo']['stage'] = 2
                        elif settings['changeProfileVideo']['stage'] == 2:
                            settings['changeProfileVideo']['video'] = path
                            changeProfileVideo(to)
                elif msg.contentType == 7:
                    a = noobcoder.shop.getProduct(packageID=int(msg.contentMetadata['STKPKGID']), language='ID', country='ID')
                    if settings["messageSticker"]["addStatus"] == True and sender == noobcoderMID:
                        name = settings["messageSticker"]["addName"]
                        if name != None and name in settings["messageSticker"]["listSticker"]:
                            settings["messageSticker"]["listSticker"][name] = {
                                "STKID": msg.contentMetadata["STKID"],
                                "STKVER": msg.contentMetadata["STKVER"],
                                "STKPKGID": msg.contentMetadata["STKPKGID"]
                            }
                            TBotMessage(msg.to, " 「 Sticker 」\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                        settings["messageSticker"]["addStatus"] = False
                        settings["messageSticker"]["addName"] = None
                        settings["messageSticker"]["listSticker"]["addSticker"]["status"] = True
                        settings['messageSticker']['listSticker']['readerSticker']['status'] = True
                        settings['messageSticker']['listSticker']['replySticker']['status'] = True
                    if wstckr["sticker"]["status"] == True:
                        if msg.contentMetadata["STKVER"] not in wstckr["sticker"]["ver"]:
                            ver = msg.contentMetadata["STKVER"]
                            wstckr["sticker"]["ver"] = ver
                        if msg.contentMetadata["STKID"] not in wstckr["sticker"]["stkid"]:
                            stk = msg.contentMetadata["STKID"]
                            wstckr["sticker"]["stkid"] = stk
                        if msg.contentMetadata["STKPKGID"] not in wstckr["sticker"]["pkgid"]:
                            pkg = msg.contentMetadata["STKPKGID"]
                            wstckr["sticker"]["pkgid"] = pkg
                    if to in wstckr["sticker"]["sender"]:
                        noobcoder.sendReplyMessage(msg.id, to, "Succes Add Sticker To Welcome Message")
                        wstckr["sticker"]["status"] = False
                        wstckr["sticker"]["sender"].remove(to)
                    if lstckr["sticker"]["status"] == True:
                        if msg.contentMetadata["STKVER"] not in lstckr["sticker"]["ver"]:
                            ver = msg.contentMetadata["STKVER"]
                            lstckr["sticker"]["ver"] = ver
                        if msg.contentMetadata["STKID"] not in lstckr["sticker"]["stkid"]:
                            stk = msg.contentMetadata["STKID"]
                            lstckr["sticker"]["stkid"] = stk
                        if msg.contentMetadata["STKPKGID"] not in lstckr["sticker"]["pkgid"]:
                            pkg = msg.contentMetadata["STKPKGID"]
                            lstckr["sticker"]["pkgid"] = pkg
                    if to in lstckr["sticker"]["sender"]:
                        noobcoder.sendReplyMessage(msg.id, to, "Succes Add Sticker To Leave Message")
                        lstckr["sticker"]["status"] = False
                        lstckr["sticker"]["sender"].remove(to)
                    if dstckr["sticker"]["status"] == True:
                        if msg.contentMetadata["STKVER"] not in dstckr["sticker"]["ver"]:
                            ver = msg.contentMetadata["STKVER"]
                            dstckr["sticker"]["ver"] = ver
                        if msg.contentMetadata["STKID"] not in dstckr["sticker"]["stkid"]:
                            stk = msg.contentMetadata["STKID"]
                            dstckr["sticker"]["stkid"] = stk
                        if msg.contentMetadata["STKPKGID"] not in dstckr["sticker"]["pkgid"]:
                            pkg = msg.contentMetadata["STKPKGID"]
                            dstckr["sticker"]["pkgid"] = pkg
                    if to in dstckr["sticker"]["sender"]:
                        noobcoder.sendReplyMessage(msg.id, to, "Succes Add Sticker To Detect Mention")
                        dstckr["sticker"]["status"] = False
                        dstckr["sticker"]["sender"].remove(to)
                    if settings["addSticker"]["status"] == True and sender == noobcoderMID:
                        stickers[settings["addSticker"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                        stickers[settings["addSticker"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        stickers[settings["addSticker"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        f = codecs.open('sticker.json','w','utf-8')
                        json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                        TBotMessage(to, "Succes Add Sticker {}".format(str(settings["addSticker"]["name"])))
                        settings["addSticker"]["status"] = False
                        settings["addSticker"]["name"] = ""
                if msg.contentType == 7:
                    if anyun["addTikel"]["status"] == True:
                        stickers2[anyun["addTikel"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        stickers2[anyun["addTikel"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        stickers2[anyun["addTikel"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                        f = codecs.open('sticker2.json','w','utf-8')
                        json.dump(stickers2, f, sort_keys=True, indent=4, ensure_ascii=False)
                        if wait["flex"] == True:
                            TBotMessage(msg.to, "Sticker {} added.".format(str(anyun["addTikel"]["name"])))
                        else:
                            noobcoder.sendMessage(to, "Sticker {} added.".format(str(anyun["addTikel"]["name"])))
                        anyun["addTikel"]["status"] = False
                        anyun["addTikel"]["name"] = ""
                if msg.contentType == 7:
                    if sets["messageStickerz"]["addStatusz"] == True:
                        name = sets["messageStickerz"]["addNamez"]
                        if name != None and name in sets["messageStickerz"]["listStickerz"]:
                            sets["messageStickerz"]["listStickerz"][name] = {
                                "STKID": msg.contentMetadata["STKID"],
                                "STKVER": msg.contentMetadata["STKVER"],
                                "STKPKGID": msg.contentMetadata["STKPKGID"]
                            }
                            TBotMessage(to, "Success Add " + name)
                        sets["messageStickerz"]["addStatusz"] = False
                        sets["messageStickerz"]["addNamez"] = None
                    if sets["addStickerz"]["status"] == True:
                        anumu[sets["addStickerz"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                        anumu[sets["addStickerz"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                        anumu[sets["addStickerz"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                        f = codecs.open('stickertemp.json','w','utf-8')
                        json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                        if wait["flex"] == True:
                            TBotMessage(msg.to, "Sticker {} added.".format(str(sets["addStickerz"]["name"])))
                        else:
                            noobcoder.sendMessage(to, "Sticker {} added.".format(str(sets["addStickerz"]["name"])))
                        sets["addStickerz"]["status"] = False
                        sets["addStickerz"]["name"] = ""
                if msg.contentType == 7:
                    a = noobcoder.shop.getProduct(packageID=int(msg.contentMetadata['STKPKGID']), language='ID', country='ID')
                    if msg.to in wait["GROUP"]['AR']['S']:
                        if wait["GROUP"]['AR']['S'][msg.to]['AP'] == True:
                            wait["GROUP"]['AR']['S'][msg.to]['Sticker'] = msg.contentMetadata
                            if wait["flex"] == True:
                                TBotMessage(msg.to, "𝗔𝗗𝗗𝗥𝗘𝗦𝗣𝗢𝗡𝗦𝗘 𝗦𝗧𝗜𝗖𝗞𝗘𝗥\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            else:
                                noobcoder.sendMessage(msg.to, "𝗔𝗗𝗗𝗥𝗘𝗦𝗣𝗢𝗡𝗦𝗘 𝗦𝗧𝗜𝗖𝗞𝗘𝗥\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            wait["GROUP"]['AR']['S'][msg.to]['AP'] = False
                    if msg.to in wait["GROUP"]['WM']['S']:
                        if wait["GROUP"]['WM']['S'][msg.to]['AP'] == True:
                            wait["GROUP"]['WM']['S'][msg.to]['Sticker'] = msg.contentMetadata
                            if wait["flex"] == True:
                                TBotMessage(msg.to,"𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗦𝗧𝗜𝗖𝗞𝗘𝗥\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            else:
                                noobcoder.sendMessage(msg.to, "𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗦𝗧𝗜𝗖𝗞𝗘𝗥\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            wait["GROUP"]['WM']['S'][msg.to]['AP'] = False
                    if msg.to in wait["GROUP"]['LM']['S']:
                        if wait["GROUP"]['LM']['S'][msg.to]['AP'] == True:
                            wait["GROUP"]['LM']['S'][msg.to]['Sticker'] = msg.contentMetadata
                            if wait["flex"] == True:
                                TBotMessage(msg.to,"𝗟𝗘𝗔𝗩𝗘 𝗦𝗧𝗜𝗖𝗞𝗘𝗥\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            else:
                                noobcoder.sendMessage(msg.to, "𝗟𝗘𝗔𝗩𝗘 𝗦𝗧𝗜𝗖𝗞𝗘𝗥\nName: "+a.title+"\nSTKID: "+msg.contentMetadata['STKID']+"\nSTKPKGID: "+msg.contentMetadata['STKPKGID']+"\nSTKVER: "+msg.contentMetadata['STKVER'])
                            wait["GROUP"]['LM']['S'][msg.to]['AP'] = False
                elif msg.contentType == 13:
                    if settings["addContact"]["status"] == True:
                        contacts[settings["addContact"]["name"]]["mid"] = msg.contentMetadata["mid"]
                        backupData()
                        TBotMessage(to,"Contact successfully added to command {}.".format(str(settings["addContact"]["name"])))
                        settings["addContact"]["status"] = False
                        settings["addContact"]["name"] = ""
                elif msg.contentType == 14:
                    if hoho["savefile"] == True and sender == noobcoderMID:
                        try:
                             namafile = hoho["namafile"]
                             noobcoder.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             TBotMessage(to, "Successful, the file has been uploaded")
                        except Exception as e:
                             TBotMessage(to, str(e))
                elif msg.contentType == 15:
                    if msg.location != None:                           
                        yun = msg.location.latitude
                        yun2 = msg.location.longitude
                        sam1 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=0&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))
                        sam2 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=90&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))
                        sam3 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=100&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))
                        sam4 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=270&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))
                        sam5 = "https://maps.googleapis.com/maps/api/streetview?location={},{}&size=600x400&heading=370&key=AIzaSyCTxOiGYGTCJH0PXkhTPRwBvooBaKdcD74".format(str(yun),str(yun2))                           
                        noobcoder.sendImageWithURL(to, str(sam1))
                        noobcoder.sendImageWithURL(to, str(sam2))
                        noobcoder.sendImageWithURL(to, str(sam3))
                        noobcoder.sendImageWithURL(to, str(sam4))
                        noobcoder.sendImageWithURL(to, str(sam5))
# Sticker
        if op.type == 55:
            #print ("[ 55 ] NOTIFIED READ MESSAGE")
            if op.param1 in settings["getReader"] and op.param2 not in settings["getReader"][op.param1]:
                msgSticker = settings["messageSticker"]["listSticker"]["readerSticker"]
                if msgSticker != None:
                    sid = msgSticker["STKID"]
                    spkg = msgSticker["STKPKGID"]
                    sver = msgSticker["STKVER"]
                    sendSticker(op.param1, op.param2, sver, spkg, sid)
                if "@!" in settings["pesanReader"]:
                    msg = settings["pesanReader"].split("@!")
                  #  noobcoder.sendMentionV1(op.param1, op.param2, msg[0], msg[1])
                else:
                    noobcoder.sendMentionV1(op.param1, op.param2, "", settings["pesanReader"])
                settings["getReader"][op.param1].append(op.param2)
# Lurking
        if op.type == 55:
            if op.param1 in tailah2["siderTemp"] and op.param2 not in tailah2["siderTemp"][op.param1]:
                tailah2["siderTemp"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = noobcoder.getContact(op.param2)
                noobcoder.sendMessage(op.param1, tailah2["siderPesan"] + " {}".format(str(contact.displayName)))
                time.sleep(1)
# Lurking Tag
        if op.type == 55:
            if op.param1 in tailah2tag["siderTemp"] and op.param2 not in tailah2tag["siderTemp"][op.param1]:
                tailah2tag["siderTemp"][op.param1].append(op.param2)
                sendMentionMsg(op.param1, op.param2, tailah2["siderPesan"], "")
                time.sleep(1)
# Sider 
        if op.type == 55:
            if op.param1 in tailah3["siderTemp"] and op.param2 not in tailah3["siderTemp"][op.param1]:
                tailah3["siderTemp"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = noobcoder.getContact(op.param2)
                    cover = noobcoder.getProfileCoverURL(op.param2)
                    pesan = tailah["siderPesan"]
                    warna1 = ("#00FFFF","#000000","#0000FF","#8A2BE2","#A52A2A","#7FFF00","#6495ED","#DC143C","#00FFFF","#00008B","#B8860B","#006400","#8B008B","#FF8C00","#FF8C00","#00CED1","#9400D3","#FF1493","#32CD32","#4B0082","#FF00FF","#0000CD","#48D1CC","#C71585","#000080","#FFA500","#FF4500","#FF0000")
                    gifna = ("https://i.ibb.co/5vxHXFV/16-4284.jpg","https://i.ibb.co/FWjjZTf/b6ec73911a2a052bef5d8f30a00fadae.jpg","https://i.ibb.co/XxJDVTB/012b348156951b7dfbd1d894d480be6e.jpg","https://i.ibb.co/z56rSm3/images.jpg","https://i.ibb.co/m4DMWSt/5c5dce88a4a2f0c86ebfa49cd510fbd6.jpg","https://i.ibb.co/1n0ySjt/31112642-0.jpg")
                    warnanya1 = random.choice(warna1)
                    gifnay = random.choice(gifna)
                    data = {
                        "type": "flex",
                        "altText": "{}".format(noobcoder.getProfile().displayName),
                        "contents": {
                          "type": "bubble",
                          "size": "micro",
                          "body": {
                            "type": "box",
                            "layout": "vertical",
                            "contents": [
                              {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                  {
                                    "type": "image",
                                    "url": cover,
                                    "size": "full",
                                    "aspectMode": "cover"
                                  },
                                  {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                      {
                                        "type": "image",
                                        "url": "https://obs.line-scdn.net/{}".format(noobcoder.getProfile().pictureStatus),
                                        "size": "full",
                                        "aspectMode": "cover"
                                      }
                                    ],
                                    "position": "absolute",
                                    "width": "40px",
                                    "height": "40px",
                                    "borderWidth": "1px",
                                    "borderColor": "#ffffff",
                                    "cornerRadius": "100px",
                                    "offsetStart": "10px",
                                    "offsetBottom": "105px"
                                  },
                                  {
                                    "type": "box",
                                    "layout": "vertical",
                                    "contents": [
                                      {
                                        "type": "text",
                                        "text": "{}".format(noobcoder.getProfile().displayName),
                                        "size": "xxs",
                                        "align": "center",
                                        "style": "normal",
                                        "color": "#ffffff",
                                        "offsetTop": "2px"
                                      }
                                    ],
                                    "position": "absolute",
                                    "width": "110px",
                                    "height": "20px",
                                    "offsetEnd": "0px",
                                    "backgroundColor": "#FFFFFF82",
                                    "offsetBottom": "115px"
                                  }
                                ]
                              },
                              {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                  {
                                    "type": "image",
                                    "size": "full",
                                    "aspectMode": "cover",
                                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                                  }
                                ],
                                "position": "absolute",
                                "offsetTop": "105px",
                                "width": "40px",
                                "height": "40px",
                                "borderWidth": "1px",
                                "borderColor": "#ffffff",
                                "cornerRadius": "100px",
                                "offsetStart": "10px"
                              },
                              {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                  {
                                    "type": "text",
                                    "text": "{}".format(str(contact.displayName)),
                                    "size": "xxs",
                                    "align": "center",
                                    "style": "normal",
                                    "color": "#ffffff",
                                    "offsetTop": "2px"
                                  }
                                ],
                                "position": "absolute",
                                "width": "110px",
                                "height": "20px",
                                "offsetTop": "115px",
                                "offsetEnd": "0px",
                                "backgroundColor": "#FFFFFF82"
                              },
                              {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                  {
                                    "type": "text",
                                    "text": "{}".format(pesan),
                                    "color": "#ffffff",
                                    "size": "xxs",
                                    "offsetTop": "2px",
                                    "align": "center"
                                  }
                                ],
                                "position": "absolute",
                                "backgroundColor": "#FFFFFF82",
                                "width": "160px",
                                "height": "20px",
                                "offsetTop": "70px"
                              }
                            ],
                            "paddingAll": "0px",
                            "borderWidth": "1px",
                            "borderColor": "#FFFFFF",
                            "cornerRadius": "10px"
                          }
                        }}
                    sendTemplate(op.param1, data)

############## sider 1
        if op.type == 55:
            if op.param1 in tailah["siderTemp"] and op.param2 not in tailah["siderTemp"][op.param1]:
                tailah["siderTemp"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    fit = noobcoder.getCompactGroup(op.param1)
                    noobcoderName = "{}".format(str(noobcoder.getContact(noobcoderMID).displayName))
                    noobcoderPP = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
                    noobcoderCV = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(noobcoderMID).pictureStatus)
                    memmberName = "{}".format(str(noobcoder.getContact(op.param2).displayName))
                    memmberPP = "https://obs.line-scdn.net/{}".format(noobcoder.getContact(op.param2).pictureStatus)
                    memmberCV = "https://obs.line-scdn.net/{}".format(noobcoder.getProfileCoverURL(op.param2))
                    Message = tailah["siderPesan"]
                TtempSider101(op.param1, memmberPP, memmberName, Message)
                time.sleep(1)
        if op.type == 55:
            try:
                Name = noobcoder.getContact(op.param2).mid
                group = noobcoder.getGroup(op.param1).name
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                hr = timeNow.strftime("%A")
                bln = timeNow.strftime("%m")
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bln == str(k): bln = bulan[k-1]
                readTime = timeNow.strftime('%H.%M')
                readTime2 = hr
                readTime3 = timeNow.strftime('%d') + "-" + bln + "-" + timeNow.strftime('%Y')
                lastseen["username"][Name] = "Was lastseen\nIn Group: ' " + group + " '\nTime: " + readTime + " WIB\nOn: " + readTime2 + ", " + readTime3
                lastseen['find'][op.param2] = True
            except Exception as e:
                print(e)
        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            if msg.contentMetadata is None:msg.contentMetadata = {}
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 0 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            if msg.location != None:
                                unsendmsg = time.time()
                                msg_dict[msg.id] = {"location":msg.location,"from":msg._from,"waktu":unsendmsg}
                            else:
                                unsendmsg = time.time()
                                msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"waktu":unsendmsg}
                        except Exception as e:
                            print (e)
                if msg.contentType == 1 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg1 = time.time()
                            path = noobcoder.downloadObjectMsg(msg_id)
                            msg_dict[msg.id] = {"from":msg._from,"image":path,"waktu":unsendmsg1}
                        except Exception as e:
                            print (e)
                if msg.contentType == 2 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg2 = time.time()
                            path = noobcoder.downloadObjectMsg(msg_id)
                            msg_dict[msg.id] = {"from":msg._from,"video":path,"waktu":unsendmsg2}
                        except Exception as e:
                            print (e)
                if msg.contentType == 3 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg3 = time.time()
                            path = noobcoder.downloadObjectMsg(msg_id)
                            msg_dict[msg.id] = {"from":msg._from,"audio":path,"waktu":unsendmsg3}
                        except Exception as e:
                            print (e)
                if msg.contentType == 7 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg7 = time.time()
                            sticker = msg.contentMetadata["STKID"]
                            link = "http://dl.stickershop.line.naver.jp/stickershop/v1/sticker/{}/android/sticker.png".format(sticker)
                            msg_dict[msg.id] = {"from":msg._from,"sticker":link,"waktu":unsendmsg7}
                        except Exception as e:
                            print (e)
                if msg.contentType == 13 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg13 = time.time()
                            mid = msg.contentMetadata["mid"]
                            msg_dict[msg.id] = {"from":msg._from,"mid":mid,"waktu":unsendmsg13}
                        except Exception as e:
                            print (e)
                if msg.contentType == 14 and to not in chatbot["botMute"]:
                    if settings["unsendMessage"] == True:
                        try:
                            unsendmsg14 = time.time()
                            path = noobcoder.downloadObjectMsg(msg_id)
                            msg_dict[msg.id] = {"from":msg._from,"file":path,"waktu":unsendmsg14}
                        except Exception as e:
                            print (e)
        if op.type == 65:
            if op.param1 not in chatbot["botMute"]:
                if settings["unsendMessage"] == True:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        ah = time.time()
                        ikkeh = noobcoder.getContact(msg_dict[msg_id]["from"])
                        if "text" in msg_dict[msg_id]:
                            waktumsg = ah - msg_dict[msg_id]["waktu"]
                            waktumsg = format_timespan(waktumsg)
                            rat_ = "\nSend At :\n{} ago".format(waktumsg)
                            rat_ += "\nText :\n{}".format(msg_dict[msg_id]["text"])
                            noobcoder.sendMentionV1(at, ikkeh.mid, "# Resend Message\n\nCreator :\n", str(rat_))
                            del msg_dict[msg_id]
                        else:
                            if "image" in msg_dict[msg_id]:
                                waktumsg = ah - msg_dict[msg_id]["waktu"]
                                waktumsg = format_timespan(waktumsg)
                                rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                rat_ += "\nImage :\nBelow"
                                noobcoder.sendMentionV1(at, ikkeh.mid, "# Resend Message\n\nCreator :\n", str(rat_))
                                noobcoder.sendImage(at, msg_dict[msg_id]["image"])
                                del msg_dict[msg_id]
                            else:
                                if "video" in msg_dict[msg_id]:
                                    waktumsg = ah - msg_dict[msg_id]["waktu"]
                                    waktumsg = format_timespan(waktumsg)
                                    rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                    rat_ += "\nVideo :\nBelow"
                                    noobcoder.sendMentionV1(at, ikkeh.mid, "# Resend Message\n\nCreator :\n", str(rat_))
                                    noobcoder.sendVideo(at, msg_dict[msg_id]["video"])
                                    del msg_dict[msg_id]
                                else:
                                    if "audio" in msg_dict[msg_id]:
                                        waktumsg = ah - msg_dict[msg_id]["waktu"]
                                        waktumsg = format_timespan(waktumsg)
                                        rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                        rat_ += "\nAudio :\nBelow"
                                        noobcoder.sendMentionV1(at, ikkeh.mid, "# Resend Message\n\nCreator :\n", str(rat_))
                                        noobcoder.sendAudio(at, msg_dict[msg_id]["audio"])
                                        del msg_dict[msg_id]
                                    else:
                                        if "sticker" in msg_dict[msg_id]:
                                            waktumsg = ah - msg_dict[msg_id]["waktu"]
                                            waktumsg = format_timespan(waktumsg)
                                            rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                            rat_ += "\nSticker :\nBelow"
                                            noobcoder.sendMentionV1(at, ikkeh.mid, "# Resend Message\n\nCreator :\n", str(rat_))
                                            noobcoder.sendImageWithURL(at, msg_dict[msg_id]["sticker"])
                                            del msg_dict[msg_id]
                                        else:
                                            if "mid" in msg_dict[msg_id]:
                                                waktumsg = ah - msg_dict[msg_id]["waktu"]
                                                waktumsg = format_timespan(waktumsg)
                                                rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                                rat_ += "\nContact :\nBelow"
                                                noobcoder.sendMentionV1(at, ikkeh.mid, "# Resend Message\n\nCreator :\n", str(rat_))
                                                noobcoder.sendContact(at, msg_dict[msg_id]["mid"])
                                                del msg_dict[msg_id]
                                            else:
                                                if "location" in msg_dict[msg_id]:
                                                    waktumsg = ah - msg_dict[msg_id]["waktu"]
                                                    waktumsg = format_timespan(waktumsg)
                                                    rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                                    rat_ += "\nLocation :\nBelow"
                                                    noobcoder.sendMentionV1(at, ikkeh.mid, "# Resend Message\n\nCreator :\n", str(rat_))
                                                    noobcoder.sendLocation(at, msg_dict[msg_id]["location"])
                                                    del msg_dict[msg_id]
                                                else:
                                                    if "file" in msg_dict[msg_id]:
                                                        waktumsg = ah - msg_dict[msg_id]["waktu"]
                                                        waktumsg = format_timespan(waktumsg)
                                                        rat_ = "\nSend At :\n{} ago".format(waktumsg)
                                                        rat_ += "\nFile :\nBelow"
                                                        noobcoder.sendMentionV1(at, ikkeh.mid, "# Resend Message\n\nCreator :\n", str(rat_))
                                                        noobcoder.sendFile(at, msg_dict[msg_id]["file"])
                                                        del msg_dict[msg_id]
                else:
                    print ("[ ERROR ] Terjadi Error Karena Tidak Ada Data Chat Tersebut~")
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)
#=====================================================================
def sendMentionMsg(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        noobcoder.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        noobcoder.sendMessage(to, "")
def getLexeInvite(op):
    if op.param1 not in Lexe["linvite"]:
        Lexe["linvite"][op.param1] = {"op2":{},"op3":{}}
    if op.param3 == None:
        invite = op.param2.split("\x1e")
        for user in invite:
            if op.param2 not in Lexe["linvite"][op.param1]["op3"]:
                if len(Lexe["linvite"][op.param1]["op3"]) <= 100:
                    Lexe["linvite"][op.param1]["op3"][user] = True
                else:
                    Lexe["linvite"][op.param1]["op3"] = {}
                    Lexe["linvite"][op.param1]["op3"][user] = True
    else:
        invite = op.param3.split("\x1e")
        for user in invite:
            if user not in Lexe["linvite"][op.param1]["op3"]:
                if len(Lexe["linvite"][op.param1]["op3"]) <= 100:
                    Lexe["linvite"][op.param1]["op3"][user] = True
                else:
                    Lexe["linvite"][op.param1]["op3"] = {}
                    Lexe["linvite"][op.param1]["op3"][user] = True
        if op.param2 not in Lexe["linvite"][op.param1]["op2"]:
            if len(Lexe["linvite"][op.param1]["op2"]) <= 100:
                Lexe["linvite"][op.param1]["op2"][op.param2] = True
            else:
                Lexe["linvite"][op.param1]["op2"] = {}
                Lexe["linvite"][op.param1]["op2"][op.param2] = True
    return
def getLexeKick(op):
    if op.param1 not in Lexe["lkick"]:Lexe["lkick"][op.param1] = {"op2":{},"op3":{}}
    if op.param3 == None:
        if op.param2 not in Lexe["lkick"][op.param1]["op3"]:
            if len(Lexe["lkick"][op.param1]["op3"]) <= 100:
                Lexe["lkick"][op.param1]["op3"][op.param2] = True
            else:
                Lexe["lkick"][op.param1]["op3"] = {}
                Lexe["lkick"][op.param1]["op3"][op.param2] = True
    else:
        if op.param3 not in Lexe["lkick"][op.param1]["op3"]:
            if len(Lexe["lkick"][op.param1]["op3"]) <= 100:
                Lexe["lkick"][op.param1]["op3"][op.param3] = True
            else:
                Lexe["lkick"][op.param1]["op3"] = {}
                Lexe["lkick"][op.param1]["op3"][op.param3] = True
        if op.param2 not in Lexe["lkick"][op.param1]["op2"]:
            if len(Lexe["lkick"][op.param1]["op2"]) <= 100:
                Lexe["lkick"][op.param1]["op2"][op.param2] = True
            else:
                Lexe["lkick"][op.param1]["op2"] = {}
                Lexe["lkick"][op.param1]["op2"][op.param2] = True
    return
def getLexeJoin(op):
    if op.param1 not in Lexe["ljoin"]:Lexe["ljoin"][op.param1] = {}
    if op.param2 not in Lexe["ljoin"][op.param1]:
        if len(Lexe["ljoin"][op.param1]) <= 100:
            Lexe["ljoin"][op.param1][op.param2] = True
        else:
            Lexe["ljoin"][op.param1] = {}
            Lexe["ljoin"][op.param1][op.param2] = True
    return
def getLexeLeave(op):
    if op.param1 not in Lexe["lleave"]:Lexe["lleave"][op.param1] = {}
    if op.param2 not in Lexe["lleave"][op.param1]:
        if len(Lexe["lleave"][op.param1]) <= 100:
            Lexe["lleave"][op.param1][op.param2] = True
        else:
            Lexe["lleave"][op.param1] = {}
            Lexe["lleave"][op.param1][op.param2] = True
    return
def getLexeCancel(op):
    if op.param1 not in Lexe["lcancel"]:Lexe["lcancel"][op.param1] = {"op2":{},"op3":{}}
    if op.param3 == None:
        if op.param2 not in Lexe["lcancel"][op.param1]["op3"]:
            if len(Lexe["lcancel"][op.param1]["op3"]) <= 100:
                Lexe["lcancel"][op.param1]["op3"][op.param2] = True
            else:
                Lexe["lcancel"][op.param1]["op3"] = {}
                Lexe["lcancel"][op.param1]["op3"][op.param2] = True
    else:
        if op.param3 not in Lexe["lcancel"][op.param1]["op3"]:
            if len(Lexe["lcancel"][op.param1]["op3"]) <= 100:
                Lexe["lcancel"][op.param1]["op3"][op.param3] = True
            else:
                Lexe["lcancel"][op.param1]["op3"] = {}
                Lexe["lcancel"][op.param1]["op3"][op.param3] = True
        if op.param2 not in Lexe["lcancel"][op.param1]["op2"]:
            if len(Lexe["lcancel"][op.param1]["op2"]) <= 100:
                Lexe["lcancel"][op.param1]["op2"][op.param2] = True
            else:
                Lexe["lcancel"][op.param1]["op2"] = {}
                Lexe["lcancel"][op.param1]["op2"][op.param2] = True
    return
def countLexe(to,lexe,x):
    num = 0
    ngen = []
    tot = 0
    if "ljoin" == lexe:
        tot += len(Lexe["ljoin"][to])
        tot -= int(x)
        for a in Lexe["ljoin"][to]:
            num +=1
            if num == tot:
                ngen.append(a)
                num -=1
        return ngen
    if "lkick" == lexe:
        tot += len(Lexe["lkick"][to]["op3"])
        tot -= int(x)
        for a in Lexe["lkick"][to]["op3"]:
            num +=1
            if num == tot:
                ngen.append(a)
                num -=1
        return ngen
    if "lkickd" == lexe:
        tot += len(Lexe["lkick"][to]["op2"])
        tot -= int(x)
        for a in Lexe["lkick"][to]["op2"]:
            num +=1
            if num == tot:
                ngen.append(a)
                num -=1
        return ngen
    if "lcancel" == lexe:
        tot += len(Lexe["lcancel"][to]["op3"])
        tot -= int(x)
        for a in Lexe["lcancel"][to]["op3"]:
            num +=1
            if num == tot:
                ngen.append(a)
                num -=1
        return ngen
    if "lcanceld" == lexe:
        tot += len(Lexe["lcancel"][to]["op2"])
        tot -= int(x)
        for a in Lexe["lcancel"][to]["op2"]:
            num +=1
            if num == tot:
                ngen.append(a)
                num -=1
        return ngen
    if "linvite" == lexe:
        tot += len(Lexe["linvite"][to]["op3"])
        tot -= int(x)
        for a in Lexe["linvite"][to]["op3"]:
            num +=1
            if num == tot:
                ngen.append(a)
                num -=1
        return ngen
    if "linvited" == lexe:
        tot += len(Lexe["linvite"][to]["op2"])
        tot -= int(x)
        for a in Lexe["linvite"][to]["op2"]:
            num +=1
            if num == tot:
                ngen.append(a)
                num -=1
        return ngen
    if "lleave" == lexe:
        tot += len(Lexe["lleave"][to])
        tot -= int(x)
        for a in Lexe["lleave"][to]:
            num +=1
            if num == tot:
                ngen.append(a)
                num -=1
        return ngen
def Lcontact(x):
    num = 0
    ngen = []
    tot = 0
    tot += len(Lexe["lscon"])
    tot -= int(x)
    for a in Lexe["lscon"]:
        num +=1
        if num == tot:
            ngen.append(Lexe["lscon"][a])
            num -=1
    return ngen
def run():
    while True:
        try:
            #delExpire()
            ops = noobcoderPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(noobcoderBot(op))
                   #noobcoderBot(op)
                   noobcoderPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)
if __name__ == "__main__":
    run()
